// JUGADOR — controles (teclado, ratón, táctil), movimiento, caída, cámara con balanceo/pulso, paranoia, muerte y reinicio.
import { estado, SZ, TACTIL } from './config.js';
import { cam, cv, renderer } from './escena.js';
import { elBanda, elBarra, elBR, elBT, elHud, elPar, joy, knob, menu, tactil } from './dom.js';
import { actualizarChunks, choca, chunks, destruirChunk } from './world.js';
import { iniciarAudio, pararVoz, vCarrera, vSusurro } from './audio.js';
import { ent, pisada } from './aulladores.js';
import { som } from './sombra.js';
import { estaticaSonido, ponerCam } from './camara.js';
import { abrirInv, aviso, inv } from './inventario.js';
import { camModelo } from './modeloCamara.js';
import { cine, cineCam, iniciarCine } from './cinematica.js';
import { DEST } from './medidor.js';
import { aplicarModo } from './modos.js';
import { VOL } from './ajustes.js';
import { abrirMenu3d } from './menu.js';

export function romperGrieta() {   // la grieta cede: estática, un golpe sordo y Game Over (por ahora)
  if (estado.rompiendo) return; estado.rompiendo = 1; estado.estatica = 1; estaticaSonido(.8, .3); if (estado.ctx) pisada(estado.ctx.currentTime, .6, 0, VOL.jug);
  setTimeout(() => { if (estado.rompiendo) { estado.rompiendo = 0; morir('grieta'); } }, 600);
}

// ================= CONTROLES (Pointer Lock + WASD) =================
export const P = { x: 14, z: 14, yaw: 0, pitch: 0 }, k = {};
// ----- Controles táctiles (Android): joystick virtual izquierdo + arrastrar para mirar -----
const mov = { x: 0, y: 0 };  // joystick: x derecha (+), y atrás (+); -y = adelante
const RJ = 50;  // recorrido máximo del botón del joystick (px)
let joyId = null, lookId = null, lx = 0, ly = 0;
function jugarTactil(on) {
  estado.activo = on; menu.style.display = on ? 'none' : 'flex'; tactil.style.display = on && !cine.act ? 'block' : 'none';
  if (!on) { joyId = lookId = null; mov.x = mov.y = 0; knob.style.transform = ''; }
}
function moverJoy(e) {
  const b = joy.getBoundingClientRect();
  let dx = e.clientX - (b.left + b.width / 2), dy = e.clientY - (b.top + b.height / 2);
  const d = Math.hypot(dx, dy); if (d > RJ) { dx *= RJ / d; dy *= RJ / d; }
  knob.style.transform = `translate(${dx}px,${dy}px)`;
  if (Math.min(d, RJ) / RJ < .15) mov.x = mov.y = 0;   // zona muerta
  else { mov.x = dx / RJ; mov.y = dy / RJ; }
}
const soltarJoy = e => { if (e.pointerId === joyId) { joyId = null; mov.x = mov.y = 0; knob.style.transform = ''; } };
const soltarLook = e => { if (e.pointerId === lookId) lookId = null; };
export function mover(dt) {
  // Teclado y joystick se suman (el joystick es analógico: más inclinado = más rápido)
  const f = (k.KeyW || k.ArrowUp ? 1 : 0) - (k.KeyS || k.ArrowDown ? 1 : 0) - mov.y, s = (k.KeyD || k.ArrowRight ? 1 : 0) - (k.KeyA || k.ArrowLeft ? 1 : 0) + mov.x;
  const m = Math.hypot(f, s);
  if (m < .05) return false;
  const v = ((k.ShiftLeft || k.ShiftRight || estado.correT) && estado.hid > 0 && !estado.calmando ? 5.2 : 3) * dt * (m > 1 ? 1 / m : 1) * (estado.calmando ? .35 : 1);   // calmándote te mueves despacio
  const dx = (-Math.sin(P.yaw) * f + Math.cos(P.yaw) * s) * v, dz = (-Math.cos(P.yaw) * f - Math.sin(P.yaw) * s) * v;
  if (!choca(P.x + dx, P.z, .35)) P.x += dx;   // ejes por separado: permite deslizar por las paredes
  if (!choca(P.x, P.z + dz, .35)) P.z += dz;
  return true;
}

// ================= PARANOIA =================
// Si te quedas demasiado tiempo en el mismo chunk, la paranoia sube hasta que sales de él; luego baja despacio.
let quieto = 0, colapso = 0, chunkAnt = '', latido = 0;
const UMBRAL = 18;  // segundos en el mismo chunk antes de que empiece a subir
export function paranoia(dt, mv) {
  const key = Math.floor(P.x / SZ) + ',' + Math.floor(P.z / SZ);
  if (key !== chunkAnt) { chunkAnt = key; quieto = 0; }       // cambiar de chunk reinicia el contador
  else quieto += dt * (mv ? .35 : 1);                         // pasear por la zona cuenta mucho menos que quedarse quieto
  const acecha = som.s === 1 && som.acecha, sube = quieto >= UMBRAL ? 1 / 28 * estado.MODO.parBase : 0;   // la sombra te vigila y no la has mirado: la paranoia sube mucho más rápido
  estado.par = Math.max(0, Math.min(1, estado.par + dt * ((acecha ? 1 / 12 * estado.MODO.parSombra + sube : (sube || -1 / 55)) - (estado.calmando ? (acecha ? 1 / 20 : 1 / 8) : 0))));   // baja algo más lento por sí sola; calmándote baja rápido (menos con la sombra encima)
  if (!estado.camOn && !estado.hintCalma && estado.par > .3 && !cine.act) { estado.hintCalma = true; aviso(TACTIL ? 'TOCA CALMA PARA CALMARTE' : 'MANTÉN Z PARA CALMARTE'); }
  colapso = estado.par >= 1 ? colapso + dt : 0;
  if (estado.par >= 1 && enManila()) morir('manila'); else if (colapso > 5.5) morir();   // en la sala manila, llegar al máximo es ganar
  if (estado.ctx && estado.par > .25 && (latido -= dt) <= 0) { const t = estado.ctx.currentTime, v = .25 + .5 * estado.par; pisada(t, v, 0, VOL.jug); pisada(t + .17, v * .7, 0, VOL.jug); latido = 1.1 - .6 * estado.par; estado.kick = 1; }   // latido cada vez más rápido
}
export function morir(causa) {
  const F = { sed: ['DESHIDRATACIÓN', 'Te quedaste sin agua.<br>Aquí casi no hay, y nadie te avisó.'], caida: ['CAÍSTE', 'No había fondo.<br>Nadie escuchó el golpe.'], manila: ['SALIDA', 'Te quedaste quieto hasta el final y el lugar te dejó pasar.<br>Por ahora esto es todo: más adelante este camino te llevará a otro nivel.'], salida: ['SALIDA', 'Abriste la puerta blanca.<br>Por ahora esto es todo: más adelante te llevará a otro nivel.'], grieta: ['GAME OVER', 'Rompiste la grieta y lo que había detrás te tragó.<br>Por ahora no lleva a ningún sitio bueno… pero algún día te llevará a otro nivel.'] }[causa] || ['COLAPSO', 'Te quedaste demasiado tiempo en el mismo lugar.<br>Tu mente se rindió antes que tu cuerpo.'];
  document.getElementById('mTit').textContent = F[0]; document.getElementById('mTxt').innerHTML = F[1];
  document.getElementById('muerte').classList.toggle('gana', causa === 'manila' || causa === 'salida'); abrirInv(false);
  if (estado.muerto) return;
  estado.muerto = true; estado.activo = false; if (document.pointerLockElement) document.exitPointerLock();
  tactil.style.display = 'none'; cv.style.filter = cv.style.transform = '';
  document.getElementById('muerte').style.display = 'flex';
}
// Reinicio dentro del juego (sin recargar la página, que falla en algunos visores/móviles)
function reiniciar() {
  if (!estado.muerto) return;
  for (const [key, ch] of [...chunks]) destruirChunk(key, ch);
  P.x = P.z = 14; P.yaw = P.pitch = 0; estado.tiempo = estado.bob = estado.osc = 0;
  estado.par = quieto = colapso = latido = 0; chunkAnt = ''; estado.flAnt = '';
  Object.assign(ent, { e: 0, t: 18 + Math.random() * 15, sil: 0, esc: 0, prox: 0 });
  som.s = 0; som.t = 40 + Math.random() * 40; if (estado.spr) estado.spr.visible = false;
  pararVoz(vCarrera); pararVoz(vSusurro);
  estado.hid = 1; estado.sed0 = 0; estado.zoom = estado.zoomObj = estado.desenf = 0; estado.objetivo = null; document.getElementById('btnZoom').classList.remove('on');
  inv.length = 0; estado.invSel = 0; abrirInv(false); estado.cayendo = false; caidaT = 0; estado.objPuerta = false;
  estado.bat = 1; estado.nv = false; estado.camObj = estado.camPos = 1; ponerCam(true); estado.modeloMundo = false; cam.add(camModelo); estado.estatica = 0; estado.medObj = estado.medPos = 0; DEST.activo = false; document.body.classList.remove('enpartida'); estado.fatiga = 0; estado.calmando = false; estado.rompiendo = 0; estado.hintCalma = false;
  if (estado.ctx && estado.voz) { estado.voz.env.gain.cancelScheduledValues(estado.ctx.currentTime); estado.voz.env.gain.setValueAtTime(0, estado.ctx.currentTime); }
  for (const key in k) k[key] = false;
  mov.x = mov.y = 0; estado.correT = false; document.getElementById('btnRun').classList.remove('on');
  cam.fov = 75; cam.updateProjectionMatrix(); elPar.style.opacity = elBanda.style.opacity = 0; elHud.style.visibility = 'visible';
  estado.muerto = false; actualizarChunks(0, 0, 99);
  document.getElementById('muerte').style.display = 'none'; abrirMenu3d();   // vuelve al menú 3D
}
// ----- Salas especiales: victoria en la sala manila y caída en la sala de huecos -----
const enManila = () => { for (const ch of chunks.values()) { const a = ch.sala; if (a && P.x > a.x0 && P.x < a.x1 && P.z > a.z0 && P.z < a.z1) return true; } return false; };
let caidaT = 0;
export function caer(dt) {
  if (estado.cayendo) { caidaT += dt; if (caidaT > 1.4) morir('caida'); return; }
  for (const ch of chunks.values()) if (ch.huecos) for (const h of ch.huecos) if (P.x > h.x0 && P.x < h.x1 && P.z > h.z0 && P.z < h.z1) { estado.cayendo = true; caidaT = 0; return; }
}
// Cámara del jugador (balanceo, zoom, pulso) y efectos visuales de la paranoia
export function efectosJugador(dt) {
  // Efectos de la paranoia (crecen despacio y se disparan al final): tambaleo, visión borrosa y fallos de la cámara
  const sw = estado.par * estado.par;
  // Zoom con servo (suave) y pulso/temblor de la cámara: más notorio y rápido con paranoia (o sed extrema) y más aún con zoom
  estado.zoom += (estado.zoomObj - estado.zoom) * Math.min(1, dt * 4);
  estado.kick = Math.max(0, estado.kick - dt * 6);
  const est = Math.max(estado.par, estado.hid < .25 ? (.25 - estado.hid) * 2 : 0);
  estado.tfase += dt * (1.3 + 4 * est);
  const tr = (.0016 + .007 * est) * (1 + 2.2 * estado.zoom) * (estado.movAhora ? 1.4 : 1);
  const t1 = Math.sin(estado.tfase * 2.1) + .6 * Math.sin(estado.tfase * 3.7 + 1), t2 = Math.sin(estado.tfase * 1.7 + 2) + .6 * Math.sin(estado.tfase * 4.3), t3 = Math.sin(estado.tfase * 1.3 + 4);
  // Al correr: balanceo de lado a lado (izquierda, derecha, izquierda...) al ritmo de los pasos
  estado.runAmt += ((estado.corrAhora ? 1 : 0) - estado.runAmt) * Math.min(1, dt * 5);
  const lat = Math.sin(estado.bob * .5) * estado.runAmt, rx = Math.cos(P.yaw), rz = -Math.sin(P.yaw);
  cam.position.set(P.x + Math.sin(estado.tiempo * 1.3) * .12 * sw + rx * lat * .07, 1.65 - (estado.cayendo ? 4.5 * caidaT * caidaT : 0) + Math.sin(estado.bob) * .035 - Math.abs(Math.sin(estado.tiempo * .9)) * .1 * sw, P.z + Math.cos(estado.tiempo * 1.1) * .12 * sw + rz * lat * .07);
  cam.rotation.set(P.pitch + Math.sin(estado.tiempo * 1.9) * .05 * sw + t2 * tr + estado.kick * .006 * estado.par, P.yaw + Math.sin(estado.tiempo * .8) * .08 * sw + t1 * tr - lat * .025, Math.sin(estado.tiempo * 1.2) * .16 * sw + t3 * tr * 1.6 + lat * .04);
  const fov = 75 - 45 * estado.zoom + Math.sin(estado.tiempo * 2.3) * 9 * sw + (estado.par > .8 && Math.random() < .08 ? (Math.random() - .5) * 30 : 0);
  if (Math.abs(fov - cam.fov) > .01) { cam.fov = fov; cam.updateProjectionMatrix(); }
  if (cine.act) cineCam();   // durante la cinemática la cámara la mueve el guion
  if (!estado.muerto && !cine.act) {
    estado.desenf = Math.max(0, estado.desenf - dt * 1.1);
    const fl = (estado.par > .12 || estado.desenf > .02) ? (estado.camOn ? `blur(${(sw * 3.5 + estado.desenf * 3.2).toFixed(1)}px) hue-rotate(${((Math.sin(estado.tiempo * 1.5) * 35 * sw) | 0)}deg) saturate(${(1 + sw).toFixed(1)})`
      : `blur(${(sw * 4.5).toFixed(1)}px) brightness(${(1 - .6 * sw).toFixed(2)}) contrast(${(1 + .3 * sw).toFixed(2)})`) : '';   // sin cámara: visión borrosa y más oscura
    if (fl !== estado.flAnt) { cv.style.filter = fl; estado.flAnt = fl; }
    cv.style.transform = (estado.camOn && estado.par > .55 && Math.random() < .12 * estado.par) ? `translate(${((Math.random() - .5) * 18 * estado.par).toFixed(0)}px,${((Math.random() - .5) * 6 * estado.par).toFixed(0)}px) scaleX(${(1 + (Math.random() - .5) * .06 * estado.par).toFixed(3)})` : '';
    elHud.style.visibility = (estado.camOn && estado.par > .7 && Math.random() < .3) ? 'hidden' : 'visible';   // la señal de la cámara falla
  }
  elPar.style.opacity = sw * .95; elBanda.style.opacity = Math.max(0, estado.par - .5) * 1.6 * (estado.camOn ? 1 : 0);
  // Barra de paranoia: se pone roja al subir, parpadea cerca del máximo y cuenta atrás al llegar al tope
  elBR.style.width = (estado.par * 100).toFixed(0) + '%'; elBR.style.background = `rgb(${(232 - 28 * estado.par) | 0},${(220 - 186 * estado.par) | 0},${(138 - 104 * estado.par) | 0})`;
  elBT.textContent = colapso > 0 ? 'COLAPSO EN ' + Math.max(0, 5.5 - colapso).toFixed(1) + 's' : estado.calmando ? 'CALMÁNDOTE…' : 'PARANOIA';
  elBarra.style.opacity = estado.par > .85 && Math.random() < .25 ? .35 : .85;
}

// ============ EVENTOS ============
// Se registran desde main.js (en el mismo orden que tenían en el script original).
export function eventosPlayer() {
  addEventListener('keydown', e => k[e.code] = true);
  addEventListener('keyup', e => k[e.code] = false);
  menu.onclick = () => {
    iniciarAudio(); aplicarModo(); iniciarCine();
    if (!TACTIL) { renderer.domElement.requestPointerLock(); return; }
    // Android/táctil: no hay bloqueo de ratón; intenta pantalla completa y horizontal
    try { document.documentElement.requestFullscreen().then(() => screen.orientation.lock('landscape')).catch(() => {}); } catch (e) {}
    jugarTactil(true);
  };
  document.addEventListener('pointerlockchange', () => { if (estado.muerto) return; estado.activo = document.pointerLockElement === renderer.domElement; menu.style.display = estado.activo ? 'none' : 'flex'; });
  document.addEventListener('mousemove', e => {
    if (!estado.activo) return;
    P.yaw -= e.movementX * .0022 * cam.fov / 75;
    P.pitch = Math.max(-1.45, Math.min(1.45, P.pitch - e.movementY * .0022 * cam.fov / 75));
  });
  joy.addEventListener('pointerdown', e => { joyId = e.pointerId; joy.setPointerCapture(joyId); moverJoy(e); });
  joy.addEventListener('pointermove', e => { if (e.pointerId === joyId) moverJoy(e); });
  joy.addEventListener('pointerup', soltarJoy);
  joy.addEventListener('pointercancel', soltarJoy);
  // Mirar: arrastrar un dedo por cualquier zona libre de la pantalla (multitáctil: funciona a la vez que el joystick)
  cv.addEventListener('pointerdown', e => { if (!TACTIL || !estado.activo || lookId !== null) return; lookId = e.pointerId; cv.setPointerCapture(lookId); lx = e.clientX; ly = e.clientY; });
  cv.addEventListener('pointermove', e => {
    if (e.pointerId !== lookId) return;
    P.yaw -= (e.clientX - lx) * .0055 * cam.fov / 75; P.pitch = Math.max(-1.45, Math.min(1.45, P.pitch - (e.clientY - ly) * .0055 * cam.fov / 75));
    lx = e.clientX; ly = e.clientY;
  });
  cv.addEventListener('pointerup', soltarLook);
  cv.addEventListener('pointercancel', soltarLook);
  // Se usa pointerdown/pointerup (no click): el navegador no genera 'click' para un segundo dedo
  document.getElementById('btnRun').onpointerdown = e => { e.preventDefault(); estado.correT = !estado.correT; e.currentTarget.classList.toggle('on', estado.correT); };
  document.getElementById('btnPausa').onpointerup = () => jugarTactil(false);
  addEventListener('contextmenu', e => e.preventDefault());
  // pointerdown (no click): con otro dedo apoyado en la pantalla el navegador no genera 'click'
  document.getElementById('muerte').onpointerdown = reiniciar;
  addEventListener('keydown', e => { if (estado.muerto && (e.code === 'Enter' || e.code === 'Space')) reiniciar(); });
}
