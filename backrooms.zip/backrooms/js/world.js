// MUNDO — generación de chunks (crearChunk), carga/descarga, colisiones y zonas oscuras.
import * as THREE from 'three';
import { C, CH, estado, H, R, SEMILLA, SZ, T } from './config.js';
import { hash, imul, rng } from './utils.js';
import { ambiente, FOG_CLARA, FOG_OSCURA, renderer, scene } from './escena.js';
import { crearManiqui, gLuz, gMuro, gSuelo, gTecho, mLuz, mMuro, mSuelo, mTecho } from './materiales.js';
import { mMueble, PROTOS } from './muebles.js';
import { gMancha, MANCHAS } from './manchas.js';
import { crearGarabato, gGar } from './garabatos.js';
import { gArco, gMarco, gPuerta, gSueloHuecos, gVacio, HS, HUECOS_L, mCrema, mManila, mPuerta, mSueloBeige, mVacio, PROTOS_ARCOS } from './salas.js';
import { GRIETAS } from './grietas.js';
import { P } from './player.js';
import { gBotella, mBotella, mContorno } from './hidratacion.js';
import { ponerItem } from './inventario.js';
import { DEST } from './medidor.js';

// ================= CHUNKS PROCEDURALES =================
export const chunks = new Map();  // "cx,cz" -> datos del chunk
export const muros = new Set();  // paredes activas (para colisiones): "n|w,i,j" en coordenadas globales de celda
export const dummy = new THREE.Object3D(), col = new THREE.Color();
const poner = (m, i, x, y, z, ry) => { dummy.position.set(x, y, z); dummy.rotation.y = ry; dummy.updateMatrix(); m.setMatrixAt(i, dummy.matrix); };
function crearChunk(cx, cz) {
  // La semilla incluye "mut": si el chunk se destruye y vuelve a crearse, será distinto
  const r = rng(hash(cx, cz, SEMILLA ^ imul(estado.mut, 2654435761)));
  const ox = cx * SZ, oz = cz * SZ, g = new THREE.Group();
  const ch = { cx, cz, g, obs: [], luces: [], mani: [], claves: [], oscura: r() < .22 && (cx !== 0 || cz !== 0) };
  // --- Distribución: densidad de paredes, salas amplias y salas especiales (muy raras, nunca en el chunk inicial) ---
  const u0 = r(); let dens = [.1, .22, .36, .36, .46][(r() * 5) | 0];
  const esDest = DEST.activo && cx === DEST.cx && cz === DEST.cz;   // el chunk al que apunta el medidor lleva siempre la salida o la sala manila
  ch.esp = (cx === 0 && cz === 0) ? null : esDest ? (DEST.tipo === 'manila' ? 'manila' : null) : u0 < .0012 ? 'arcos' : u0 < .0082 ? 'manila' : u0 < .015 ? 'huecos' : u0 < .025 ? 'marcos' : null;
  let blk = null;   // bloque rectangular de celdas que forma una sala
  if (ch.esp === 'manila') blk = { i0: 1 + ((r() * 2) | 0), j0: 1 + ((r() * 2) | 0), n: 3, m: 3, tipo: 'manila' };
  else if (ch.esp === 'huecos' || ch.esp === 'arcos') blk = { i0: 1, j0: 1, n: 4, m: 4, tipo: ch.esp };
  else if (!ch.esp && r() < .3) { const n = 3 + ((r() * 2) | 0), m = 3 + ((r() * 2) | 0); blk = { i0: (r() * (CH - n)) | 0, j0: (r() * (CH - m)) | 0, n, m, tipo: 'amplia' }; }
  if (ch.esp) ch.oscura = false;
  if (ch.esp === 'marcos') { ch.fogT = .55; dens = 0; }   // sin paredes y con la niebla espesándose: los marcos se pierden en la oscuridad
  const en = (i, j) => blk && i >= blk.i0 && i < blk.i0 + blk.n && j >= blk.j0 && j < blk.j0 + blk.m;
  const puertas = new Set();   // huecos en el perímetro de la sala (puertas)
  if (blk && (blk.tipo === 'manila' || blk.tipo === 'huecos')) {
    const per = [];
    for (let a = 0; a < blk.n; a++) per.push('n,' + (blk.i0 + a) + ',' + blk.j0, 'n,' + (blk.i0 + a) + ',' + (blk.j0 + blk.m));
    for (let b = 0; b < blk.m; b++) per.push('w,' + blk.i0 + ',' + (blk.j0 + b), 'w,' + (blk.i0 + blk.n) + ',' + (blk.j0 + b));
    for (let q = blk.tipo === 'huecos' ? 2 : 1; q--;) puertas.add(per[(r() * per.length) | 0]);
  }
  // 0 = sin pared, 1 = pared normal, 2 = pared especial (manila / crema), 3 = arco. 'n' = entre (i,j-1) y (i,j); 'w' = entre (i-1,j) y (i,j)
  const borde = (tp, i, j) => {
    const a = tp === 'n' ? en(i, j - 1) : en(i - 1, j), b = en(i, j);
    if (a && b) return 0;
    if (a || b) {
      if (blk.tipo === 'amplia') return r() < .85 ? 1 : 0;
      if (puertas.has(tp + ',' + i + ',' + j)) return 0;
      if (blk.tipo === 'arcos') return tp === 'n' ? 3 : 2;
      return 2;
    }
    return r() < dens ? 1 : 0;
  };
  const s = new THREE.Mesh(ch.esp === 'huecos' ? gSueloHuecos : gSuelo, ch.esp === 'arcos' ? mSueloBeige : mSuelo); s.position.set(ox + SZ / 2, 0, oz + SZ / 2);
  const t = new THREE.Mesh(gTecho, mTecho); t.position.set(ox + SZ / 2, H, oz + SZ / 2);
  g.add(s, t);
  const iw = new THREE.InstancedMesh(gMuro, mMuro, CH * CH * 2);
  const il = new THREE.InstancedMesh(gLuz, mLuz, CH * CH);
  iw.frustumCulled = il.frustumCulled = false;
  let nw = 0, nl = 0; const lista = [];
  const iw2 = new THREE.InstancedMesh(gMuro, ch.esp === 'manila' ? mManila : mCrema, CH * CH), ia = new THREE.InstancedMesh(gArco, mCrema, CH * CH);
  iw2.frustumCulled = ia.frustumCulled = false; let n2 = 0, na = 0;
  const colocarMuro = (tipo, tp, x, z, ry, gi, gj) => {
    if (tipo === 3) {   // tramo de arcada: los pilares bloquean el paso y el vano del arco queda libre
      dummy.position.set(x, 0, z); dummy.rotation.y = ry; dummy.updateMatrix(); ia.setMatrixAt(na++, dummy.matrix);
      for (const sg of [-1, 1]) ch.obs.push(tp === 'n' ? { x: x + sg * 1.625, z, hx: .525, hz: T / 2 } : { x, z: z + sg * 1.625, hx: T / 2, hz: .525 });
      return;
    }
    const k = tp + ',' + gi + ',' + gj;
    poner(tipo === 2 ? iw2 : iw, tipo === 2 ? n2++ : nw++, x, H / 2, z, ry); muros.add(k); ch.claves.push(k); lista.push([x, z, tp === 'n' ? 0 : 1]);
  };

  for (let i = 0; i < CH; i++) for (let j = 0; j < CH; j++) {
    const gi = cx * CH + i, gj = cz * CH + j, x0 = ox + i * C, z0 = oz + j * C;
    // Cada celda es dueña de su pared norte (eje X) y oeste (eje Z)
    const bn = borde('n', i, j), bw = borde('w', i, j);
    if (bn) colocarMuro(bn, 'n', x0 + C / 2, z0, 0, gi, gj);
    if (bw) colocarMuro(bw, 'w', x0, z0 + C / 2, Math.PI / 2, gi, gj);
    // Fluorescente: 0 = encendido, 1 = parpadea, 2 = apagado (en zonas oscuras casi todos mueren)
    if (r() < .55 || (blk && blk.tipo !== 'amplia' && en(i, j))) {
      const u = r(), e = blk && blk.tipo !== 'amplia' && en(i, j) ? 0 : ch.oscura ? (u < .92 ? 2 : 1) : (u < .12 ? 2 : u < .35 ? 1 : 0);
      poner(il, nl, x0 + C / 2, H - .02, z0 + C / 2, 0);
      il.setColorAt(nl, e === 2 ? col.setHex(0x1b1810) : col.setScalar(1));
      ch.luces.push({ x: x0 + C / 2, z: z0 + C / 2, e, f: r() * 100, v: e === 2 ? 0 : 1, i: nl, m: il }); nl++;
    }
    // Objetos aleatorios (no en la celda de inicio)
    if (r() < .08 && !ch.esp && !(cx === 0 && cz === 0 && i === 3 && j === 3)) {
      const def = PROTOS[(r() * PROTOS.length) | 0], rot = (r() * 4) | 0, px = x0 + 1.1 + r() * (C - 2.2), pz = z0 + 1.1 + r() * (C - 2.2);
      const m = new THREE.Mesh(def.g, mMueble); m.position.set(px, 0, pz);
      m.rotation.y = def.libre ? r() * 6.28 : rot * Math.PI / 2;   // giran de 90º en 90º para que la colisión rectangular cuadre (las sillas, libres)
      g.add(m); ch.obs.push({ x: px, z: pz, hx: rot % 2 ? def.hz : def.hx, hz: rot % 2 ? def.hx : def.hz });
      if (def.esc && r() < .28) {   // (sube para que las baterías sigan igual de comunes aunque haya menos escritorios)
        const a = rot * Math.PI / 2, lx = -.62, lz = .1; ponerItem(ch, 'bateria', px + Math.cos(a) * lx + Math.sin(a) * lz, pz - Math.sin(a) * lx + Math.cos(a) * lz, .775); }   // una batería sobre el escritorio
    }
  }

  // --- Contenido de las salas especiales y puerta de salida ---
  const cxw = ox + SZ / 2, czw = oz + SZ / 2;
  if (ch.esp === 'manila') ch.sala = { x0: ox + blk.i0 * C, z0: oz + blk.j0 * C, x1: ox + (blk.i0 + blk.n) * C, z1: oz + (blk.j0 + blk.m) * C };
  else if (ch.esp === 'huecos') { ch.huecos = HUECOS_L.map(([hx, hz]) => ({ x0: cxw + hx, z0: czw + hz, x1: cxw + hx + HS, z1: czw + hz + HS })); const v = new THREE.Mesh(gVacio, mVacio); v.position.set(cxw, 0, czw); g.add(v); }
  else if (ch.esp === 'arcos') {
    for (let q = 0; q < 10; q++) {
      const def = PROTOS_ARCOS[(r() * PROTOS_ARCOS.length) | 0], px = ox + blk.i0 * C + 1.3 + r() * (blk.n * C - 2.6), pz = oz + blk.j0 * C + 1.3 + r() * (blk.m * C - 2.6);
      if (ch.obs.some(o => Math.abs(px - o.x) < o.hx + def.hx + .2 && Math.abs(pz - o.z) < o.hz + def.hz + .2)) continue;
      const m = new THREE.Mesh(def.g, mMueble); m.position.set(px, 0, pz); m.rotation.y = r() * 6.28; g.add(m); ch.obs.push({ x: px, z: pz, hx: Math.max(def.hx, def.hz), hz: Math.max(def.hx, def.hz) });
    }
  } else if (ch.esp === 'marcos') {   // dos líneas largas de marcos que se cruzan
    for (let k = 0; k < 9; k++) for (const ax of [0, 1]) {
      if (ax && k === 4) continue;
      const d = (k - 4) * 2.6, fx = ax ? cxw : cxw + d, fz = ax ? czw + d : czw, m = new THREE.Mesh(gMarco, mMueble);
      m.position.set(fx, 0, fz); m.rotation.y = ax ? Math.PI / 2 : 0; g.add(m);
      for (const sg of [-.7, .7]) ch.obs.push(ax ? { x: fx + sg, z: fz, hx: .1, hz: .15 } : { x: fx, z: fz + sg, hx: .15, hz: .1 });
    }
  }
  if (esDest && DEST.tipo === 'salida' && !lista.length) colocarMuro(1, 'n', ox + 2 * C + C / 2, oz + 3 * C, 0, cx * CH + 2, cz * CH + 3);   // asegura una pared para la puerta
  if (!ch.esp && ((esDest && DEST.tipo === 'salida') || (lista.length && r() < .005))) {   // la puerta blanca de salida: una cada ~200 chunks (más la del destino)
    const w = lista[(r() * lista.length) | 0], cara = r() < .5 ? 1 : -1, off = (r() - .5) * 1.6, m = new THREE.Mesh(gPuerta, mPuerta);
    const dx = w[2] ? cara * (T / 2) : off, dz = w[2] ? off : cara * (T / 2);
    m.position.set(w[0] + dx, 0, w[1] + dz); m.rotation.y = w[2] ? cara * Math.PI / 2 : (cara > 0 ? 0 : Math.PI); g.add(m);
    ch.salida = { x: w[0] + dx, z: w[1] + dz };
  }
  // Grietas: pequeñas y rarísimas (~1 de cada 250 chunks). Romperlas (E) hoy da un Game Over malo; en el futuro llevarán a otros niveles.
  if (!ch.esp && (cx !== 0 || cz !== 0) && r() < .004) {
    const mat = GRIETAS[(r() * GRIETAS.length) | 0], tam = .55 + r() * .5, m = new THREE.Mesh(gGar, mat); let gx, gy, gz;
    if (lista.length && r() < .55) {   // en una pared
      const w = lista[(r() * lista.length) | 0], cara = r() < .5 ? 1 : -1, off = (r() - .5) * 2.4; gy = .5 + r() * 1.3;
      if (w[2]) { gx = w[0] + cara * (T / 2 + .012); gz = w[1] + off; m.rotation.y = cara * Math.PI / 2; } else { gx = w[0] + off; gz = w[1] + cara * (T / 2 + .012); m.rotation.y = cara > 0 ? 0 : Math.PI; }
    } else { gx = ox + 3 + r() * (SZ - 6); gz = oz + 3 + r() * (SZ - 6); gy = .014; m.rotation.x = -Math.PI / 2; m.rotation.z = r() * 6.28; }   // en el suelo
    m.scale.set(tam, tam, 1); m.position.set(gx, gy, gz); g.add(m); (ch.grietas = ch.grietas || []).push({ x: gx, y: Math.max(gy, .05), z: gz });
  }
  // Agua de almendras: poquísimas botellas (~1 de cada 35 chunks), nunca en el chunk inicial
  if (r() < .029 && !ch.esp && (cx !== 0 || cz !== 0)) for (let q = 0; q < 6; q++) {
    const px = ox + 2 + r() * (SZ - 4), pz = oz + 2 + r() * (SZ - 4);
    if (choca(px, pz, .3) || ch.obs.some(o => Math.abs(px - o.x) < o.hx + .3 && Math.abs(pz - o.z) < o.hz + .3)) continue;
    const m = new THREE.Mesh(gBotella, mBotella), ol = new THREE.Mesh(gBotella, mContorno);
    m.position.set(px, 0, pz); ol.position.set(px, 0, pz); ol.scale.setScalar(1.18); ol.visible = false; g.add(m, ol); (ch.bot = ch.bot || []).push({ x: px, z: pz, m, o: ol, ch }); break;
  }
  // Manchas ocasionales: pocas y distintas entre sí (la mayoría de las paredes y del suelo quedan limpios)
  for (let q = ch.esp ? 0 : r() < .35 ? (r() < .25 ? 2 : 1) : 0; q > 0 && lista.length; q--) {
    const w = lista[(r() * lista.length) | 0], mat = MANCHAS[(r() * MANCHAS.length) | 0], tp = mat.userData.tipo, cara = r() < .5 ? 1 : -1, off = (r() - .5) * 2, tam = 1.1 + r() * 1.5, alto = tam * (.7 + r() * .6);
    const m = new THREE.Mesh(gGar, mat); m.scale.set(tam * (r() < .5 ? 1 : -1), alto, 1);
    const y = tp === 0 ? H - alto / 2 : tp === 1 ? .5 + r() * .5 : 1 + r() * 1.2;   // chorreones desde el techo; humedad cerca del suelo
    if (tp !== 0) m.rotation.z = (r() - .5) * 1.2;
    if (w[2]) { m.position.set(w[0] + cara * (T / 2 + .015), y, w[1] + off); m.rotation.y = cara * Math.PI / 2; }
    else { m.position.set(w[0] + off, y, w[1] + cara * (T / 2 + .015)); m.rotation.y = cara > 0 ? 0 : Math.PI; }
    g.add(m);
  }
  if (!ch.esp && r() < .1) {   // en el suelo, casi ninguna
    const m = new THREE.Mesh(gMancha, MANCHAS[[1, 3, 5, 7, 9][(r() * 5) | 0]]), tam = 1.2 + r() * 1.8;
    m.scale.set(tam, 1, tam * (.7 + r() * .6)); m.rotation.y = r() * 6.28; m.position.set(ox + 3 + r() * (SZ - 6), .012, oz + 3 + r() * (SZ - 6)); g.add(m);
  }
  // Garabato con rotulador en una pared: no en todos los chunks y como mucho uno por chunk (así quedan bastante separados)
  if (!ch.esp && lista.length && r() < .32) {
    const w = lista[(r() * lista.length) | 0], cara = r() < .5 ? 1 : -1, off = (r() - .5) * 1.6, ancho = 1.8 + r() * .8, y = 1.2 + r() * .7;
    const m = new THREE.Mesh(gGar, new THREE.MeshLambertMaterial({ map: crearGarabato(), transparent: true, depthWrite: false }));
    m.scale.set(ancho, ancho / 2, 1); m.userData.graf = true; m.rotation.z = (r() - .5) * .1;
    if (w[2]) { m.position.set(w[0] + cara * (T / 2 + .02), y, w[1] + off); m.rotation.y = cara * Math.PI / 2; }
    else { m.position.set(w[0] + off, y, w[1] + cara * (T / 2 + .02)); m.rotation.y = cara > 0 ? 0 : Math.PI; }
    g.add(m);
  }
  // Maniquíes glitcheados: atraviesan suelo, pared o techo
  const n = ch.esp ? 0 : (r() < Math.min(.95, .45 * estado.MODO.entid) ? 1 : 0) + (r() < Math.min(.95, .1 * estado.MODO.entid) ? 1 : 0);
  for (let k = 0; k < n; k++) {
    const m = crearManiqui(r), v = (r() * 3) | 0, px = ox + 3 + r() * (SZ - 6), pz = oz + 3 + r() * (SZ - 6);
    if (v === 0) { m.position.set(px, -.5 - r() * .5, pz); m.rotation.set((r() - .5) * .8, r() * 6.28, (r() - .5) * .6); }       // hundido en el suelo
    else if (v === 1 && lista.length) { const w = lista[(r() * lista.length) | 0]; m.position.set(w[0] + (w[2] ? 0 : (r() - .5) * 2.4), 0, w[1] + (w[2] ? (r() - .5) * 2.4 : 0)); m.rotation.set((r() < .5 ? -.35 : .35), w[2] ? Math.PI / 2 : 0, 0); } // saliendo de la pared
    else { m.position.set(px, H + .7, pz); m.rotation.set(Math.PI, r() * 6.28, 0); }                                              // colgando del techo
    g.add(m); ch.mani.push({ o: m, x: m.position.x, y: m.position.y, z: m.position.z });
  }

  // Objetos de oficina glitcheados (no-clip): hundidos en el suelo o asomando de una pared; vibran y parpadean como los maniquíes
  if (!ch.esp && (cx !== 0 || cz !== 0)) for (let q = r() < .25 ? (r() < .3 ? 2 : 1) : 0; q > 0; q--) {
    const def = PROTOS[(r() * PROTOS.length) | 0]; if (!def.g.boundingBox) def.g.computeBoundingBox();
    const hh = def.g.boundingBox.max.y, m = new THREE.Mesh(def.g, mMueble), mx = Math.max(def.hx, def.hz); m.rotation.order = 'YXZ'; m.userData.prop = true;
    let px, pz, py, hx = mx, hz = mx;
    if (lista.length && r() < .55) {   // saliendo de una pared: casi todo dentro, el frente asoma inclinado hacia fuera
      const w = lista[(r() * lista.length) | 0], cara = r() < .5 ? 1 : -1, off = (r() - .5) * 2, sh = Math.max(.02, def.hz - .13), tilt = .08 + r() * .35;
      py = (r() - .3) * .5;
      if (w[2] === 0) { px = w[0] + off; pz = w[1] + cara * sh; m.rotation.set(tilt, cara > 0 ? 0 : Math.PI, (r() - .5) * .3); hx = def.hx; hz = def.hz; }
      else { px = w[0] + cara * sh; pz = w[1] + off; m.rotation.set(tilt, cara * Math.PI / 2, (r() - .5) * .3); hx = def.hz; hz = def.hx; }
    } else {                            // hundido en el suelo, torcido
      px = ox + 3 + r() * (SZ - 6); pz = oz + 3 + r() * (SZ - 6); py = -hh * (.25 + r() * .45);
      m.rotation.set((r() - .5) * .9, r() * 6.28, (r() - .5) * .7);
    }
    m.position.set(px, py, pz); g.add(m); ch.obs.push({ x: px, z: pz, hx, hz }); ch.mani.push({ o: m, x: px, y: py, z: pz });
  }

  iw.count = nw; iw.instanceMatrix.needsUpdate = true; if (nw) g.add(iw);
  iw2.count = n2; iw2.instanceMatrix.needsUpdate = true; if (n2) g.add(iw2);
  ia.count = na; ia.instanceMatrix.needsUpdate = true; if (na) g.add(ia);
  il.count = nl; if (nl) { il.instanceMatrix.needsUpdate = true; il.instanceColor.needsUpdate = true; g.add(il); }
  scene.add(g); chunks.set(cx + ',' + cz, ch);
}
export function destruirChunk(key, ch) {
  scene.remove(ch.g);
  ch.g.traverse(o => { if (o.isInstancedMesh && o.dispose) o.dispose(); if (o.userData.graf) { o.material.map.dispose(); o.material.dispose(); } });
  ch.claves.forEach(k => muros.delete(k));
  chunks.delete(key); estado.mut++;   // el espacio "olvida" lo que dejas atrás
}
export function actualizarChunks(pcx, pcz, limite) {
  for (const [key, ch] of chunks) if (Math.max(Math.abs(ch.cx - pcx), Math.abs(ch.cz - pcz)) > R + 1) destruirChunk(key, ch);
  let n = 0;
  for (let d = 0; d <= R; d++) for (let a = -d; a <= d; a++) for (let b = -d; b <= d; b++)
    if (Math.max(Math.abs(a), Math.abs(b)) === d && n < limite && !chunks.has((pcx + a) + ',' + (pcz + b))) { crearChunk(pcx + a, pcz + b); n++; }
}

// ================= COLISIONES =================
export function choca(x, z, rad) {
  const ci = Math.floor(x / C), cj = Math.floor(z / C);
  for (let i = ci - 1; i <= ci + 2; i++) for (let j = cj - 1; j <= cj + 2; j++) {
    if (muros.has('n,' + i + ',' + j) && Math.abs(x - (i * C + C / 2)) < C / 2 + T / 2 + rad && Math.abs(z - j * C) < T / 2 + rad) return true;
    if (muros.has('w,' + i + ',' + j) && Math.abs(x - i * C) < T / 2 + rad && Math.abs(z - (j * C + C / 2)) < C / 2 + T / 2 + rad) return true;
  }
  const pcx = Math.floor(x / SZ), pcz = Math.floor(z / SZ);
  for (let a = pcx - 1; a <= pcx + 1; a++) for (let b = pcz - 1; b <= pcz + 1; b++) {
    const ch = chunks.get(a + ',' + b);
    if (ch) for (const o of ch.obs) if (Math.abs(x - o.x) < o.hx + rad && Math.abs(z - o.z) < o.hz + rad) return true;
  }
  return false;
}
// Chunks cargados, zonas oscuras (luz ambiente y niebla)
export function actualizarMundo(dt) {
  const pcx = Math.floor(P.x / SZ), pcz = Math.floor(P.z / SZ);
  actualizarChunks(pcx, pcz, 1);   // máx. 1 chunk nuevo por fotograma

  // Zonas oscuras: la luz ambiente y la niebla se apagan al entrar en un chunk "muerto"
  const cur = chunks.get(pcx + ',' + pcz);
  estado.osc += (((cur && cur.oscura) ? 1 : (cur && cur.fogT) || 0) - estado.osc) * Math.min(1, dt * 1.2);
  ambiente.intensity = .4 - .37 * estado.osc;
  scene.fog.color.copy(FOG_CLARA).lerp(FOG_OSCURA, estado.osc); scene.fog.density = .05 + .025 * estado.osc;
  renderer.setClearColor(scene.fog.color);
}
