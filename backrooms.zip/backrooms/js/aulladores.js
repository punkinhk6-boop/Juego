// ENTIDAD SONORA — los aulladores: solo se oyen, nunca se ven.
import { estado } from './config.js';
import { P } from './player.js';
import { AUD, bucleVoz, panDe, pararVoz, prepararVoz, vCarrera } from './audio.js';
import { VOL } from './ajustes.js';

// Estados: 0 = en reposo, 1 = fuente lejana que aúlla, 2 = "algo" corre hacia ti
export const ent = { e: 0, t: 18 + Math.random() * 15, x: 0, z: 0, cx: 0, cz: 0, vida: 0, esc: 0, prox: 0, dprev: 0, sil: 0 };
// Un aullido: el tono sube, se sostiene y cae lentamente
function aullar(dur) {
  if (AUD.aull.length) {   // aullido real: pasa por la cadena de la voz (filtro, panorama y volumen según la distancia)
    const t = estado.ctx.currentTime, s = estado.ctx.createBufferSource(); let i = (Math.random() * AUD.aull.length) | 0;
    if (i === estado.voz.ult && AUD.aull.length > 1) i = (i + 1) % AUD.aull.length;
    try { estado.voz.src && estado.voz.src.stop(); } catch (e) {}
    estado.voz.mezcla.gain.value = 0; estado.voz.env.gain.cancelScheduledValues(t); estado.voz.env.gain.setValueAtTime(1, t);
    s.buffer = AUD.aull[i]; s.connect(estado.voz.lp); s.start(t); estado.voz.src = s; estado.voz.ult = i; return;
  }
  const t = estado.ctx.currentTime, f0 = 260 + Math.random() * 100, pico = f0 * (1.6 + Math.random() * .4);
  [estado.voz.o1, estado.voz.o2].forEach(o => { const f = o.frequency; f.cancelScheduledValues(t); f.setValueAtTime(f0, t); f.linearRampToValueAtTime(pico, t + dur * .3); f.linearRampToValueAtTime(pico * .96, t + dur * .6); f.linearRampToValueAtTime(f0 * .75, t + dur); });
  const g = estado.voz.env.gain; g.cancelScheduledValues(t); g.setValueAtTime(0, t); g.linearRampToValueAtTime(.45, t + dur * .3); g.linearRampToValueAtTime(.36, t + dur * .7); g.linearRampToValueAtTime(0, t + dur);
}
// Una pata golpeando el suelo (golpe grave que cae de tono)
export function pisada(t, vol, pan, k = 1) {
  vol *= k;
  const o = estado.ctx.createOscillator(), g = estado.ctx.createGain(), p = estado.ctx.createStereoPanner();
  o.type = 'triangle'; o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(45, t + .09);
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.001, t + .12); p.pan.value = pan;
  o.connect(g).connect(p).connect(estado.ctx.destination); o.start(t); o.stop(t + .13);
}
export function aulladores(dt, corre) {
  if (!estado.ctx) return;
  if (!estado.voz) prepararVoz();
  const n = ent, ahora = estado.ctx.currentTime;
  n.sil -= dt; n.t -= dt * estado.MODO.entid;
  if (n.e === 0) {
    if (n.t > 0) return;
    // Aparece una "fuente" lejana en una dirección al azar (no hay nada visible)
    const a = Math.random() * 6.283, d = 55 + Math.random() * 25;
    n.x = P.x + Math.sin(a) * d; n.z = P.z + Math.cos(a) * d; n.vida = 60 + Math.random() * 50; n.e = 1; n.t = 0;
  }
  const dx = n.x - P.x, dz = n.z - P.z, dF = Math.hypot(dx, dz);
  // La voz sale de la fuente: cuanto más cerca, más fuerte y más nítida
  estado.voz.pan.pan.value = panDe(dx, dz); estado.voz.out.gain.value = (AUD.aull.length ? .9 / (1 + dF / 14) : 1.3 / (1 + dF / 12)) * VOL.ent; estado.voz.lp.frequency.value = AUD.aull.length ? 1500 + 6000 / (1 + dF / 12) : 700 + 3500 / (1 + dF / 10);
  if (n.e === 1) {
    n.vida -= dt;
    if (n.vida <= 0) { n.e = 0; n.t = 25 + Math.random() * 35; return; }
    if (n.t <= 0) { aullar(3.5 + Math.random() * 2); n.t = dF < 30 ? 5 + Math.random() * 5 : 12 + Math.random() * 16; }   // más seguido si te acercas
    if (dF < 20) { n.e = 2; n.cx = n.x; n.cz = n.z; n.esc = 0; n.prox = 0; aullar(4.5); }                                  // algo empieza a correr hacia ti
  } else {
    // Persecución fantasma: solo se oye, y se acerca en línea recta
    const ex = P.x - n.cx, ez = P.z - n.cz, dC = Math.hypot(ex, ez) || 1;
    n.cx += ex / dC * 4.2 * dt; n.cz += ez / dC * 4.2 * dt;
    estado.par = Math.min(1, estado.par + dt * .04 * Math.max(0, 1 - dC / 22) * estado.MODO.parPasos);   // los pasos cerca ponen nervioso (los aullidos no)
    n.esc = (corre && dF > n.dprev + .01) ? Math.min(2, n.esc + dt) : Math.max(0, n.esc - dt * .4);   // huir corriendo la apaga
    if (n.esc >= 1.5 || dC < 2.2) {
      // Deja de sonar (o "llega" a ti y el mundo se queda en silencio, sin que aparezca nada)
      estado.voz.env.gain.cancelScheduledValues(ahora); estado.voz.env.gain.setTargetAtTime(0, ahora, .15);
      if (dC < 2.2) n.sil = 3;
      pararVoz(vCarrera);
      n.e = 0; n.t = 40 + Math.random() * 40;
    } else if (AUD.corr) {   // carrera real: más fuerte y algo más rápida cuanto más cerca
      bucleVoz(vCarrera, AUD.corr, .85 * Math.min(1, 7 / (dC + 3)) * (1 - n.esc / 1.5), panDe(n.cx - P.x, n.cz - P.z), 1 + .25 * (1 - Math.min(1, dC / 20)));
    } else if (ahora >= n.prox) {
      const vol = Math.min(.6, 4 / (dC + 3)) * (1 - n.esc / 1.5), T = .3 + .14 * Math.min(1, dC / 20), pan = panDe(n.cx - P.x, n.cz - P.z);
      [0, .2, .5, .7].forEach((f, i) => pisada(ahora + f * T, vol * (i % 2 ? .75 : 1), pan, VOL.ent));   // galope: más rápido y fuerte al acercarse
      n.prox = ahora + T;
    }
  }
  n.dprev = dF;
}
