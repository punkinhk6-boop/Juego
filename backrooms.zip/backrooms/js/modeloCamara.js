// MODELO 3D de la cámara de mano.
import * as THREE from 'three';
import { Bx, Cy, mMueble, mueble } from './muebles.js';

export const gCamara = mueble([[Bx(.13, .09, .2), 0x2b2d30, 0, 0, 0], [Cy(.035, .04, .09, 12), 0x161718, 0, 0, -.14, 0, Math.PI / 2], [Bx(.04, .05, .07), 0x3a3d40, 0, .065, .04], [Bx(.12, .015, .1), 0x1d1e20, 0, .052, 0], [Bx(.03, .02, .02), 0xc0392b, .05, .035, -.1]]);
export const camModelo = new THREE.Mesh(gCamara, mMueble);
