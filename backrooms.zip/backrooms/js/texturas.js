// TEXTURAS PROCEDURALES — muros, suelo y techo dibujados en canvas.
import * as THREE from 'three';
import { SZ } from './config.js';

// ================= TEXTURAS PROCEDURALES (canvas) =================
export function lienzo(w, h, dibujar, rx, ry) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  dibujar(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry); t.anisotropy = 4;
  return t;
}
export const ruido = (x, w, h, n, col) => { for (let i = 0; i < n; i++) { x.fillStyle = col(); x.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 2, 1 + Math.random() * 2); } };
export const manchas = (x, w, h, n, rgb, a) => {
  for (let i = 0; i < n; i++) {
    const px = Math.random() * w, py = Math.random() * h, r = 10 + Math.random() * 40, g = x.createRadialGradient(px, py, 0, px, py, r);
    g.addColorStop(0, `rgba(${rgb},${a})`); g.addColorStop(1, `rgba(${rgb},0)`); x.fillStyle = g; x.fillRect(px - r, py - r, r * 2, r * 2);
  }
};
// Papel tapiz amarillo: rayas verticales + humedad
export const texMuro = lienzo(256, 256, (x, w, h) => {
  x.fillStyle = '#b8a85f'; x.fillRect(0, 0, w, h);   // amarillo menos chillón y más opaco
  for (let i = 0; i < w; i += 16) { x.fillStyle = 'rgba(108,96,42,.2)'; x.fillRect(i, 0, 6, h); }
  ruido(x, w, h, 1800, () => `rgba(85,74,30,${Math.random() * .25})`);
}, 3, 1.5);
// Alfombra sucia y húmeda
export const texSuelo = lienzo(512, 512, (x, w, h) => {
  x.fillStyle = '#7f7541'; x.fillRect(0, 0, w, h);   // un poco más clara
  // Fibras de alfombra: miles de motas y trazos cortos de varios tonos + hileras de pelo; sin manchas
  for (let i = 0; i < 26000; i++) {
    const t = Math.random(), a = .25 + Math.random() * .4;
    x.fillStyle = t < .45 ? `rgba(48,42,16,${a})` : t < .8 ? `rgba(138,126,68,${a})` : `rgba(164,150,86,${a * .7})`;
    x.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 1.5, 1 + Math.random() * 3);
  }
  for (let y = 0; y < h; y += 3) { x.fillStyle = 'rgba(0,0,0,.05)'; x.fillRect(0, y, w, 1); }
}, SZ / 2, SZ / 2);
// Techo de losetas
export const texTecho = lienzo(128, 128, (x, w, h) => {
  x.fillStyle = '#d6cd9c'; x.fillRect(0, 0, w, h); x.strokeStyle = '#918858'; x.lineWidth = 4; x.strokeRect(0, 0, w, h);
  ruido(x, w, h, 900, () => `rgba(70,60,20,${Math.random() * .3})`);
}, SZ / 2, SZ / 2);
