// CONFIG — constantes del juego (tamaños, semilla, táctil) y `estado`, el objeto con las variables globales que cambian durante la partida.

// ================= CONFIGURACIÓN =================
export const C = 4, H = 3, T = 0.3;  // tamaño de celda, altura del techo, grosor de pared
export const CH = 6, SZ = CH * C;  // celdas por chunk y tamaño del chunk (24 u.)
export const R = 2;  // radio de chunks cargados alrededor del jugador
export const SEMILLA = (Math.random() * 1e9) | 0;
export const TACTIL = matchMedia('(pointer:coarse)').matches;  // true en móviles/tabletas (Android)

// ============ ESTADO COMPARTIDO ============
// Variables que cambian durante la partida y que usan varios módulos.
// Un módulo no puede reasignar una variable importada, así que viven como propiedades de este objeto: estado.par, estado.hid...
export const estado = {
  // --- config ---
  mut: 0,   // "mutaciones": cada chunk destruido cambia el futuro del laberinto
  // --- grietas ---
  calmando: false,
  hintCalma: false,
  rompiendo: 0,
  // --- player ---
  activo: false,
  muerto: false,
  correT: false,   // botón CORRER (interruptor)
  par: 0,
  flAnt: '',
  cayendo: false,
  // --- audio ---
  hum: null,
  ctx: null,
  voz: null,
  // --- sombra ---
  spr: null,
  // --- camara ---
  zoom: 0,
  zoomObj: 0,
  desenf: 0,
  kick: 0,
  tfase: 0,
  runAmt: 0,
  movAhora: false,
  corrAhora: false,
  camOn: false,
  camObj: 0,
  camPos: 0,
  nv: false,
  bat: 1,
  estatica: 0,
  modeloMundo: false,
  // --- hidratacion ---
  hid: 1,   // hid: 1 = hidratado, 0 = deshidratado; sed0: segundos seguidos sin agua
  sed0: 0,
  fatiga: 0,
  objetivo: null,
  objPuerta: false,
  objGrieta: false,
  // --- inventario ---
  invSel: 0,
  avisoT: 0,
  // --- medidor ---
  medObj: 0,
  medPos: 0,
  // --- modos ---
  MODO: undefined,
  modoSel: 'canon',
  // --- ajustes ---
  BRI: 1,
  // --- main ---
  tiempo: 0,
  bob: 0,
  // --- world ---
  osc: 0,
};
