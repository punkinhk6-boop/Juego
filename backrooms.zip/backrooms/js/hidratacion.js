// HIDRATACIÓN — sed, botellas de agua de almendras y qué objeto estás apuntando.
import * as THREE from 'three';
import { estado, TACTIL } from './config.js';
import { Cy, mueble } from './muebles.js';
import { btnBeber, elPrompt } from './dom.js';
import { morir, P } from './player.js';
import { chunks } from './world.js';

// ================= HIDRATACIÓN y AGUA DE ALMENDRAS =================
// hid: 1 = hidratado, 0 = deshidratado; sed0: segundos seguidos sin agua
export function hidratacion(dt, corre) {
  estado.fatiga = Math.max(0, Math.min(1, estado.fatiga + dt * (corre ? 1 / 40 : -1 / 25)));   // correr mucho seguido te cansa: la sed baja cada vez más rápido
  estado.hid = Math.max(0, estado.hid - dt * (corre ? 1 / 380 * (1 + 1.8 * estado.fatiga) * estado.MODO.sedCorr : 1 / 720 * estado.MODO.sedCam));   // caminando baja muy despacio
  estado.sed0 = estado.hid <= 0 ? estado.sed0 + dt : 0;
  if (estado.sed0 > 25) morir('sed');                                   // sin agua no puedes correr y a los 25 s mueres
}
// Botella: azul con tapa gris. Se unen sus piezas en una geometría; el contorno es el mismo modelo, más grande y por dentro (solo se ve al apuntarle)
export const gBotella = mueble([[Cy(.055, .055, .22), 0x3f7fc4, 0, .11, 0], [Cy(.03, .055, .05), 0x3f7fc4, 0, .245, 0], [Cy(.028, .028, .04), 0x8a8d90, 0, .29, 0]]);
export const mBotella = new THREE.MeshLambertMaterial({ vertexColors: true, emissive: 0x0a1a2a }), mContorno = new THREE.MeshBasicMaterial({ color: 0xcfeaff, side: THREE.BackSide });
export function botellas() {
  // Botella o puerta a la que apuntas: cerca y casi en el centro de la vista
  const fx = -Math.sin(P.yaw) * Math.cos(P.pitch), fy = Math.sin(P.pitch), fz = -Math.cos(P.yaw) * Math.cos(P.pitch); let mejor = null, md = 2.6, puerta = false, grieta = false;
  for (const ch of chunks.values()) {
    for (const b of ch.bot || []) {
      const dx = b.x - P.x, dy = (b.yc || .15) - 1.65, dz = b.z - P.z, d = Math.hypot(dx, dy, dz);
      if (d < md && (dx * fx + dy * fy + dz * fz) / d > .965) { md = d; mejor = b; }
    }
    if (ch.salida) { const dx = ch.salida.x - P.x, dy = 1.05 - 1.65, dz = ch.salida.z - P.z, d = Math.hypot(dx, dy, dz); if (d < 3 && (dx * fx + dy * fy + dz * fz) / d > .93) puerta = true; }
    for (const g of ch.grietas || []) { const dx = g.x - P.x, dy = g.y - 1.65, dz = g.z - P.z, d = Math.hypot(dx, dy, dz); if (d < 2.2 && (dx * fx + dy * fy + dz * fz) / d > .93) grieta = true; }
  }
  if (mejor !== estado.objetivo) { if (estado.objetivo) estado.objetivo.o.visible = false; estado.objetivo = mejor; if (mejor) mejor.o.visible = true; }
  estado.objPuerta = puerta; estado.objGrieta = grieta && !puerta;
  const hay = estado.objetivo || puerta || estado.objGrieta;
  elPrompt.textContent = puerta ? '[E] ABRIR LA PUERTA' : estado.objGrieta ? '[E] ROMPER LA GRIETA' : estado.objetivo && estado.objetivo.tipo === 'bateria' ? '[E] AGARRAR BATERÍA DE CÁMARA' : '[E] AGARRAR AGUA DE ALMENDRAS'; btnBeber.textContent = puerta ? 'ABRIR' : estado.objGrieta ? 'ROMPER' : 'AGARRAR';
  elPrompt.style.display = hay && !TACTIL ? 'block' : 'none'; btnBeber.style.display = hay && TACTIL ? 'flex' : 'none';
}
