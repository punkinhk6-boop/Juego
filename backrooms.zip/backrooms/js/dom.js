// DOM — referencias a los elementos del HTML (HUD, botones, menús). Se evalúa sin dependencias.

export const btnZoomEl = document.getElementById('btnZoom');
export const menu = document.getElementById('menu');
export const tactil = document.getElementById('touch'), joy = document.getElementById('joy'), knob = document.getElementById('knob');
export const elPar = document.getElementById('par'), elBanda = document.getElementById('banda'), elHud = document.getElementById('hud'), elBarra = document.getElementById('barra'), elBT = document.getElementById('barraT'), elBR = document.getElementById('barraR');
export const elHid = document.getElementById('barra2'), elHT = document.getElementById('barra2T'), elHR = document.getElementById('barra2R');
export const elPrompt = document.getElementById('prompt'), btnBeber = document.getElementById('btnBeber');
export const elBat = document.getElementById('hudBat'), elFecha = document.getElementById('hudFecha'), elSub = document.getElementById('subt'), elNegro = document.getElementById('negro'), elP1 = document.getElementById('pp1'), elP2 = document.getElementById('pp2'), elSaltar = document.getElementById('saltar');
export const btnCamEl = document.getElementById('btnCam');
export const elNav = document.getElementById('navm'), elSelM = document.getElementById('mSel'), elIzq = document.getElementById('mIzq'), elDer = document.getElementById('mDer'), elBlanco = document.getElementById('blanco'), pcIn = document.getElementById('pcIn');
