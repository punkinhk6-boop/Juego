// MANCHAS OCASIONALES (decals) en paredes.
import * as THREE from 'three';

// ================= MANCHAS OCASIONALES (decals) =================
// Pocas y distintas entre sí: la pared y el suelo base están limpios. Hay 10 variantes que además se colocan con tamaño/giro/reflejo al azar.
function texMancha(tipo) {
  const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d'), R = Math.random;
  const blob = (cx, cy, r, rgb, a) => { const g = x.createRadialGradient(cx, cy, 0, cx, cy, r); g.addColorStop(0, `rgba(${rgb},${a})`); g.addColorStop(.6, `rgba(${rgb},${a * .45})`); g.addColorStop(1, `rgba(${rgb},0)`); x.fillStyle = g; x.beginPath(); x.arc(cx, cy, r, 0, 6.29); x.fill(); };
  if (tipo === 0) {          // chorreones de humedad que caen desde el techo
    for (let k = 0, n = 2 + ((R() * 4) | 0); k < n; k++) { const px = 40 + R() * 176, L = 80 + R() * 160, w = 6 + R() * 16, g = x.createLinearGradient(0, 0, 0, L); g.addColorStop(0, 'rgba(70,52,14,.38)'); g.addColorStop(1, 'rgba(70,52,14,0)'); x.fillStyle = g; x.fillRect(px - w / 2, 0, w, L); blob(px, L, w * .9, '70,52,14', .3); }
  } else if (tipo === 1) {   // mancha de humedad irregular (círculos solapados)
    for (let k = 0, n = 4 + ((R() * 6) | 0); k < n; k++) blob(80 + R() * 96, 80 + R() * 96, 30 + R() * 50, '75,56,16', .22);
  } else if (tipo === 2) {   // roces y marcas oscuras
    x.lineCap = 'round';
    for (let k = 0, n = 3 + ((R() * 5) | 0); k < n; k++) { x.strokeStyle = `rgba(50,38,12,${.12 + R() * .2})`; x.lineWidth = 2 + R() * 6; const px = 30 + R() * 190, py = 30 + R() * 190; x.beginPath(); x.moveTo(px, py); x.lineTo(px + (R() - .5) * 120, py + (R() - .5) * 80); x.stroke(); }
  } else {                   // salpicaduras pequeñas
    for (let k = 0, n = 8 + ((R() * 14) | 0); k < n; k++) blob(30 + R() * 196, 30 + R() * 196, 3 + R() * 14, '60,45,12', .35);
  }
  return new THREE.CanvasTexture(c);
}
export const MANCHAS = Array.from({ length: 10 }, (_, i) => { const m = new THREE.MeshLambertMaterial({ map: texMancha(i % 4), transparent: true, depthWrite: false }); m.userData.tipo = i % 4; return m; });
export const gMancha = new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2);
