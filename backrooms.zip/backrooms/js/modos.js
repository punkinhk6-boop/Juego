// DIFICULTADES — Fácil / Canon / Liminal y cómo se aplican al empezar.
import { estado } from './config.js';
import { actualizarChunks, chunks, destruirChunk } from './world.js';
import { DEST, nuevoDestino } from './medidor.js';

// ================= DIFICULTADES =================
const MODOS = {
  facil:   { medidor: true,  parSombra: .6,  parBase: 1,   parLuz: .6,  parPasos: .6,  sedCam: .7, sedCorr: .7,  bat: 1.35, entid: .55 },
  canon:   { medidor: false, parSombra: 1,   parBase: 1,   parLuz: 1,   parPasos: 1,   sedCam: 1,  sedCorr: 1,   bat: 1,    entid: 1 },
  liminal: { medidor: false, parSombra: 1.6, parBase: 1.3, parLuz: 1.5, parPasos: 1.5, sedCam: 1,  sedCorr: 1.6, bat: 1,    entid: 1.7 }
};
estado.MODO = MODOS.canon;
export function aplicarModo() {   // se aplica al empezar la partida; el mundo se regenera con las reglas del modo
  if (document.body.classList.contains('enpartida')) return;
  document.body.classList.add('enpartida'); estado.MODO = MODOS[estado.modoSel];
  if (estado.MODO.medidor) Object.assign(DEST, nuevoDestino(), { activo: true, t: 110 + Math.random() * 20 }); else DEST.activo = false;
  for (const [k, ch] of [...chunks]) destruirChunk(k, ch);
  actualizarChunks(0, 0, 99);
}

// ============ EVENTOS ============
// Se registran desde main.js (en el mismo orden que tenían en el script original).
export function eventosModos() {
  document.querySelectorAll('.modo').forEach(el => el.onclick = e => { e.stopPropagation(); estado.modoSel = el.dataset.m; document.querySelectorAll('.modo').forEach(o => o.classList.toggle('sel', o === el)); });
}
