// CÁMARA DE VÍDEO — zoom con servo, ojo de pez, visión nocturna, estática, batería, fecha y medidor/cámara en mano.
import { estado } from './config.js';
import { cam, scene } from './escena.js';
import { btnCamEl, btnZoomEl, elBat, elFecha } from './dom.js';
import { abrirInv, aviso, beberInv, interactuar, invAbierto, renderInv, tirarInv } from './inventario.js';
import { postMat } from './shaders.js';
import { camModelo } from './modeloCamara.js';
import { cine } from './cinematica.js';
import { ambienteLoop, respiracion } from './sonidoAmbiente.js';
import { calcMed, dibujarMed, poseMed } from './medidor.js';
import { VOL } from './ajustes.js';
import { M, menuProps, menuUpdate } from './menu.js';

// ================= CÁMARA: zoom con servo, pulso y balanceo al correr =================
function zoomear(on) {
  if (!estado.camOn) { estado.calmando = on && !cine.act; return; }   // sin la cámara en el ojo (baja o con el medidor) el botón sirve para calmarse
  if (on === (estado.zoomObj === 1)) return;                  // con la cámara puesta es el zoom
  estado.zoomObj = on ? 1 : 0; estado.desenf = 1;   // al cambiar el zoom la imagen se desenfoca y luego vuelve a enfocarse
  if (estado.ctx) { const t = estado.ctx.currentTime, o = estado.ctx.createOscillator(), g = estado.ctx.createGain(); o.type = 'sawtooth'; o.frequency.setValueAtTime(on ? 160 : 260, t); o.frequency.linearRampToValueAtTime(on ? 270 : 150, t + .45); g.gain.setValueAtTime(.012, t); g.gain.linearRampToValueAtTime(0, t + .5); o.connect(g); g.connect(estado.ctx.destination); o.start(t); o.stop(t + .5); }   // zumbido del motor del zoom
}
// Modelo de la cámara (en la mano, abajo a la derecha; al ponérsela en el ojo desaparece y entra el visor)
scene.add(cam);
cam.add(camModelo);
let expo = 1, expKick = 0, fecha = '', batT = 0;
const MESES = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC'];
function genFecha() {   // fechas normales, imposibles o sin sentido
  const R = Math.random, p2 = n => String(n).padStart(2, '0'), u = R(), dia = 1 + ((R() * 28) | 0), mes = (R() * 12) | 0, anio = 1983 + ((R() * 44) | 0), hh = (R() * 24) | 0, mm = (R() * 60) | 0;
  if (u < .30) return `${p2(dia)}/${p2(mes + 1)}/${anio}  ${p2(hh)}:${p2(mm)}`;
  if (u < .48) return `${MESES[mes]} ${p2(dia)} ${anio}  ${p2(hh % 12 || 12)}:${p2(mm)} ${hh < 12 ? 'AM' : 'PM'}`;
  if (u < .62) return `${p2(30 + ((R() * 3) | 0))}/${p2(13 + ((R() * 5) | 0))}/${anio}  ${p2(24 + ((R() * 7) | 0))}:${p2(60 + ((R() * 39) | 0))}`;   // día, mes y hora imposibles
  if (u < .72) return `FEB 30 ${2030 + ((R() * 3000) | 0)}  ${p2(hh)}:${p2(mm)}`;
  return ['??/??/????  --:--', '99/99/9999  99:99', '-1/-1/-1  -1:-1', '▒▒/▒▒/▒▒▒▒  ▒▒:▒▒', 'ERR 0x0000  ∞:∞', '00/00/0000  00:00', `${p2(hh)}:${p2(mm)}  DÍA ${(R() * 400) | 0} DESPUÉS`, 'HOY  AYER  MAÑANA'][(R() * 8) | 0];
}
export function estaticaSonido(dur, vol) {
  if (!estado.ctx) return; const b = estado.ctx.createBuffer(1, Math.floor(estado.ctx.sampleRate * dur), estado.ctx.sampleRate), d = b.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  const s = estado.ctx.createBufferSource(), g = estado.ctx.createGain(); s.buffer = b; g.gain.setValueAtTime(vol * VOL.jug, estado.ctx.currentTime); g.gain.linearRampToValueAtTime(0, estado.ctx.currentTime + dur); s.connect(g); g.connect(estado.ctx.destination); s.start();
}
export function ponerCam(on) {   // ponerse (o quitarse) la cámara: mini estática y, al ponérsela, fecha nueva
  estado.camOn = on; estado.estatica = on ? 1 : .6; if (on) expKick = .3; estado.calmando = false; document.getElementById('btnZoom').classList.remove('on');
  if (on) { fecha = genFecha(); elFecha.textContent = fecha; estaticaSonido(.3, .06); } else { estado.nv = false; estado.zoomObj = 0; }
}
function alternarCam() {   // la misma tecla/botón alterna entre la cámara y el medidor (solo en modo Fácil)
  if (cine.act) return;
  if (!estado.MODO.medidor) { if (estado.camObj === 1 || estado.camOn) { estado.camObj = 0; ponerCam(false); } else if (estado.bat > 0) estado.camObj = 1; else aviso('SIN BATERÍA'); return; }
  if (estado.camObj === 1 || estado.camOn) { estado.camObj = 0; ponerCam(false); estado.medObj = 1; }                       // la cámara baja y sube el medidor
  else if (estado.medObj === 1) { estado.medObj = 0; if (estado.bat > 0) estado.camObj = 1; else aviso('SIN BATERÍA'); }      // el medidor se guarda y vuelve la cámara
  else if (estado.bat > 0) estado.camObj = 1; else estado.medObj = 1;                                                 // manos vacías (batería agotada)
}
function alternarNV() { if (!estado.camOn) return; estado.nv = !estado.nv; estado.estatica = .4; estaticaSonido(.15, .05); }
export function camaraSistema(dt) {
  if (!cine.act) estado.camPos += (estado.camObj - estado.camPos) * Math.min(1, dt * 6);          // 0 = cámara abajo (en la mano), 1 = en el ojo
  if (!cine.act && estado.camObj === 1 && !estado.camOn && estado.camPos > .93) ponerCam(true);
  estado.estatica = Math.max(0, estado.estatica - dt * 2.2);
  estado.medPos += (estado.medObj - estado.medPos) * Math.min(1, dt * 6); poseMed(); calcMed(dt); if (estado.medPos > .02) dibujarMed(dt);
  const etq = estado.MODO.medidor && !estado.medObj ? 'MEDIDOR' : 'CÁMARA'; if (btnCamEl.textContent !== etq) btnCamEl.textContent = etq;
  const zt = estado.camOn ? 'ZOOM' : 'CALMA'; if (btnZoomEl.textContent !== zt) btnZoomEl.textContent = zt;
  if (estado.camOn && estado.activo && !cine.act) { estado.bat -= dt / (480 * estado.MODO.bat) * (estado.nv ? 2.2 : 1); if (estado.bat <= 0) { estado.bat = 0; estado.camObj = 0; ponerCam(false); aviso('BATERÍA AGOTADA'); } }   // ~8 min de grabación; la visión nocturna gasta más del doble
  if (!estado.modeloMundo) { const e = estado.camPos * estado.camPos * (3 - 2 * estado.camPos); camModelo.position.set(.3 * (1 - e), -.3 + .29 * e, -.55 + .33 * e); camModelo.rotation.set(.25 * (1 - e), -.55 * (1 - e), 0); camModelo.visible = estado.camPos < .96 && estado.medPos < .05 && !M.act; }
  document.body.classList.toggle('sincam', !estado.camOn);
  const U = postMat.uniforms;
  U.uT.value = (performance.now() / 1000) % 1000; U.uBright.value = estado.BRI; expo += (1 + .18 * estado.osc - expo) * Math.min(1, dt * 1.2); expKick = Math.max(0, expKick - dt * .7); U.uExp.value = expo + expKick; U.uNoise.value = .025 * (1 + 3 * Math.max(0, expo - 1)); U.uFish.value = estado.camOn ? 1 : 0; U.uNight.value = estado.nv && estado.camOn ? 1 : 0;
  U.uStatic.value = Math.max(estado.estatica, cine.est || 0); U.uGlitch.value = Math.max(cine.glitch || 0, estado.camOn && estado.par > .7 ? (estado.par - .7) * 2 * Math.random() : 0);
  if ((batT -= dt) <= 0) { batT = .25; const n = Math.ceil(estado.bat * 5); elBat.textContent = '▮'.repeat(n) + '▯'.repeat(5 - n) + ' ' + Math.round(estado.bat * 100) + '%' + (estado.nv ? ' · NV' : ''); elBat.style.color = estado.bat < .2 ? '#ff5a4a' : ''; }
  try { ambienteLoop(dt); respiracion(dt); } catch (e) {}   // ambiente y respiración (un fallo de audio nunca debe romper el dibujo)
  try { if (M.act) menuUpdate(dt); menuProps.visible = M.act; } catch (e) { console.warn(e); }   // menú 3D
}

// ============ EVENTOS ============
// Se registran desde main.js (en el mismo orden que tenían en el script original).
export function eventosCamara() {
  // Escritorio: mantener Z o botón derecho del ratón = zoom; E = beber. Móvil: botones ZOOM y BEBER
  addEventListener('keydown', e => { if (!estado.activo) return; if (e.code === 'KeyZ') zoomear(true); if (e.code === 'KeyC') alternarCam(); if (e.code === 'KeyN') alternarNV(); if (e.code === 'KeyE') (invAbierto() ? beberInv() : interactuar()); if (e.code === 'KeyI') abrirInv(!invAbierto()); if (e.code === 'KeyQ' && invAbierto()) tirarInv(); if (invAbierto() && e.code >= 'Digit1' && e.code <= 'Digit4') { estado.invSel = +e.code.slice(5) - 1; renderInv(); } });
  addEventListener('keyup', e => { if (e.code === 'KeyZ') zoomear(false); });
  document.addEventListener('mousedown', e => { if (estado.activo && e.button === 2) zoomear(true); });
  document.addEventListener('mouseup', e => { if (e.button === 2) zoomear(false); });
  document.getElementById('btnZoom').onpointerdown = e => { e.preventDefault(); zoomear(estado.camOn ? estado.zoomObj === 0 : !estado.calmando); e.currentTarget.classList.toggle('on', estado.camOn ? estado.zoomObj === 1 : estado.calmando); };  // móvil: toca para activar/desactivar
  document.getElementById('btnCam').onpointerdown = e => { e.preventDefault(); alternarCam(); };
  document.getElementById('btnNV').onpointerdown = e => { e.preventDefault(); alternarNV(); };
}
