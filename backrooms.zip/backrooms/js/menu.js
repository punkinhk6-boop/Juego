// MENÚ PRINCIPAL EN 3D — la habitación de la casa abandonada (cámara = jugar, corcho = ajustes, PC, puerta).
import * as THREE from 'three';
import { estado, TACTIL } from './config.js';
import { ambiente, cam, cv, pool } from './escena.js';
import { lienzo, manchas, ruido } from './texturas.js';
import { Bx, K, mMueble, mueble } from './muebles.js';
import { elBlanco, elDer, elIzq, elNav, elNegro, elSelM, menu, pcIn, tactil } from './dom.js';
import { ponerCam } from './camara.js';
import { gCamara } from './modeloCamara.js';
import { casa, cine, CX, CZ } from './cinematica.js';
import { AJ, aplicarAjustes } from './ajustes.js';
import { arrancarAudio, sBip, sBlanco, sMadera, sPapel, sPuerta, sServo, sTecla } from './sonidosMenu.js';

const V3 = (x, y, z) => new THREE.Vector3(x, y, z), d2 = new THREE.Object3D();
export const menuProps = new THREE.Group();
casa.add(menuProps);  // solo se ven en el menú; en la cinemática la habitación está vacía de esto
export const M = { act: true, estado: 'nav', op: 0, dif: 1, t: 0, drag: -1, sl: 0, pcModo: false, pcTexto: '', pcErr: 0, pos: V3(CX, 1.4, CZ + 2.5), look: V3(CX, 1, CZ), fov: 70, p0: null, q0: null, objs: [] };
const NOM = ['JUGAR', 'VOLUMEN', 'BRILLO', 'CONTROLES', 'IDIOMA', 'CRÉDITOS', 'COMPUTADORA', 'SALIR'], NOMD = ['FÁCIL', 'CANON', 'LIMINAL', 'VOLVER'];
// ---- Mesa de madera con la cámara ----
menuProps.add(Object.assign(new THREE.Mesh(mueble([[Bx(1.3, .06, .75), K.mad, 0, .77, 0], [Bx(.07, .77, .07), K.madO, -.58, .385, -.31], [Bx(.07, .77, .07), K.madO, .58, .385, -.31], [Bx(.07, .77, .07), K.madO, -.58, .385, .31], [Bx(.07, .77, .07), K.madO, .58, .385, .31]]), mMueble)).translateX(CX - .2).translateZ(CZ + .9));
const camMesa = new THREE.Mesh(gCamara, mMueble);
camMesa.scale.setScalar(1.5);
camMesa.userData.op = 0;
menuProps.add(camMesa);
const recLed = new THREE.Mesh(new THREE.SphereGeometry(.009, 6, 4), new THREE.MeshBasicMaterial({ color: 0xff2a1a }));
recLed.position.set(0, .075, .06);
camMesa.add(recLed);
function resetCamMesa() { camMesa.position.set(CX - .2, .8675, CZ + .9); camMesa.rotation.set(0, .6, 0); camMesa.updateMatrix(); }
resetCamMesa();
// ---- Pizarrón de corcho con hojas, chinchetas y hilos rojos ----
const BZ = CZ - 2.43, SX = [-1.4, -.7, 0, .7, 1.4], SY = [.05, -.08, .1, -.05, .06], SR = [.05, -.04, .03, -.06, .04];
const texCorcho = lienzo(512, 256, (x, w, h) => { x.fillStyle = '#a97b4a'; x.fillRect(0, 0, w, h); ruido(x, w, h, 6000, () => `rgba(${(60 + Math.random() * 90) | 0},${(40 + Math.random() * 50) | 0},20,${Math.random() * .45})`); }, 3, 1.6);
const corcho = new THREE.Mesh(new THREE.PlaneGeometry(3.6, 1.9), new THREE.MeshLambertMaterial({ map: texCorcho }));
corcho.position.set(CX, 1.75, BZ - .005);
menuProps.add(corcho);
menuProps.add(new THREE.Mesh(mueble([[Bx(3.76, .08, .06), K.madO, CX, 2.74, BZ], [Bx(3.76, .08, .06), K.madO, CX, .76, BZ], [Bx(.08, 2, .06), K.madO, CX - 1.84, 1.75, BZ], [Bx(.08, 2, .06), K.madO, CX + 1.84, 1.75, BZ]]), mMueble));
function papel(x) {
  x.fillStyle = '#d8cfae'; x.fillRect(0, 0, 512, 660); ruido(x, 512, 660, 2500, () => `rgba(110,90,50,${Math.random() * .12})`); manchas(x, 512, 660, 2, '120,90,40', .25);
  const g = x.createLinearGradient(0, 0, 512, 0); g.addColorStop(0, 'rgba(0,0,0,.18)'); g.addColorStop(.08, 'rgba(0,0,0,0)'); g.addColorStop(.92, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.18)'); x.fillStyle = g; x.fillRect(0, 0, 512, 660);
}
const TINTA = '#2a2418';
const titulo = (x, s) => { x.fillStyle = TINTA; x.textAlign = 'center'; x.font = 'bold 46px "Courier New", monospace'; x.fillText(s, 256, 84); x.fillRect(60, 104, 392, 4); };
const lineas = (x, arr, y0, sz, lh, al = 'center') => { x.fillStyle = TINTA; x.textAlign = al; x.font = sz + 'px "Courier New", monospace'; arr.forEach((l, i) => x.fillText(l, al === 'center' ? 256 : 40, y0 + i * lh)); };
function deslizador(x, y, et, v, act, txt) {
  x.fillStyle = TINTA; x.textAlign = 'left'; x.font = 'bold 32px "Courier New", monospace'; x.fillText(et, 60, y - 34);
  x.textAlign = 'right'; x.font = '28px "Courier New", monospace'; x.fillText(txt, 452, y - 34);
  x.fillStyle = 'rgba(40,32,20,.35)'; x.fillRect(60, y - 6, 392, 12); x.fillStyle = TINTA; x.fillRect(60, y - 6, 392 * v, 12);
  x.beginPath(); x.arc(60 + 392 * v, y, act ? 22 : 18, 0, 6.29); x.fillStyle = act ? '#a31515' : TINTA; x.fill();
}
const crearHoja = dib => { const c = document.createElement('canvas'); c.width = 512; c.height = 660; const x = c.getContext('2d'), t = new THREE.CanvasTexture(c); t.minFilter = THREE.LinearFilter; t.generateMipmaps = false; t.anisotropy = 8; const h = { t, redibujar() { papel(x); dib(x); t.needsUpdate = true; } }; h.redibujar(); return h; };
const CTRL = [['WASD / palanca', 'moverte'], ['Ratón / arrastrar', 'mirar'], ['Shift / CORRER', 'correr'], ['C / CÁMARA', 'cámara ↔ medidor'], ['Z / ZOOM', 'zoom o calmarte'], ['N / VISIÓN', 'visión nocturna'], ['E', 'interactuar'], ['I / MOCHILA', 'mochila'], ['Q · 1-4', 'tirar · elegir'], ['Esc / ❚❚', 'pausa']];
const hojas = [
  crearHoja(x => { titulo(x, 'VOLUMEN'); [['ENTIDADES', 'ent'], ['AMBIENTE', 'amb'], ['JUGADOR', 'jug']].forEach(([n, k], i) => deslizador(x, 210 + i * 150, n, AJ[k], M.sl === i, Math.round(AJ[k] * 150) + '%')); }),
  crearHoja(x => { titulo(x, 'BRILLO'); deslizador(x, 250, 'BRILLO', AJ.bri, true, Math.round((.5 + AJ.bri) * 100) + '%'); const g = x.createLinearGradient(60, 0, 452, 0); g.addColorStop(0, '#000'); g.addColorStop(1, '#fff'); x.fillStyle = g; x.fillRect(60, 340, 392, 70); lineas(x, ['oscuro                claro'], 440, 22, 30); lineas(x, ['Cambia qué tan oscuro', 'o claro se ve todo.'], 520, 26, 34); }),
  crearHoja(x => { titulo(x, 'CONTROLES'); CTRL.forEach(([a, b], i) => { x.fillStyle = TINTA; x.textAlign = 'left'; x.font = 'bold 24px "Courier New", monospace'; x.fillText(a, 34, 160 + i * 42); x.font = '24px "Courier New", monospace'; x.fillText(b, 262, 160 + i * 42); }); lineas(x, ['(por ahora no se pueden cambiar)'], 610, 20, 26); }),
  crearHoja(x => { titulo(x, 'IDIOMA'); lineas(x, ['▸ ESPAÑOL', '', 'ENGLISH', 'FRANÇAIS', 'PORTUGUÊS', 'DEUTSCH', '', '(próximamente)'], 190, 32, 50); }),
  crearHoja(x => { titulo(x, 'CRÉDITOS'); lineas(x, ['IDEA, DISEÑO Y SONIDOS', '[ tu nombre aquí ]', '', 'PROGRAMACIÓN', 'con ayuda de Claude (Anthropic)', '', 'MANIQUÍ 3D', '«Mannequin Female» de SketchPunk', 'CC BY 4.0 · sketchfab.com/sketchpunk', '', 'MOTOR: Three.js', '', 'Gracias por jugar.'], 160, 23, 37); })
];
const hojaMesh = hojas.map((h, i) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(.48, .62), new THREE.MeshBasicMaterial({ map: h.t, color: 0xdddddd })); m.position.set(CX + SX[i], 1.75 + SY[i], BZ + .004 * i); m.rotation.z = SR[i]; m.userData = { op: i + 1, hoja: h }; menuProps.add(m); return m; });
{
  const pin = SX.map((sx, i) => V3(CX + sx - SR[i] * .3, 1.75 + SY[i] + .27, BZ + .03)), cur = (a, b, sag) => new THREE.TubeGeometry(new THREE.QuadraticBezierCurve3(a, V3((a.x + b.x) / 2, (a.y + b.y) / 2 - sag, (a.z + b.z) / 2 + .03), b), 14, .004, 5, false);
  const piezas = [[0, 1], [1, 2], [2, 3], [3, 4], [0, 2], [1, 4], [2, 4]].map(([i, j]) => [cur(pin[i], pin[j], .06 + Math.random() * .1), 0xa31515, 0, 0, 0]);
  pin.forEach((q, i) => piezas.push([new THREE.SphereGeometry(.02, 8, 6), [0xc03030, 0x3050a0, 0xd0b030, 0x30903a, 0xc03030][i], q.x, q.y, q.z + .012]));
  menuProps.add(new THREE.Mesh(mueble(piezas), mMueble));
}
// ---- Puerta de salida: al abrirla solo hay luz blanca ----
const grupoPuerta = new THREE.Group();
grupoPuerta.userData.op = 7;
grupoPuerta.position.set(CX - 2.2, 0, CZ + 3.5);
menuProps.add(grupoPuerta);
const brillo = new THREE.Mesh(new THREE.PlaneGeometry(.98, 2.1), new THREE.MeshBasicMaterial({ color: 0xffffff, fog: false }));
brillo.position.set(0, 1.05, -.012);
brillo.rotation.y = Math.PI;
const pDoor = new THREE.Group();
pDoor.position.set(-.48, 0, -.045);
pDoor.add(new THREE.Mesh(mueble([[Bx(.96, 2.1, .05), 0x6a4a2a, .48, 1.05, 0], [Bx(.34, .8, .02), 0x5a3e22, .28, 1.55, -.03], [Bx(.34, .8, .02), 0x5a3e22, .68, 1.55, -.03], [Bx(.34, .7, .02), 0x5a3e22, .28, .55, -.03], [Bx(.34, .7, .02), 0x5a3e22, .68, .55, -.03], [Bx(.06, .06, .06), 0xb59b3a, .85, 1, -.04]]), mMueble));
grupoPuerta.add(new THREE.Mesh(mueble([[Bx(.08, 2.2, .1), K.madO, -.52, 1.1, -.05], [Bx(.08, 2.2, .1), K.madO, .52, 1.1, -.05], [Bx(1.12, .08, .1), K.madO, 0, 2.24, -.05]]), mMueble), brillo, pDoor);
// ---- Computadora antigua sobre el escritorio ----
const cvPC = document.createElement('canvas');
cvPC.width = 512;
cvPC.height = 384;
const xp = cvPC.getContext('2d'), texPC = new THREE.CanvasTexture(cvPC);
texPC.minFilter = THREE.LinearFilter;
texPC.generateMipmaps = false;
const grupoPC = new THREE.Group();
grupoPC.userData.op = 6;
grupoPC.position.set(CX + 2.74, .775, CZ + 1.2);
grupoPC.rotation.y = -Math.PI / 2;
menuProps.add(grupoPC);
grupoPC.add(new THREE.Mesh(mueble([[Bx(.5, .42, .46), K.bei, 0, .25, 0], [Bx(.44, .36, .02), 0x1a1a18, 0, .27, .225], [Bx(.28, .06, .3), K.bei, 0, .02, 0], [Bx(.44, .025, .16), K.bei, 0, .0125, .46], [Bx(.2, .45, .4), K.bei, .42, .225, -.02]]), mMueble));
const pantallaPC = new THREE.Mesh(new THREE.PlaneGeometry(.34, .255), new THREE.MeshBasicMaterial({ map: texPC, fog: false }));
pantallaPC.position.set(0, .27, .236);
grupoPC.add(pantallaPC);
function dibujarPC() {
  const x = xp, W = 512, H = 384;
  if (!M.pcModo) { x.fillStyle = '#050a06'; x.fillRect(0, 0, W, H); x.fillStyle = '#1f6a2c'; x.font = 'bold 26px "Courier New", monospace'; x.textAlign = 'center'; if (((M.t * 1.2) | 0) % 2) x.fillText('C:\\>_', W / 2, H / 2); }
  else {   // pantalla azul con un rectángulo blanco para escribir; por ahora todo da ERROR
    x.fillStyle = '#0000aa'; x.fillRect(0, 0, W, H); x.fillStyle = '#fff'; x.textAlign = 'center'; x.font = 'bold 26px "Courier New", monospace'; x.fillText('CÓDIGO DE ACCESO', W / 2, 110);
    x.fillRect(46, 140, W - 92, 62); x.fillStyle = '#000'; x.textAlign = 'left'; x.font = 'bold 34px "Courier New", monospace'; x.fillText(M.pcTexto + (((M.t * 2) | 0) % 2 ? '_' : ''), 62, 184);
    if (M.pcErr > 0) { x.fillStyle = '#ff5555'; x.textAlign = 'center'; x.font = 'bold 64px "Courier New", monospace'; x.fillText('ERROR', W / 2, 300); }
    x.fillStyle = '#99aabb'; x.font = '18px "Courier New", monospace'; x.textAlign = 'center'; x.fillText('ENTER enviar · ESC salir', W / 2, 360);
  }
  texPC.needsUpdate = true;
}
// ---- Pantalla de dificultad: va DENTRO de la escena (sobre negro) para que el efecto de la cámara se aplique también a las letras ----
const cvDif = document.createElement('canvas');
cvDif.width = 1280;
cvDif.height = 720;
const xd = cvDif.getContext('2d'), texDif = new THREE.CanvasTexture(cvDif);
texDif.minFilter = THREE.LinearFilter;
texDif.generateMipmaps = false;
const difPlano = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: texDif, depthTest: false, fog: false }));
const fondoNegro = new THREE.Mesh(new THREE.PlaneGeometry(8, 8), new THREE.MeshBasicMaterial({ color: 0x000000, depthTest: false, fog: false }));
difPlano.position.z = -1;
fondoNegro.position.z = -1.02;
difPlano.renderOrder = 1001;
fondoNegro.renderOrder = 1000;
difPlano.visible = fondoNegro.visible = false;
difPlano.frustumCulled = fondoNegro.frustumCulled = false;
cam.add(fondoNegro, difPlano);
const DIF = [['FÁCIL', 'Con el medidor de porcentajes. La paranoia sube más despacio con las sombras, el agua baja más lento, la batería dura más y hay menos entidades.'], ['CANON', 'Lo que le pasaría a una persona real que entrara en los Backrooms. Sin medidor. La puerta blanca y la sala manila aparecen al azar, a veces a la vez o varias, pero son muy difíciles de encontrar: ganar depende de la suerte.'], ['LIMINAL', 'Como Canon, pero las entidades aparecen más seguido, la paranoia sube todavía más rápido y la sed baja más rápido al correr.']];
function palabras(x, t, px, py, w, lh) { let l = ''; for (const q of t.split(' ')) { if (x.measureText(l + q).width > w) { x.fillText(l, px, py); py += lh; l = ''; } l += q + ' '; } x.fillText(l, px, py); }
function dibujarDif() {
  const x = xd; x.fillStyle = '#000'; x.fillRect(0, 0, 1280, 720); x.fillStyle = '#e8e8e8'; x.textAlign = 'left'; x.font = '30px "Courier New", monospace'; x.fillText('SELECCIONA LA DIFICULTAD', 70, 70);
  DIF.forEach(([n, d], i) => {
    const y = 140 + i * 170; if (M.dif === i) { x.strokeStyle = '#fff'; x.lineWidth = 4; x.strokeRect(50, y - 6, 1180, 150); }
    x.font = 'bold 56px "Courier New", monospace'; x.fillText((M.dif === i ? '> ' : '  ') + n, 70, y + 52); x.font = '27px "Courier New", monospace'; palabras(x, d, 70, y + 94, 1130, 33);
  });
  x.font = 'bold 46px "Courier New", monospace'; x.fillText((M.dif === 3 ? '> ' : '  ') + 'VOLVER', 70, 690); texDif.needsUpdate = true;
}
// ---- Navegación ----
const VP = [{ p: V3(CX - .2, 1.15, CZ + 1.5), l: V3(CX - .2, .85, CZ + .9), fov: 60 }, ...SX.map((sx, i) => ({ p: V3(CX + sx, 1.75 + SY[i], BZ + .85), l: V3(CX + sx, 1.75 + SY[i], BZ), fov: 55 })), { p: V3(CX + 1.2, 1.2, CZ + 1.2), l: V3(CX + 2.5, 1, CZ + 1.2), fov: 65 }, { p: V3(CX - 2.2, 1.5, CZ + 1.7), l: V3(CX - 2.2, 1.1, CZ + 3.45), fov: 65 }];
const VP_PC = { p: V3(CX + 2.05, 1.06, CZ + 1.2), l: V3(CX + 2.5, 1.06, CZ + 1.2), fov: 42 }, VP_PUERTA = { p: V3(CX - 2.2, 1.35, CZ + 3.9), l: V3(CX - 2.2, 1.3, CZ + 5), fov: 75 };
function etiqueta() {
  const e = M.estado; elNav.style.display = (e === 'nav' || e === 'dif' || e === 'pc') ? 'flex' : 'none';
  const t = e === 'dif' ? NOMD[M.dif] : e === 'pc' ? 'ESCRIBE UN CÓDIGO' : NOM[M.op]; if (elSelM.textContent !== t) elSelM.textContent = t;
}
function irA(i) { if (M.estado === 'pc') salirPC(); if (M.estado !== 'nav') return; M.op = (i + 8) % 8; M.sl = 0; (M.op >= 1 && M.op <= 5 ? sPapel : sMadera)(); etiqueta(); }
function salirPC() { M.pcModo = false; M.estado = 'nav'; pcIn.blur(); etiqueta(); }
function seleccionar() {
  if (M.estado !== 'nav') return;
  if (M.op === 0) { M.estado = 'jugar'; M.t = 0; M.p0 = camMesa.position.clone(); M.q0 = camMesa.quaternion.clone(); sServo(true); }
  else if (M.op === 1) { M.sl = (M.sl + 1) % 3; hojas[0].redibujar(); sPapel(); }
  else if (M.op === 6) { M.estado = 'pc'; M.pcModo = true; M.pcTexto = ''; pcIn.value = ''; pcIn.focus(); sBip(880); }
  else if (M.op === 7) { M.estado = 'puerta'; M.t = 0; sPuerta(); setTimeout(sBlanco, 900); }
  etiqueta();
}
function difMover(d) { M.dif = (M.dif + d + 4) % 4; dibujarDif(); sTecla(false); etiqueta(); }
function volverDeDif() { ponerCam(false); camMesa.visible = true; resetCamMesa(); difPlano.visible = fondoNegro.visible = false; M.estado = 'nav'; sServo(false); etiqueta(); }
function seleccionarDif() { if (M.dif === 3) volverDeDif(); else empezar(['facil', 'canon', 'liminal'][M.dif]); }
function empezar(modo) {   // elegir dificultad = empezar: se reutiliza el arranque de siempre (audio, modo, cinemática y control)
  estado.modoSel = modo; M.act = false; M.estado = 'juego'; cv.style.cursor = 'default'; document.body.classList.remove('menu'); difPlano.visible = fondoNegro.visible = false; elNav.style.display = 'none';
  arrancarAudio(); menu.onclick();
  if (!TACTIL) menu.style.display = 'flex';   // por si el navegador no concede el bloqueo del ratón: queda 'haz clic para continuar' (si lo concede, se oculta solo)
}
export function abrirMenu3d() {
  Object.assign(M, { act: true, estado: 'nav', op: 0, dif: 1, t: 0, drag: -1, sl: 0, pcModo: false, pcTexto: '', pcErr: 0 });
  M.pos.copy(VP[0].p); M.look.copy(VP[0].l); M.fov = VP[0].fov;
  estado.activo = false; estado.camOn = false; estado.camObj = estado.camPos = 0; estado.nv = false; estado.medObj = estado.medPos = 0; cine.hecha = false; cine.act = false;
  document.body.classList.add('menu'); camMesa.visible = true; resetCamMesa(); pDoor.rotation.y = 0; difPlano.visible = fondoNegro.visible = false; casa.visible = true;
  elNegro.style.opacity = 0; elBlanco.style.opacity = 0; elBlanco.style.pointerEvents = 'none'; elBlanco.classList.remove('fin'); menu.style.display = 'none'; tactil.style.display = 'none';
  hojas.forEach(h => h.redibujar()); dibujarPC(); etiqueta();
}
export function menuUpdate(dt) {
  casa.visible = true; M.t += dt; const e = M.estado;
  ambiente.intensity = .3; pool.forEach((l, i) => l.intensity = i ? 0 : 1.5 + Math.sin(M.t * 1.3) * .05); pool[0].position.set(CX, 2.5, CZ + .5);
  const vp = e === 'pc' ? VP_PC : e === 'puerta' ? VP_PUERTA : VP[M.op], k = 1 - Math.exp(-dt * (e === 'puerta' ? 1.1 : 3.2));
  M.pos.lerp(vp.p, k); M.look.lerp(vp.l, k); M.fov += (vp.fov - M.fov) * k;
  cam.position.set(M.pos.x + Math.sin(M.t * .6) * .008, M.pos.y + Math.sin(M.t * .8) * .006, M.pos.z); cam.lookAt(M.look);
  if (Math.abs(cam.fov - M.fov) > .01) { cam.fov = M.fov; cam.updateProjectionMatrix(); }
  recLed.visible = Math.sin(M.t * 3) > 0;
  if (e === 'jugar') {   // la cámara vuela de la mesa a tu ojo; al taparlo todo, la pantalla se pone negra (visor)
    const u = Math.min(1, M.t / 1.5), s = u * u * (3 - 2 * u), f = V3(0, 0, 0).subVectors(M.look, M.pos).normalize(), tgt = M.pos.clone().addScaledVector(f, .12); tgt.y -= .04;
    camMesa.position.lerpVectors(M.p0, tgt, s); d2.position.copy(tgt); d2.lookAt(M.pos); camMesa.quaternion.copy(M.q0).slerp(d2.quaternion, s);
    if (u >= 1) { M.estado = 'dif'; M.dif = 1; camMesa.visible = false; difPlano.visible = fondoNegro.visible = true; ponerCam(true); dibujarDif(); etiqueta(); }
  } else if (e === 'puerta') {   // la puerta se abre: solo hay luz blanca; la cámara avanza hasta que todo es blanco
    pDoor.rotation.y = Math.min(1.7, M.t * 1.5); elBlanco.style.opacity = Math.max(0, Math.min(1, (M.t - 1.2) / 1.7));
    if (M.t > 3.1) { M.estado = 'fin'; elBlanco.style.pointerEvents = 'auto'; elBlanco.classList.add('fin'); try { window.close(); } catch (e2) {} }
  } else if (e === 'pc') { if (M.pcErr > 0) M.pcErr -= dt; dibujarPC(); }
  else if (M.op === 6) dibujarPC();
  if (difPlano.visible) { const h = 2 * Math.tan(cam.fov * Math.PI / 360), asp = innerWidth / innerHeight, w = Math.min(h * asp, h * 16 / 9); difPlano.scale.set(w, w * 9 / 16, 1); }
  etiqueta();
}
// ---- Entrada: puntero (clic/toque sobre los objetos), teclado y barra inferior ----
const ray = new THREE.Raycaster(), ptr = new THREE.Vector2();
const deform = (nx, ny) => { const asp = innerWidth / innerHeight, r2 = (nx * nx * asp * asp + ny * ny) / (asp * asp + 1), f = (1 + .45 * r2) / 1.45; return [nx * f, ny * f]; };  // inversa del ojo de pez del shader
function rayo(e, objs) { let nx = e.clientX / innerWidth * 2 - 1, ny = -(e.clientY / innerHeight * 2 - 1); if (estado.camOn) [nx, ny] = deform(nx, ny); ptr.set(nx, ny); ray.setFromCamera(ptr, cam); return ray.intersectObjects(objs, true)[0]; }
M.objs = [camMesa, ...hojaMesh, grupoPuerta, grupoPC];
function sliderDesde(h) {   // ajusta el deslizador que está bajo el puntero (hoja de volumen o de brillo)
  const cx = h.uv.x * 512, cy = (1 - h.uv.y) * 660, v = Math.max(0, Math.min(1, (cx - 60) / 392));
  if (M.op === 1) { const i = M.drag >= 0 ? M.drag : [210, 360, 510].findIndex(y => Math.abs(cy - y) < 55); if (i < 0) return -1; AJ[['ent', 'amb', 'jug'][i]] = v; M.sl = i; aplicarAjustes(); hojas[0].redibujar(); return i; }
  if (M.op === 2) { if (M.drag < 0 && Math.abs(cy - 250) > 55) return -1; AJ.bri = v; aplicarAjustes(); hojas[1].redibujar(); return 0; }
  return -1;
}
function ajustarTeclado(d) {
  if (M.op === 1) { const k = ['ent', 'amb', 'jug'][M.sl]; AJ[k] = Math.max(0, Math.min(1, AJ[k] + d * .05)); hojas[0].redibujar(); }
  else if (M.op === 2) { AJ.bri = Math.max(0, Math.min(1, AJ.bri + d * .05)); hojas[1].redibujar(); } else return;
  aplicarAjustes();
}
const navPaso = d => { if (M.estado === 'nav' || M.estado === 'pc') irA(M.op + d); else if (M.estado === 'dif') difMover(d); };
abrirMenu3d();

// ============ EVENTOS ============
// Se registran desde main.js (en el mismo orden que tenían en el script original).
export function eventosMenu() {
  cv.addEventListener('pointerdown', e => {
    if (!M.act) return; arrancarAudio();
    if (M.estado === 'dif') { const h = rayo(e, [difPlano]); if (h) { const cy = (1 - h.uv.y) * 720, i = cy < 134 ? -1 : cy < 296 ? 0 : cy < 466 ? 1 : cy < 636 ? 2 : cy > 640 ? 3 : -1; if (i >= 0) { M.dif = i; dibujarDif(); seleccionarDif(); } } return; }
    if (M.estado !== 'nav') return;
    const h = rayo(e, M.objs); if (!h) return; let o = h.object; while (o && o.userData.op === undefined) o = o.parent; if (!o) return;
    if (o.userData.op !== M.op) irA(o.userData.op);
    else if (o.userData.hoja) { M.drag = sliderDesde(h); if (M.drag >= 0) { try { cv.setPointerCapture(e.pointerId); } catch (e2) {} sPapel(); } }
    else seleccionar();
  });
  cv.addEventListener('pointermove', e => {
    if (!M.act) return;
    if (M.drag >= 0) { const h = rayo(e, [hojaMesh[M.op - 1]]); if (h) sliderDesde(h); return; }
    if (M.estado === 'nav') cv.style.cursor = rayo(e, M.objs) ? 'pointer' : 'default';
  });
  addEventListener('pointerup', () => { M.drag = -1; });
  addEventListener('keydown', e => {
    if (!M.act) return;
    if (M.estado === 'pc') { if (e.code === 'Escape') salirPC(); return; }
    const c = e.code;
    if (M.estado === 'nav') { if (c === 'ArrowLeft') irA(M.op - 1); else if (c === 'ArrowRight') irA(M.op + 1); else if (c === 'Enter' || c === 'Space') { e.preventDefault(); seleccionar(); } else if (c === 'ArrowUp' || c === 'ArrowDown') ajustarTeclado(c === 'ArrowUp' ? 1 : -1); }
    else if (M.estado === 'dif') { if (c === 'ArrowLeft' || c === 'ArrowUp') difMover(-1); else if (c === 'ArrowRight' || c === 'ArrowDown') difMover(1); else if (c === 'Enter' || c === 'Space') { e.preventDefault(); seleccionarDif(); } else if (c === 'Escape') volverDeDif(); }
  });
  elIzq.onpointerdown = e => { e.preventDefault(); arrancarAudio(); navPaso(-1); };
  elDer.onpointerdown = e => { e.preventDefault(); arrancarAudio(); navPaso(1); };
  elSelM.onpointerdown = e => { e.preventDefault(); arrancarAudio(); if (M.estado === 'nav') seleccionar(); else if (M.estado === 'dif') seleccionarDif(); };
  pcIn.oninput = () => { M.pcTexto = pcIn.value.toUpperCase().slice(0, 20); sTecla(false); };
  pcIn.onkeydown = e => { e.stopPropagation(); if (e.code === 'Enter') { e.preventDefault(); sTecla(true); setTimeout(() => sBip(160), 120); M.pcErr = 2.2; M.pcTexto = ''; pcIn.value = ''; } else if (e.code === 'Escape') salirPC(); };
  document.getElementById('blVolver').onpointerdown = e => { e.preventDefault(); abrirMenu3d(); };
}
