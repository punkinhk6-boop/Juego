// SHADERS — render a textura y post-proceso analógico: ojo de pez, aberración cromática, glitch, visión nocturna, grano, estática. Los GLSL están en VERT_POST / FRAG_POST.
import * as THREE from 'three';
import { TACTIL } from './config.js';
import { renderer } from './escena.js';

// La escena se dibuja en una textura y luego se pasa por un shader que aplica todo lo "de cámara".
export const rt = (renderer.capabilities.isWebGL2 && !TACTIL) ? new THREE.WebGLMultisampleRenderTarget(innerWidth, innerHeight) : new THREE.WebGLRenderTarget(innerWidth, innerHeight);
// Shader de vértices: un quad a pantalla completa
export const VERT_POST = `varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, 0., 1.); }`;

// Shader de fragmentos: ojo de pez, aberración cromática, bandas de glitch, visión nocturna,
// look de videocámara analógica (exposición, saturación, contraste, grano), estática y brillo
export const FRAG_POST = `
    uniform sampler2D tD; uniform float uT, uFish, uNight, uStatic, uGlitch, uAsp, uBright, uNoise, uExp; uniform vec2 uPx; varying vec2 vUv;
    float h(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
    void main() {
      vec2 p = vUv * 2. - 1.;
      vec2 pa = vec2(p.x * uAsp, p.y);
      float r2 = dot(pa, pa) / (uAsp * uAsp + 1.);
      vec2 uv = (p * (1. + .45 * uFish * r2) / (1. + .45 * uFish)) * .5 + .5;      // ojo de pez: centro ampliado, bordes comprimidos
      float fila = floor(uv.y * 28.);
      float banda = step(.93, h(vec2(fila, floor(uT * 9.)))) * uGlitch;           // fallos de imagen: bandas desplazadas
      uv.x += banda * (h(vec2(fila, floor(uT * 17.))) - .5) * .3;
      uv = clamp(uv, 0., 1.);
      float ca = (.0016 * uFish + .014 * uGlitch) * (.4 + r2);                    // aberración cromática: discreta al grabar con normalidad; la separación RGB fuerte queda para los fallos de señal
      vec3 c = vec3(texture2D(tD, uv + vec2(ca, 0.)).r, texture2D(tD, uv).g, texture2D(tD, uv - vec2(ca, 0.)).b);
      if (uFish > .5) {                                                            // suavidad óptica muy ligera: 4 muestras diagonales, algo más anchas en horizontal (como el vídeo analógico)
        vec2 o = uPx * vec2(1.1, .7);
        vec3 sf = (texture2D(tD, uv + o).rgb + texture2D(tD, uv - o).rgb + texture2D(tD, uv + vec2(o.x, -o.y)).rgb + texture2D(tD, uv + vec2(-o.x, o.y)).rgb) * .25;
        c = mix(c, sf, .3);
      }
      if (uNight > .5) {                                                           // visión nocturna: verde, muy sensible, luces con resplandor y grano
        float l = dot(c, vec3(.3, .59, .11)), g = 0.;
        for (int i = 0; i < 8; i++) { float a = float(i) * .785; g += max(dot(texture2D(tD, uv + vec2(cos(a), sin(a)) * .01).rgb, vec3(.3, .59, .11)) - .75, 0.); }
        l = 1. - exp(-(l * 7. + g * .9));
        l += (h(vUv * 700. + uT) - .5) * .2;
        c = vec3(.25, 1., .3) * l;
      } else if (uFish > .5) {                                                     // look de videocámara doméstica antigua
        c *= uExp;                                                                 // exposición suave (la calcula el JS)
        float lum = dot(c, vec3(.299, .587, .114));
        c = mix(vec3(lum), c, .82);                                                // saturación ~0.82
        c = (c - .5) * .94 + .5;                                                   // contraste 0.94 (de paso levanta un poco el negro)
        c *= vec3(1.03, 1., .95);                                                  // dominante cálida muy sutil
        c = c * .985 + vec3(.010, .009, .012);                                     // niveles de negro: menos "digital"
        float tt = mod(floor(uT * 24.), 211.);                                     // el grano cambia 24 veces por segundo, como el vídeo
        float g1 = h(floor(vUv * vec2(960., 540.)) + tt * 1.37) - .5;              // grano fino
        float g2 = h(floor(vUv * vec2(240., 135.)) + tt * 2.11 + 31.) - .5;        // mancha suave de luminancia: lo hace orgánico, no estática
        c += (g1 * .75 + g2 * .5) * 2. * uNoise * (1.25 - lum);                    // algo más visible en sombras
      }
      c = mix(c, vec3(h(vUv * vec2(900., 500.) + uT * 37.)), uStatic * .85);      // estática
      c += banda * .25;
      gl_FragColor = vec4(c * uBright, 1.);
    }`;

export const postMat = new THREE.ShaderMaterial({
  uniforms: { tD: { value: rt.texture }, uT: { value: 0 }, uFish: { value: 0 }, uNight: { value: 0 }, uStatic: { value: 0 }, uGlitch: { value: 0 }, uAsp: { value: innerWidth / innerHeight }, uBright: { value: 1 }, uNoise: { value: .025 }, uExp: { value: 1 }, uPx: { value: new THREE.Vector2(1 / innerWidth, 1 / innerHeight) } },
  depthTest: false, depthWrite: false,
  vertexShader: VERT_POST,
  fragmentShader: FRAG_POST
});
export const postScene = new THREE.Scene(), postCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1), quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), postMat);
quad.frustumCulled = false;
postScene.add(quad);
function tamRT() { const pr = renderer.getPixelRatio(); rt.setSize(Math.floor(innerWidth * pr), Math.floor(innerHeight * pr)); postMat.uniforms.uAsp.value = innerWidth / innerHeight; postMat.uniforms.uPx.value.set(1 / rt.width, 1 / rt.height); }
tamRT();

// ============ EVENTOS ============
// Se registran desde main.js (en el mismo orden que tenían en el script original).
export function eventosShaders() {
  addEventListener('resize', tamRT);
}
