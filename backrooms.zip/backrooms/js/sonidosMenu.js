// SONIDOS SINTETIZADOS del menú (hojas, teclas, madera…).
import { estado } from './config.js';
import { cargarAudios, iniciarAudio } from './audio.js';

// Sonidos del menú (sintetizados): hojas, teclas, madera, puerta, luz blanca, bips y el servo de la cámara
function sRuido(dur, vol, tipo, f, q = 1) {
  if (!estado.ctx) return; const n = Math.floor(estado.ctx.sampleRate * dur), b = estado.ctx.createBuffer(1, n, estado.ctx.sampleRate), d = b.getChannelData(0); for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
  const s = estado.ctx.createBufferSource(), fl = estado.ctx.createBiquadFilter(), g = estado.ctx.createGain(); s.buffer = b; fl.type = tipo; fl.frequency.value = f; fl.Q.value = q; g.gain.value = vol; s.connect(fl); fl.connect(g); g.connect(estado.ctx.destination); s.start();
}
function sTono(tipo, f0, f1, dur, vol) { if (!estado.ctx) return; const t = estado.ctx.currentTime, o = estado.ctx.createOscillator(), g = estado.ctx.createGain(); o.type = tipo; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + dur); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.001, t + dur); o.connect(g); g.connect(estado.ctx.destination); o.start(t); o.stop(t + dur + .02); }
export const sPapel = () => { sRuido(.2, .16, 'bandpass', 3800, 1.2); setTimeout(() => sRuido(.12, .1, 'bandpass', 5500, 1.5), 80); };
export const sTecla = fuerte => { sRuido(.035, .28, 'highpass', 2200); if (fuerte) sTono('triangle', 140, 60, .12, .3); };
export const sMadera = () => sTono('triangle', 120, 55, .14, .35);
export const sBip = f => sTono('square', f, f * .98, .16, .08);
export const sServo = on => sTono('sawtooth', on ? 160 : 260, on ? 270 : 150, .45, .03);
export function sPuerta() { sTono('sawtooth', 95, 48, 1.2, .1); sRuido(1.1, .06, 'bandpass', 700, 3); }
export const sBlanco = () => sRuido(2.6, .2, 'lowpass', 1800);
// El audio solo puede arrancar tras un gesto del usuario: en el móvil el 'pointerdown' no cuenta, así que se prueba con varios eventos y se reanuda si quedó en pausa
export const arrancarAudio = () => { if (!estado.ctx) { iniciarAudio(); try { cargarAudios(); } catch (e) {} } if (estado.ctx && estado.ctx.state === 'suspended') estado.ctx.resume(); };

// ============ EVENTOS ============
// Se registran desde main.js (en el mismo orden que tenían en el script original).
export function eventosSonidosMenu() {
  ['pointerdown', 'pointerup', 'click', 'touchend', 'keydown'].forEach(ev => addEventListener(ev, arrancarAudio));
}
