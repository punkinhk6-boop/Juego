// CINEMÁTICA INICIAL — casa abandonada, subtítulos y la toma de la cámara.
import * as THREE from 'three';
import { estado, TACTIL } from './config.js';
import { ambiente, cam, cv, pool, scene } from './escena.js';
import { lienzo, manchas, ruido } from './texturas.js';
import { Bx, escritorio, estanteria, K, mMueble, mueble, silla } from './muebles.js';
import { MANCHAS } from './manchas.js';
import { gGar } from './garabatos.js';
import { elNegro, elP1, elP2, elSaltar, elSub, tactil } from './dom.js';
import { P } from './player.js';
import { estaticaSonido, ponerCam } from './camara.js';
import { camModelo } from './modeloCamara.js';
import { VOL } from './ajustes.js';

// ================= CINEMÁTICA INICIAL =================
export const cine = { act: false, hecha: false, t: 0, p: { x: 0, y: 1.65, z: 0, yaw: 0, pitch: 0, roll: 0, fov: 75, casa: false }, ev: [], glitch: 0, est: 0, hum: null };
export const CX = 1000, CZ = 1000;  // la casa abandonada está lejos del mapa
const kf = (t, k) => { if (t <= k[0][0]) return k[0][1]; for (let i = 1; i < k.length; i++) if (t <= k[i][0]) { const a = k[i - 1], b = k[i], x = (t - a[0]) / (b[0] - a[0]); return a[1] + (b[1] - a[1]) * x * x * (3 - 2 * x); } return k[k.length - 1][1]; };  // claves [tiempo, valor] con suavizado
let subT = 0;
function subtitulo(txt, ms) { elSub.textContent = txt; elSub.style.display = 'block'; clearTimeout(subT); subT = setTimeout(() => elSub.style.display = 'none', ms); }
export const casa = new THREE.Group();
casa.visible = false;
scene.add(casa);
{
  const tx = lienzo(256, 256, (x, w, h) => { x.fillStyle = '#6f6557'; x.fillRect(0, 0, w, h); ruido(x, w, h, 3000, () => `rgba(30,24,16,${Math.random() * .3})`); manchas(x, w, h, 7, '30,24,14', .35); }, 3, 1.2);
  const tm = lienzo(256, 256, (x, w, h) => { for (let i = 0; i < 8; i++) { x.fillStyle = `rgb(${(70 + Math.random() * 30) | 0},${(48 + Math.random() * 20) | 0},${(30 + Math.random() * 14) | 0})`; x.fillRect(0, i * 32, w, 30); } ruido(x, w, h, 2500, () => `rgba(0,0,0,${Math.random() * .3})`); }, 3, 3);
  const mP = new THREE.MeshLambertMaterial({ map: tx }), mS = new THREE.MeshLambertMaterial({ map: tm }), mN = new THREE.MeshBasicMaterial({ color: 0x000000, side: THREE.DoubleSide, fog: false });
  const pl = (w, h, m, x, y, z, ry, rx = 0) => { const o = new THREE.Mesh(new THREE.PlaneGeometry(w, h), m); o.position.set(x, y, z); o.rotation.set(rx, ry, 0); casa.add(o); return o; };
  pl(7, 6, mS, CX, 0, CZ + .5, 0, -Math.PI / 2); pl(7, 6, mP, CX, 3, CZ + .5, 0, Math.PI / 2);                  // suelo de tablas y techo
  pl(7, 3, mP, CX, 1.5, CZ - 2.5, 0); pl(7, 3, mP, CX, 1.5, CZ + 3.5, Math.PI);                                // pared norte (la de la cinemática) y sur
  pl(6, 3, mP, CX - 3.5, 1.5, CZ + .5, Math.PI / 2); pl(6, 3, mP, CX + 3.5, 1.5, CZ + .5, -Math.PI / 2);        // oeste (con ventanas) y este
  const ventana = mueble([[Bx(.06, .1, 1.3), K.madO, 0, .75, 0], [Bx(.06, .1, 1.3), K.madO, 0, -.75, 0], [Bx(.06, 1.4, .1), K.madO, 0, 0, -.6], [Bx(.06, 1.4, .1), K.madO, 0, 0, .6], [Bx(.06, .05, 1.1), K.madO, 0, 0, 0]]);
  for (const zw of [CZ - .8, CZ + 1.8]) { pl(1.1, 1.4, mN, CX - 3.49, 1.6, zw, Math.PI / 2); const v = new THREE.Mesh(ventana, mMueble); v.position.set(CX - 3.46, 1.6, zw); casa.add(v); }   // fuera solo hay negro
  const poner = (def, x, z, ry, rz = 0, y = 0) => { const m = new THREE.Mesh(def.g, mMueble); m.position.set(x, y, z); m.rotation.set(0, ry, rz); casa.add(m); };
  poner(escritorio(false), CX + 2.6, CZ + 1.2, -Math.PI / 2); poner(estanteria(), CX + 3.3, CZ - 1, -Math.PI / 2); poner(silla(K.madO), CX - 1.8, CZ + 2.2, 1, 1.5, .3); poner(silla(K.gri), CX + 1.8, CZ + 1, 2.4);
  const cuadro = new THREE.Mesh(mueble([[Bx(.7, .9, .04), K.madO, 0, 0, 0], [Bx(.6, .8, .02), 0x2a2a28, 0, 0, .02]]), mMueble); cuadro.position.set(CX + .5, 1.7, CZ - 2.47); casa.add(cuadro);
  const mancha = new THREE.Mesh(gGar, MANCHAS[1]); mancha.scale.set(2.6, 2.2, 1); mancha.position.set(CX - .9, 1.4, CZ - 2.49); casa.add(mancha);
}
export function iniciarCine() {
  if (cine.act || cine.hecha) return;
  Object.assign(cine, { act: true, t: 0, glitch: 0, est: 0, hum: null, p: { x: CX, y: 1.65, z: CZ, yaw: .9, pitch: 0, roll: 0, fov: 75, casa: true }, ev: [
    { t: 4.7, f: () => subtitulo('Qué raro...', 2400) }, { t: 4.8, f: () => estaticaSonido(.5, .12) },
    { t: 16.35, f: () => subtitulo('¡Pero qué—!', 1100) }, { t: 16.9, f: () => estaticaSonido(.4, .3) },
    { t: 23, f: () => subtitulo('Este lugar... Me suena de algo.', 3400) }].map(e => Object.assign(e, { ok: false })) });
  estado.camOn = false; estado.camObj = estado.camPos = 0; estado.nv = false; estado.modeloMundo = false; cam.add(camModelo); estado.medObj = estado.medPos = 0;
  document.body.classList.add('cine'); tactil.style.display = 'none'; elSaltar.style.display = 'block'; elNegro.style.opacity = 1;
}
function finCine() {
  if (!cine.act) return;
  cine.act = false; cine.hecha = true; P.yaw = P.pitch = 0; casa.visible = false;   // el jugador toma el control justo donde despertó
  if (cine.hum) { try { cine.hum.o.stop(); } catch (e) {} cine.hum = null; }
  estado.modeloMundo = false; cam.add(camModelo); estado.camObj = estado.camPos = 1; cine.glitch = cine.est = 0; if (!estado.camOn) ponerCam(true);
  document.body.classList.remove('cine'); elNegro.style.opacity = 0; elP1.style.height = elP2.style.height = '0'; elSub.style.display = 'none'; elSaltar.style.display = 'none';
  cam.fov = 75; cam.updateProjectionMatrix(); cv.style.filter = ''; estado.flAnt = '';
  if (TACTIL && estado.activo) tactil.style.display = 'block';
}
export function cineUpdate(dt) {
  const t = (cine.t += dt), p = cine.p, E = kf;
  for (const e of cine.ev) if (!e.ok && t >= e.t) { e.ok = true; e.f(); }
  const quiere = (t >= 3 && t < 6) || (t >= 9.3 && t < 17) || t >= 26;   // la cámara está en el ojo solo en estos tramos
  if (quiere !== estado.camOn) ponerCam(quiere);
  if (t < 18.2) {
    // ---- Casa abandonada: levanta la cámara, falla, la baja, la vuelve a subir y la pared lo absorbe ----
    p.casa = true; cine.resp = 0;
    estado.camPos = E(t, [[0, 0], [2, 0], [3, 1], [6, 1], [6.9, 0], [8.4, 0], [9.3, 1]]);
    p.x = CX + Math.sin(t * 1.1) * .012; p.y = 1.65 + Math.sin(t * 1.7) * .01 + (t > 9.4 && t < 16.4 ? Math.sin(t * 5.2) * .02 : 0);
    p.z = CZ + E(t, [[9.4, 0], [16.4, -2.1], [16.9, -3]]);                                  // se acerca despacio y al final la pared lo succiona
    p.yaw = E(t, [[0, .9], [2.4, 0], [6, .05], [7, -.12], [8.2, 0]]) + (t > 9.4 ? Math.sin(t * 2.3) * .015 : 0);
    p.pitch = E(t, [[0, 0], [3.2, .05], [6, .05], [7, -.12], [9.4, 0]]);
    p.roll = E(t, [[16.3, 0], [17, .75]]) + (t > 16.4 ? Math.sin(t * 40) * .05 : 0);
    p.fov = E(t, [[16.3, 75], [17, 130]]);
    cine.glitch = E(t, [[0, 0], [4.4, 0], [4.8, 1], [5.7, .9], [6, 0], [9.4, 0], [10, .1], [14, .35], [16.4, .9], [17, 1]]) * (estado.camOn ? .7 + Math.random() * .3 : 0);
    cine.est = E(t, [[16.7, 0], [16.95, 1]]);
    elNegro.style.opacity = E(t, [[0, 1], [1.6, 0], [16.95, 0], [17, 1], [18.2, 1]]);      // fundido inicial y corte brusco a negro
    if (estado.ctx && t > 9.3 && t < 17 && !cine.hum) { const o = estado.ctx.createOscillator(), g = estado.ctx.createGain(); o.type = 'sawtooth'; o.frequency.value = 52; g.gain.value = 0; o.connect(g); g.connect(estado.ctx.destination); o.start(); cine.hum = { o, g }; }
    if (cine.hum) { cine.hum.g.gain.value = E(t, [[9.4, 0], [16.4, .07], [16.9, .2]]) * VOL.amb; if (t >= 17) { cine.hum.o.stop(); cine.hum = null; } }
  } else {
    // ---- Despertar en el suelo del backroom (mismo sitio y vista que al empezar), levantarse, recoger la cámara y paneo ----
    p.casa = false; cine.glitch = cine.est = 0; cine.resp = E(t, [[18.2, .95], [21.5, .75], [24.5, .35], [26.5, 0]]);   // respira agitado al despertar
    if (!estado.modeloMundo && t < 25.1) { estado.modeloMundo = true; scene.add(camModelo); camModelo.visible = true; camModelo.position.set(P.x + .7, .06, P.z - .56); camModelo.rotation.set(0, 1.1, 0); }
    p.x = P.x + .25; p.z = P.z; p.y = E(t, [[18.2, .3], [22, .3], [23.6, .9], [25.4, 1.65]]);
    p.yaw = E(t, [[18.2, .4], [22, .4], [23, -.9], [27, -.9], [28.4, .9], [30, 0]]);
    p.pitch = E(t, [[18.2, 1.15], [22, 1], [23, -.55], [25.4, -.3], [27, 0]]);
    p.roll = E(t, [[18.2, .12], [22, .1], [24, 0]]); p.fov = 75;
    const open = E(t, [[18.2, 0], [18.7, .25], [19.15, .05], [19.7, .55], [20.15, .15], [20.75, .85], [21.25, .5], [21.9, 1]]);   // parpadeos suaves
    elNegro.style.opacity = 0; elP1.style.height = elP2.style.height = (50 * (1 - open)) + '%';
    cv.style.filter = `blur(${(7 * (1 - open) + E(t, [[18.2, 5], [22.5, 0]])).toFixed(1)}px)`;
    if (estado.modeloMundo && t >= 24.2) {   // la cámara vuela del suelo a su mano
      const f = E(t, [[24.2, 0], [25.1, 1]]), fx = -Math.sin(p.yaw) * Math.cos(p.pitch), fz = -Math.cos(p.yaw) * Math.cos(p.pitch);
      camModelo.position.set(P.x + .7 + (p.x + fx * .45 - (P.x + .7)) * f, .06 + (p.y - .35 - .06) * f, P.z - .56 + (p.z + fz * .45 - (P.z - .56)) * f);
    }
    if (estado.modeloMundo && t >= 25.1) { estado.modeloMundo = false; cam.add(camModelo); }
    estado.camPos = E(t, [[18.2, 0], [25.2, 0], [26.1, 1]]);
  }
  if (t >= 30.6) finCine();
}
export function cineCam() {
  const p = cine.p; cam.position.set(p.x, p.y, p.z); cam.rotation.set(p.pitch, p.yaw, p.roll);
  if (Math.abs(p.fov - cam.fov) > .01) { cam.fov = p.fov; cam.updateProjectionMatrix(); }
  casa.visible = p.casa;
  if (p.casa) {   // la casa se alumbra con una de las luces del juego (así no hay que recompilar shaders) y la luz titila cuando la cosa se pone fea
    ambiente.intensity = .2; pool.forEach((l, i) => l.intensity = i ? 0 : 1.3 + Math.sin(cine.t * 9) * .08 * cine.glitch - (Math.random() < .05 * cine.glitch ? 1 : 0)); pool[0].position.set(CX, 2.4, CZ);
  }
}

// ============ EVENTOS ============
// Se registran desde main.js (en el mismo orden que tenían en el script original).
export function eventosCinematica() {
  elSaltar.onpointerdown = e => { e.preventDefault(); finCine(); };
  addEventListener('keydown', e => { if (cine.act && (e.code === 'Space' || e.code === 'Enter')) finCine(); });
}
