// HUD — barra de hidratación, avisos y reloj.
import { estado } from './config.js';
import { elHid, elHR, elHT } from './dom.js';
import { elAviso } from './inventario.js';

let tHud = 0;
// Barras de hidratación, avisos y reloj del HUD
export function actualizarHud(dt) {
  elHR.style.width = (estado.hid * 100).toFixed(0) + '%'; elHT.textContent = estado.hid <= 0 ? 'SIN AGUA ' + Math.max(0, 25 - estado.sed0).toFixed(0) + 's' : 'HIDRATACIÓN';
  elHid.style.opacity = estado.hid < .2 && Math.random() < .2 ? .35 : .85;
  if ((estado.avisoT -= dt) <= 0) elAviso.style.opacity = 0;

  tHud += dt;
  if (tHud > .5) { tHud = 0; const s = estado.tiempo | 0; document.getElementById('t').textContent = String(s / 60 | 0).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); document.getElementById('m').textContent = estado.mut; }
}
