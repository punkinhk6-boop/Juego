// ENTIDAD — la sombra que se asoma por las paredes y se esconde si la miras.
import * as THREE from 'three';
import { C, estado, T } from './config.js';
import { scene } from './escena.js';
import { P } from './player.js';
import { choca, muros } from './world.js';
import { AUD, bucleVoz, panDe, pararVoz, vSusurro } from './audio.js';

// ================= LA SOMBRA: vigilante que se asoma por las paredes y nunca se deja ver entera =================
// Silueta negra con ojos humanos (dibujada con canvas). Para usar una imagen propia basta con cargarla en lugar de esta textura.
function texSombra() {
  const c = document.createElement('canvas'); c.width = 256; c.height = 512; const x = c.getContext('2d');
  x.fillStyle = '#000'; x.shadowColor = '#000'; x.shadowBlur = 30;
  x.beginPath(); x.ellipse(128, 120, 46, 66, 0, 0, 6.29); x.fill();                                          // cabeza alargada
  x.beginPath(); x.moveTo(40, 512); x.quadraticCurveTo(50, 230, 128, 200); x.quadraticCurveTo(206, 230, 216, 512); x.fill();   // hombros caídos
  const g = x.createLinearGradient(0, 300, 0, 512); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,1)');
  x.globalCompositeOperation = 'destination-out'; x.fillStyle = g; x.fillRect(0, 300, 256, 212); x.globalCompositeOperation = 'source-over'; x.shadowBlur = 0;   // el cuerpo se disuelve hacia abajo
  for (const [ex, ey, w] of [[106, 112, 15], [152, 108, 13]]) {                                              // ojos humanos, apagados y desiguales
    x.fillStyle = '#d9d4c4'; x.beginPath(); x.ellipse(ex, ey, w, 8.5, 0, 0, 6.29); x.fill();
    x.fillStyle = '#050505'; x.beginPath(); x.arc(ex + 1, ey + 1, 4.2, 0, 6.29); x.fill();
  }
  return new THREE.CanvasTexture(c);
}
// Susurros: ruido filtrado con forma de sílabas, colocado en el estéreo donde está la sombra
let ruidoBuf = null;
function susurro(pan, vol) {
  const t = estado.ctx.currentTime;
  if (!ruidoBuf) { ruidoBuf = estado.ctx.createBuffer(1, estado.ctx.sampleRate * 2, estado.ctx.sampleRate); const d = ruidoBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; }
  const src = estado.ctx.createBufferSource(), bp = estado.ctx.createBiquadFilter(), g = estado.ctx.createGain(), p = estado.ctx.createStereoPanner();
  src.buffer = ruidoBuf; bp.type = 'bandpass'; bp.Q.value = 4; p.pan.value = pan;
  bp.frequency.setValueAtTime(1500, t); g.gain.setValueAtTime(0, t);
  let u = t; for (let i = 0, n = 2 + ((Math.random() * 3) | 0); i < n; i++) { const d = .12 + Math.random() * .18; bp.frequency.linearRampToValueAtTime(1000 + Math.random() * 2600, u + d); g.gain.linearRampToValueAtTime(vol * (.5 + Math.random() * .5), u + d * .4); g.gain.linearRampToValueAtTime(vol * .1, u + d); u += d + .04; }
  g.gain.linearRampToValueAtTime(0, u + .1);
  src.connect(bp); bp.connect(g); g.connect(p); p.connect(estado.ctx.destination); src.start(t, Math.random() * 1.5); src.stop(u + .15);
}
export const som = { s: 0, t: 40 + Math.random() * 40, emerge: 0, ex: 0, ez: 0, wx: 0, wz: 0, vida: 0, voz: 0, visto: false, acecha: false };
const SH = 2.6, SW = SH * 0.490789, BORDE = 0.055130;  // alto/ancho de la figura y posición de su borde recto (fracción del ancho)
export function sombra(dt) {
  const o = som;
  if (!estado.spr) {
    const tex = new THREE.TextureLoader().load(new URL('../assets/sombra.webp', import.meta.url).href);
    estado.spr = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide }));
    estado.spr.scale.set(SW, SH, 1); estado.spr.visible = false; scene.add(estado.spr);
  }
  o.t -= dt * (1 + estado.par * 2) * estado.MODO.entid;   // con más paranoia se deja ver más seguido
  if (o.s === 0) {
    if (o.t > 0) return;
    // Busca el extremo libre de una pared CERCANA (5-12 u.) y SIEMPRE A TU ESPALDA: la criatura se asoma por esa esquina
    const fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw); let n = 0, ok = false;
    for (const key of muros) {
      if (++n % 3) continue;
      const [tp, a, b] = key.split(','), i = +a, j = +b, along = tp === 'n', cx = along ? i * C + C / 2 : i * C, cz = along ? j * C : j * C + C / 2, sg = Math.random() < .5 ? 1 : -1;
      const hl = (C + T) / 2, ex = cx + (along ? sg * hl : 0), ez = cz + (along ? 0 : sg * hl), wx = along ? -sg : 0, wz = along ? 0 : -sg;   // (wx,wz): del extremo hacia dentro de la pared
      const dx = ex - P.x, dz = ez - P.z, d = Math.hypot(dx, dz); if (d < 5 || d > 12) continue;
      const c = (dx * fx + dz * fz) / d; if (c > -.25) continue;   // detrás de ti (más de ~105º respecto a hacia dónde miras)
      if (choca(ex - wx * .8, ez - wz * .8, .3)) continue;   // más allá del extremo tiene que haber hueco (ahí asoma)
      let vis = true; const tx = ex - wx * .4, tz = ez - wz * .4, nn = Math.ceil(d / .5);
      for (let q = 1; q < nn && vis; q++) if (choca(P.x + (tx - P.x) * q / nn, P.z + (tz - P.z) * q / nn, .05)) vis = false;
      if (!vis) continue;   // al darte la vuelta tiene que poder verse sin paredes en medio
      Object.assign(o, { s: 1, ex, ez, wx, wz, emerge: 0, vida: 40 + Math.random() * 30, voz: 0, visto: false, acecha: false, fuga: false }); estado.spr.visible = true; ok = true; estado.par = Math.min(1, estado.par + .08 * estado.MODO.parSombra); break;   // al aparecer, un golpe de paranoia
    }
    if (!ok) o.t = .5;
    return;
  }
  const rx = Math.cos(P.yaw), rz = -Math.sin(P.yaw), fx = -Math.sin(P.yaw), fz = -Math.cos(P.yaw);   // derecha y frente de la cámara
  const lado = (o.wx * rx + o.wz * rz) < 0 ? 1 : -1;   // pared a la izquierda del extremo: asoma por la derecha (y al revés: la imagen se refleja)
  const oc = 1 - o.emerge, desp = lado * SW * (.5 - BORDE) - lado * oc * (SW + .25);
  estado.spr.position.set(o.ex + rx * desp + fx * oc * .8, SH / 2 - .15, o.ez + rz * desp + fz * oc * .8);   // al esconderse se desliza tras la pared y se aleja
  estado.spr.rotation.y = P.yaw; estado.spr.scale.x = lado * SW; estado.spr.material.opacity = Math.min(1, o.emerge * 1.5);
  const dx = estado.spr.position.x - P.x, dz = estado.spr.position.z - P.z, d = Math.hypot(dx, dz) || 1;
  const mira = (dx * fx + dz * fz) / d > .95;   // lo estás mirando de frente
  if (mira && o.emerge > .1) o.visto = true;   // ya te has dado la vuelta a mirarlo
  const huye = (mira && o.emerge > .1) || d < 3.5 || d > 40 || (o.vida -= dt) <= 0;
  if (huye) o.fuga = true;   // una vez que empieza a esconderse, termina de esconderse y desaparece sola
  o.acecha = !o.visto && o.emerge > .2;       // vigila a tu espalda y no lo has mirado: la paranoia sube (ver paranoia())
  o.emerge = Math.max(0, Math.min(1, o.emerge + dt * (o.fuga ? -.9 : .6)));
  if (estado.ctx && AUD.susu) { if (o.emerge > .05) bucleVoz(vSusurro, AUD.susu, (.4 + .6 * o.emerge) * Math.min(1, 14 / (d + 4)), panDe(dx, dz)); else pararVoz(vSusurro); }
  else if (o.emerge > .05 && (o.voz -= dt) <= 0 && estado.ctx) { susurro(panDe(dx, dz), (.5 + .5 * o.emerge) * Math.min(1.2, 14 / (d + 4))); o.voz = .6 + Math.random() * 1.4; }
  if (o.emerge <= 0 && o.fuga) { o.s = 0; o.t = 35 + Math.random() * 55; estado.spr.visible = false; pararVoz(vSusurro); }
}
