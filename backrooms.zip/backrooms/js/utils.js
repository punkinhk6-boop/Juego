// UTILIDADES — hash y generador pseudoaleatorio con semilla (el mundo es determinista por chunk).

// ================= UTILIDADES =================
export const imul = Math.imul;
export function hash(a, b, c) { let h = imul(a, 374761393) ^ imul(b, 668265263) ^ imul(c, 2147483647); h = imul(h ^ (h >>> 13), 1274126177); return (h ^ (h >>> 16)) >>> 0; }
export function rng(s) { return function () { s |= 0; s = s + 0x6D2B79F5 | 0; let t = imul(s ^ s >>> 15, 1 | s); t = t + imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
