// AJUSTES — volúmenes y brillo (se guardan en localStorage).
import { estado } from './config.js';

// Ajustes (se guardan en el navegador): volúmenes por categoría y brillo. Los deslizadores van de 0 a 1; 2/3 equivale a 100 % de volumen.
export const AJ = { ent: 2 / 3, amb: 2 / 3, jug: 2 / 3, bri: .5 };
try { Object.assign(AJ, JSON.parse(localStorage.getItem('bk_aj') || '{}')); } catch (e) {}
export const VOL = { ent: 1, amb: 1, jug: 1 };
export function aplicarAjustes() { VOL.ent = AJ.ent * 1.5; VOL.amb = AJ.amb * 1.5; VOL.jug = AJ.jug * 1.5; estado.BRI = .5 + AJ.bri; try { localStorage.setItem('bk_aj', JSON.stringify(AJ)); } catch (e) {} }
aplicarAjustes();
