// FALLOS DE LUZ — apagones que suben la paranoia.
import { estado, H, SZ, TACTIL } from './config.js';
import { pool } from './escena.js';
import { P } from './player.js';
import { chunks, col } from './world.js';
import { ent, pisada } from './aulladores.js';
import { estaticaSonido } from './camara.js';
import { VOL } from './ajustes.js';
import { M } from './menu.js';

// Fallos de luces (todas las dificultades): en el chunk donde estás parpadean, se apagan y la paranoia sube
const lz = { t: 50 + Math.random() * 60, fase: 0, tf: 0, ch: null, osc0: false };
export function luces(dt) {
  const cur = chunks.get(Math.floor(P.x / SZ) + ',' + Math.floor(P.z / SZ));
  if (lz.fase === 0) {
    if ((lz.t -= dt) > 0 || !cur || !cur.luces.length || cur.esp === 'huecos') return;
    lz.fase = 1; lz.ch = cur; lz.tf = 5 + Math.random() * 5; lz.osc0 = cur.oscura;
    for (const l of cur.luces) { l.e0 = l.e; if (l.e < 2) l.e = 1; }
    estado.par = Math.min(1, estado.par + .03 * estado.MODO.parLuz); estaticaSonido(.3, .05);
    return;
  }
  const ch = lz.ch;
  if (chunks.get(ch.cx + ',' + ch.cz) !== ch) { lz.fase = 0; lz.t = 80; return; }   // el chunk ya no existe
  if (lz.fase === 1) {
    estado.par = Math.min(1, estado.par + dt / 90 * estado.MODO.parLuz);
    if ((lz.tf -= dt) <= 0) {
      lz.fase = 2; lz.tf = 14 + Math.random() * 14; ch.oscura = true;
      for (const l of ch.luces) if (l.e < 2) { l.e = 2; l.v = 0; l.m.setColorAt(l.i, col.setHex(0x1b1810)); l.m.instanceColor.needsUpdate = true; }
      if (estado.ctx) pisada(estado.ctx.currentTime, .5, 0, VOL.amb);
    }
  } else {
    estado.par = Math.min(1, estado.par + dt / 40 * estado.MODO.parLuz);
    if ((lz.tf -= dt) <= 0 || cur !== ch) {
      lz.fase = 0; lz.t = 70 + Math.random() * 80; ch.oscura = lz.osc0;
      for (const l of ch.luces) { l.e = l.e0; l.v = l.e === 2 ? 0 : 1; l.m.setColorAt(l.i, l.e === 2 ? col.setHex(0x1b1810) : col.setScalar(1)); l.m.instanceColor.needsUpdate = true; }
    }
  }
}
// Parpadeo de fluorescentes, luces reales cercanas y glitch de los maniquíes
export function parpadeoLuces(dt) {
  // Parpadeo de fluorescentes y asignación de las luces reales a los más cercanos
  const cand = [];
  for (const ch of chunks.values()) {
    let sucio = false;
    for (const l of ch.luces) {
      if (l.e === 1) {
        const v = (Math.sin(estado.tiempo * 41 + l.f) * Math.sin(estado.tiempo * 17 + l.f * 3) > .55 ? .12 : 1) * (Math.sin(estado.tiempo * .8 + l.f) > .94 ? 0 : 1);
        if (v !== l.v) { l.v = v; l.m.setColorAt(l.i, col.setScalar(v)); sucio = true; }
      }
      if (l.e < 2) { const dx = l.x - P.x, dz = l.z - P.z, d = dx * dx + dz * dz; if (d < 400) cand.push([d, l]); }
    }
    if (sucio) ch.luces[0].m.instanceColor.needsUpdate = true;
    // Glitch: los maniquíes cercanos vibran y parpadean
    for (const m of ch.mani) {
      const d = Math.hypot(m.x - P.x, m.z - P.z);
      m.o.visible = d < (TACTIL ? 30 : 42);   // lejos se pierden en la niebla: no se dibujan
      if (d > 14) continue;
      const j = Math.random() < .06;
      m.o.position.set(m.x + (j ? (Math.random() - .5) * .15 : 0), m.y, m.z + (j ? (Math.random() - .5) * .15 : 0));
      m.o.visible = Math.random() > .02;
    }
  }
  cand.sort((a, b) => a[0] - b[0]);
  pool.forEach((p, i) => { const c = cand[i]; if (c) { p.position.set(c[1].x, H - .4, c[1].z); p.intensity = 1.5 * c[1].v; } else p.intensity = 0; });
  if (estado.hum) estado.hum.gain.value = .05 * (cand[0] ? .5 + .5 * cand[0][1].v : .3) * VOL.amb * (M.act ? 0 : ent.sil > 0 || estado.muerto ? .1 : 1);
}
