// INVENTARIO — mochila, objetos recogibles (agua, baterías) e interacción.
import * as THREE from 'three';
import { estado, SZ } from './config.js';
import { Bx, mueble } from './muebles.js';
import { btnBeber } from './dom.js';
import { morir, P, romperGrieta } from './player.js';
import { choca, chunks } from './world.js';
import { estaticaSonido } from './camara.js';
import { gBotella, mBotella, mContorno } from './hidratacion.js';
import { cine } from './cinematica.js';
import { VOL } from './ajustes.js';

// ----- Inventario: las botellas se guardan (4 huecos) y desde la mochila se beben o se tiran al suelo -----
export const inv = [], elInv = document.getElementById('inv'), elSlots = document.getElementById('invSlots'), elAviso = document.getElementById('aviso');
export const invAbierto = () => elInv.style.display === 'block';
export function aviso(t) { elAviso.textContent = t; elAviso.style.opacity = 1; estado.avisoT = 2.4; }
const NOMBRES = { agua: 'AGUA DE ALMENDRAS', bateria: 'BATERÍA DE CÁMARA' };
export function renderInv() {
  elSlots.innerHTML = '';
  for (let i = 0; i < 4; i++) {
    const d = document.createElement('div'); d.className = 'slot' + (i === estado.invSel ? ' sel' : '');
    d.innerHTML = inv[i] ? `<i class="${inv[i] === 'agua' ? 'bot' : 'pil'}"></i><span>${NOMBRES[inv[i]]}</span>` : '<span class="vacio">— vacío —</span>';
    d.onpointerdown = e => { e.preventDefault(); estado.invSel = i; renderInv(); }; elSlots.appendChild(d);
  }
}
export function abrirInv(on) { if (on && cine.act) return; elInv.style.display = on ? 'block' : 'none'; if (on) renderInv(); }
function sonidoTrago() { if (!estado.ctx) return; for (let i = 0; i < 4; i++) { const t = estado.ctx.currentTime + i * .16, o = estado.ctx.createOscillator(), g = estado.ctx.createGain(); o.frequency.setValueAtTime(260 + i * 40, t); o.frequency.exponentialRampToValueAtTime(120, t + .12); g.gain.setValueAtTime(.12 * VOL.jug, t); g.gain.exponentialRampToValueAtTime(.001, t + .14); o.connect(g); g.connect(estado.ctx.destination); o.start(t); o.stop(t + .15); } }  // glu glu glu
// Objetos recogibles: geometría, material, altura del centro (para apuntarles) y tamaño del contorno
const gBateria = mueble([[Bx(.09, .03, .055), 0x2c2f33, 0, .015, 0], [Bx(.092, .008, .057), 0xd9b43a, 0, .026, 0], [Bx(.012, .012, .03), 0xb0b0b0, .05, .015, 0]]), mBateria = new THREE.MeshLambertMaterial({ vertexColors: true, emissive: 0x1a1608 });
const ITEMS = { agua: { g: gBotella, m: mBotella, yc: .15, esc: 1.18 }, bateria: { g: gBateria, m: mBateria, yc: .03, esc: 1.35 } };
export function ponerItem(ch, tipo, px, pz, y = 0) {
  const it = ITEMS[tipo], m = new THREE.Mesh(it.g, it.m), ol = new THREE.Mesh(it.g, mContorno);
  m.position.set(px, y, pz); ol.position.set(px, y, pz); ol.scale.setScalar(it.esc); ol.visible = false; ch.g.add(m, ol);
  (ch.bot = ch.bot || []).push({ x: px, z: pz, yc: y + it.yc, tipo, m, o: ol, ch });
}
export function interactuar() {   // E con la mochila cerrada: abrir la puerta o guardar lo que apuntas
  if (estado.objPuerta) { morir('salida'); return; }
  if (estado.objGrieta) { romperGrieta(); return; }
  if (!estado.objetivo) return;
  if (inv.length >= 4) { aviso('MOCHILA LLENA'); return; }
  const b = estado.objetivo, tipo = b.tipo || 'agua'; estado.objetivo = null; b.ch.g.remove(b.m, b.o); b.ch.bot.splice(b.ch.bot.indexOf(b), 1);
  inv.push(tipo); aviso(NOMBRES[tipo] + ' GUARDADA · [I] MOCHILA');
}
export function beberInv() {   // usar el objeto seleccionado: beber agua o cambiar la batería
  const it = inv[estado.invSel]; if (!it) return;
  if (it === 'bateria') { if (estado.bat > .97) { aviso('LA BATERÍA YA ESTÁ LLENA'); return; } estado.bat = Math.min(1, estado.bat + .5); aviso('BATERÍA CAMBIADA'); estaticaSonido(.12, .05); }
  else { estado.hid = Math.min(1, estado.hid + .35); estado.sed0 = 0; estado.par = Math.max(0, estado.par - .3); aviso('AGUA DE ALMENDRAS · PARANOIA −30%'); sonidoTrago(); }   // además de hidratar, baja la paranoia de golpe
  inv.splice(estado.invSel, 1); estado.invSel = Math.min(estado.invSel, Math.max(0, inv.length - 1)); renderInv();
}
export function tirarInv() {   // se queda en el suelo, delante de ti (o a tus pies si hay una pared)
  const it = inv[estado.invSel]; if (!it) return;
  let px = P.x - Math.sin(P.yaw) * .9, pz = P.z - Math.cos(P.yaw) * .9; if (choca(px, pz, .2)) { px = P.x; pz = P.z; }
  const ch = chunks.get(Math.floor(px / SZ) + ',' + Math.floor(pz / SZ)); if (!ch) return;
  inv.splice(estado.invSel, 1); estado.invSel = Math.min(estado.invSel, Math.max(0, inv.length - 1)); ponerItem(ch, it, px, pz); renderInv();
}

// ============ EVENTOS ============
// Se registran desde main.js (en el mismo orden que tenían en el script original).
export function eventosInventario() {
  btnBeber.onpointerdown = e => { e.preventDefault(); interactuar(); };
  document.getElementById('invBeber').onpointerdown = e => { e.preventDefault(); beberInv(); };
  document.getElementById('invTirar').onpointerdown = e => { e.preventDefault(); tirarInv(); };
  document.getElementById('invCerrar').onpointerdown = e => { e.preventDefault(); abrirInv(false); };
  document.getElementById('btnMochila').onpointerdown = e => { e.preventDefault(); abrirInv(!invAbierto()); };
}
