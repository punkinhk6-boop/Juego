// PRINCIPAL — punto de entrada. IMPORTANTE: el orden de los imports es el orden de carga del juego (cada módulo construye su parte de la escena al importarse). Aquí se registran los eventos y corre el bucle de animación.
import { estado, SEMILLA } from './config.js';
import './utils.js';
import { cam, renderer, scene } from './escena.js';
import './texturas.js';
import './materiales.js';
import './muebles.js';
import './manchas.js';
import './garabatos.js';
import './salas.js';
import './grietas.js';
import './dom.js';
import { caer, efectosJugador, eventosPlayer, k, mover, paranoia } from './player.js';
import { actualizarChunks, actualizarMundo } from './world.js';
import { pararVoz, vCarrera, vSusurro } from './audio.js';
import { aulladores, ent } from './aulladores.js';
import { som, sombra } from './sombra.js';
import { camaraSistema, eventosCamara } from './camara.js';
import { botellas, hidratacion } from './hidratacion.js';
import { eventosInventario } from './inventario.js';
import { eventosShaders, postCam, postScene, rt } from './shaders.js';
import './modeloCamara.js';
import { cine, cineUpdate, eventosCinematica } from './cinematica.js';
import { ambienteSonoro } from './sonidoAmbiente.js';
import { moverDestino } from './medidor.js';
import { eventosModos } from './modos.js';
import { luces, parpadeoLuces } from './luces.js';
import './ajustes.js';
import { eventosSonidosMenu } from './sonidosMenu.js';
import { eventosMenu } from './menu.js';
import { actualizarHud } from './hud.js';

// Registro de eventos de cada módulo (el orden importa: es el del script original)
eventosPlayer();
eventosCamara();
eventosInventario();
eventosShaders();
eventosCinematica();
eventosModos();
eventosSonidosMenu();
eventosMenu();

// ================= BUCLE PRINCIPAL =================
let t0 = performance.now();
document.getElementById('s').textContent = SEMILLA;
actualizarChunks(0, 0, 99);  // carga inicial completa
addEventListener('resize', () => { cam.aspect = innerWidth / innerHeight; cam.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });
function bucle(now) {
  requestAnimationFrame(bucle);
  const dt = Math.min((now - t0) / 1000, .1); t0 = now;
  if (estado.activo && cine.act) { cineUpdate(dt); } else if (estado.activo) {
    estado.tiempo += dt;
    const mv = estado.cayendo ? false : mover(dt), sp = (k.ShiftLeft || k.ShiftRight || estado.correT) && estado.hid > 0 && !estado.calmando;
    if (mv) estado.bob += dt * (sp ? 12 : 8);
    estado.movAhora = mv; estado.corrAhora = mv && sp;
    try { aulladores(dt, mv && sp); } catch (e) { ent.e = 0; ent.t = 1e9; }   // si el navegador no soporta el audio, se desactiva la entidad
    paranoia(dt, mv); hidratacion(dt, mv && sp); botellas(); caer(dt); ambienteSonoro(dt);
    try { luces(dt); moverDestino(dt); } catch (e) {}
    try { sombra(dt); } catch (e) { som.s = 0; som.t = 1e9; }
  } else { estado.movAhora = estado.corrAhora = false; if (estado.ctx) { pararVoz(vCarrera); pararVoz(vSusurro); } }   // en pausa no deben seguir sonando los bucles
  actualizarMundo(dt); parpadeoLuces(dt); efectosJugador(dt); actualizarHud(dt);
  camaraSistema(dt);
  renderer.setRenderTarget(rt); renderer.render(scene, cam); renderer.setRenderTarget(null); renderer.render(postScene, postCam);   // escena -> textura -> ojo de pez / visión nocturna / estática
}
requestAnimationFrame(bucle);
