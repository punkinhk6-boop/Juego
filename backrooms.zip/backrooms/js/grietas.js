// GRIETAS — decals raros con un hilo de luz fría (romperlas da Game Over; la lógica está en player.js).
import * as THREE from 'three';

// ================= GRIETAS (decals con un hilo de luz fría dentro) =================
function texGrieta() {
  const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d'), R = Math.random, out = [];
  (function rama(px, py, ang, n, prof) {
    const pts = [[px, py]]; let cx = px, cy = py;
    for (let i = 0; i < n; i++) { ang += (R() - .5) * .9; cx += Math.cos(ang) * 11; cy += Math.sin(ang) * 11; pts.push([cx, cy]); if (prof < 2 && R() < .13) rama(cx, cy, ang + (R() < .5 ? 1 : -1) * (.5 + R() * .7), (n * .45) | 0, prof + 1); }
    out.push(pts);
  })(128, 128, R() * 6.28, 9 + ((R() * 6) | 0), 0);
  const a2 = R() * 6.28; (function rama2() { const pts = [[128, 128]]; let cx = 128, cy = 128, ang = a2 + Math.PI; for (let i = 0; i < 8; i++) { ang += (R() - .5) * .9; cx += Math.cos(ang) * 11; cy += Math.sin(ang) * 11; pts.push([cx, cy]); } out.push(pts); })();
  x.lineCap = x.lineJoin = 'round';
  for (const [w, col] of [[10, 'rgba(8,6,4,.95)'], [2.6, 'rgba(190,220,255,.9)']]) { x.lineWidth = w; x.strokeStyle = col; for (const pts of out) { x.beginPath(); pts.forEach(([a, b], k) => k ? x.lineTo(a, b) : x.moveTo(a, b)); x.stroke(); } }
  return new THREE.CanvasTexture(c);
}
export const GRIETAS = Array.from({ length: 6 }, () => new THREE.MeshBasicMaterial({ map: texGrieta(), transparent: true, depthWrite: false }));
