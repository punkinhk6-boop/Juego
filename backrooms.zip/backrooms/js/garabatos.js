// GARABATOS CON ROTULADOR — frases en varios idiomas y dibujos en las paredes.
import * as THREE from 'three';

// ================= GARABATOS CON ROTULADOR =================
// Frases en varios idiomas ("|" = salto de línea). AÑADE AQUÍ LAS TUYAS. Cada partida usa solo un subconjunto al azar.
const FRASES = [
  // Advertencias
  "NO SIGAS LAS VOCES.", "NO HAY NADA DETRÁS DE VOS.", "NO CONFÍES EN LAS SALIDAS.", "SI ESCUCHÁS UN TELÉFONO, NO CONTESTES.", "NO TE QUEDES EN LA MISMA HABITACIÓN DEMASIADO TIEMPO.",
  "DON'T FOLLOW THE VOICES.", "DON'T LOOK UP.", "IT CAN HEAR YOU.", "NEVER TRUST THE EXIT SIGNS.", "振り返るな。", "НЕ ОБОРАЧИВАЙСЯ.", "НЕ ВЕРЬ УКАЗАТЕЛЯМ.",
  // Notas de gente perdida
  "Llevo horas caminando. No tengo idea de dónde estoy", "Tiene que haber una salida", "Voy a dejar marcas para no perderme", "Si encontrás mis cosas, por favor, llevátelas. No quiero volver", "Mamá, estoy intentando volver a casa",
  "I JUST WANT TO GO HOME.", "I THINK I'M GETTING CLOSER.", "I FOUND MY OWN FOOTPRINTS.", "DAY ONE. I THINK.", "Je veux rentrer chez moi.", "J'ai déjà vu cet endroit.", "Eu só quero ir para casa.", "Estou andando em círculos.",
  // Cosas que no encajan
  "El pasillo era más corto ayer", "¿Por qué hay olor a lluvia?", "Las luces no estaban así cuando llegué", "Hay una habitación que siempre está detrás de mí", "El techo está bajando", "No recuerdo haber escrito esto", "La salida cambia de lugar", "¿Cuánto mide una habitación cuando nadie la mira?",
  "THE WALLS ARE GETTING CLOSER.", "DIE TÜR WAR GESTERN NOCH HIER.", "この廊下は昨日より長い。", "여기 처음 온 게 아니야。", "出口在哪里？",
  // Lo que escribe "algo" más
  "Ya llegaste.", "Te vimos entrar.", "No sos el primero.", "¿Por qué tardaste tanto?", "No te preocupes. Todavía no.", "Esta vez llegó más lejos.", "Seguí caminando. Queremos ver qué hacés.", "¿Todavía creés que estás solo?", "No escribas en las paredes.", "Dejá de leer.", "WE KNOW YOU'RE HERE.", "YOU WEREN'T SUPPOSED TO FIND THIS."
];
const FR = FRASES.filter(() => Math.random() < .5);
while (FR.length < 5) FR.push(FRASES[(Math.random() * FRASES.length) | 0]);
export const gGar = new THREE.PlaneGeometry(1, 1);
// Rotulador: trazo grueso, irregular y repasado dos veces, como hecho con prisa
function trazo(x, pts, grosor) {
  for (let i = 0; i < 2; i++) {
    x.beginPath(); x.lineWidth = grosor * (.8 + Math.random() * .5);
    pts.forEach(([a, b], k) => { const px = a + (Math.random() - .5) * 3, py = b + (Math.random() - .5) * 3; k ? x.lineTo(px, py) : x.moveTo(px, py); });
    x.stroke();
  }
}
// Línea temblorosa entre dos puntos
const linea = (x1, y1, x2, y2, tem = 5) => { const n = Math.max(2, (Math.hypot(x2 - x1, y2 - y1) / 40) | 0), p = []; for (let i = 0; i <= n; i++) p.push([x1 + (x2 - x1) * i / n + (Math.random() - .5) * tem, y1 + (y2 - y1) * i / n + (Math.random() - .5) * tem]); return p; };
const circ = (cx, cy, r, n = 14) => Array.from({ length: n + 3 }, (_, i) => [cx + Math.cos(i / n * 6.28) * r * (.9 + Math.random() * .2), cy + Math.sin(i / n * 6.28) * r * (.9 + Math.random() * .2)]);
const DIBUJOS = [
  // Flechas que no señalan a nada
  (x, w, h) => { for (let i = 1 + ((Math.random() * 3) | 0); i--;) { const a = Math.random() * 6.28, cx = 100 + Math.random() * (w - 200), cy = 70 + Math.random() * (h - 140), L = 60 + Math.random() * 90, ex = cx + Math.cos(a) * L, ey = cy + Math.sin(a) * L; trazo(x, linea(cx, cy, ex, ey, 8), 7); for (const q of [-.5, .5]) trazo(x, [[ex, ey], [ex - Math.cos(a + q) * 32, ey - Math.sin(a + q) * 32]], 7); } },
  // Mapa que no concuerda con nada: habitaciones, un camino absurdo y una X
  (x, w, h) => {
    for (let i = 0; i < 5; i++) { const a = 20 + Math.random() * (w - 140), b = 20 + Math.random() * (h - 100), c = 40 + Math.random() * 90, d = 30 + Math.random() * 60; trazo(x, [[a, b], [a + c, b], [a + c, b + d], [a, b + d], [a, b]], 5); }
    let px = 40, py = 40; const ruta = [[px, py]]; x.setLineDash([14, 10]);
    for (let i = 0; i < 6; i++) { px = Math.max(30, Math.min(w - 30, px + (Math.random() < .5 ? 1 : -1) * 40 * (1 + ((Math.random() * 3) | 0)))); ruta.push([px, py]); py = Math.max(30, Math.min(h - 30, py + 45 * (Math.random() < .5 ? 1 : -1))); ruta.push([px, py]); }
    trazo(x, ruta, 4); x.setLineDash([]);
    const [ex, ey] = ruta[ruta.length - 1]; trazo(x, [[ex - 16, ey - 16], [ex + 16, ey + 16]], 8); trazo(x, [[ex + 16, ey - 16], [ex - 16, ey + 16]], 8);
  },
  // Un ojo
  (x, w, h) => { const cx = w / 2, cy = h / 2; trazo(x, [[cx - 130, cy], [cx - 60, cy - 60], [cx + 60, cy - 60], [cx + 130, cy], [cx + 60, cy + 60], [cx - 60, cy + 60], [cx - 130, cy]], 7); trazo(x, circ(cx, cy, 34), 8); trazo(x, circ(cx, cy, 10), 12); for (let i = 0; i < 5; i++) trazo(x, linea(cx - 100 + i * 50, cy - 80, cx - 90 + i * 45, cy - 110, 3), 5); },
  // Conteo de días: rayas de cinco en cinco
  (x, w, h) => { const n = 6 + ((Math.random() * 16) | 0), y0 = 60 + Math.random() * 30; for (let i = 0; i < n; i++) { const gx = 40 + ((i / 5) | 0) * 75, k = i % 5; if (k < 4) trazo(x, linea(gx + k * 13, y0, gx + k * 13 + Math.random() * 6, y0 + 70, 3), 7); else trazo(x, linea(gx - 6, y0 + 60, gx + 58, y0 + 10, 4), 7); } },
  // Figura de palitos con los brazos larguísimos
  (x, w, h) => { const cx = w / 2; trazo(x, circ(cx, 60, 24), 6); trazo(x, [[cx, 84], [cx + 6, 160]], 7); trazo(x, [[cx - 110, 200], [cx, 110], [cx + 120, 215]], 6); trazo(x, [[cx + 6, 160], [cx - 40, 245]], 7); trazo(x, [[cx + 6, 160], [cx + 50, 245]], 7); }
];
const DB = DIBUJOS.filter(() => Math.random() < .6);
if (!DB.length) DB.push(DIBUJOS[0]);
// Reparte las frases largas en varias líneas (~18 letras cada una); "|" fuerza un salto
function ajustar(f) {
  if (f.includes('|') || f.length <= 18) return f.split('|');
  const n = Math.ceil(f.length / 18), obj = f.length / n, L = [''];
  for (const w of f.split(' ')) { const u = L[L.length - 1]; if (u && (u + ' ' + w).length > obj + 3 && L.length < n) L.push(w); else L[L.length - 1] = u ? u + ' ' + w : w; }
  return L;
}
// Frase escrita letra a letra: tamaño, giro y altura distintos en cada una
function escribir(x, w, h, frase) {
  const L = ajustar(frase), arabe = /[\u0590-\u06FF]/.test(frase), fam = '"Marker Felt","Segoe Print","Bradley Hand","Comic Sans MS","Chalkboard SE",sans-serif';
  let fs = Math.min(100, (h - 50) / L.length * .85);
  x.font = `bold ${fs}px ${fam}`;
  const mx = Math.max(...L.map(l => x.measureText(l).width));
  if (mx > w - 60) { fs *= (w - 60) / mx; x.font = `bold ${fs}px ${fam}`; }
  x.lineWidth = fs * .07;
  const y0 = (h - L.length * fs * 1.1) / 2 + fs * .85;
  L.forEach((l, i) => {
    const py = y0 + i * fs * 1.1 + (Math.random() - .5) * 10; let px = 30 + Math.random() * 30;
    if (arabe) { x.textAlign = 'center'; x.save(); x.translate(w / 2, py); x.rotate((Math.random() - .5) * .1); x.fillText(l, 0, 0); x.strokeText(l, 0, 0); x.restore(); return; }   // el árabe va entero para no romper las letras
    x.textAlign = 'left';
    for (const c of l) {
      const cw = x.measureText(c).width, e = .85 + Math.random() * .35;
      x.save(); x.translate(px, py + (Math.random() - .5) * fs * .25); x.rotate((Math.random() - .5) * .35); x.scale(e, e); x.fillText(c, 0, 0); x.strokeText(c, 0, 0); x.restore();
      px += cw * (.8 + Math.random() * .35);
    }
  });
  if (Math.random() < .4) trazo(x, linea(20, h - 30, w - 30, h - 45 - Math.random() * 25, 6), 6);   // subrayado con prisa
}
export function crearGarabato() {
  const c = document.createElement('canvas'); c.width = 512; c.height = 256;
  const x = c.getContext('2d'); x.fillStyle = x.strokeStyle = 'rgba(10,8,6,.93)'; x.lineCap = x.lineJoin = 'round';
  if (Math.random() < .35) DB[(Math.random() * DB.length) | 0](x, 512, 256); else escribir(x, 512, 256, FR[(Math.random() * FR.length) | 0]);
  const t = new THREE.CanvasTexture(c); t.anisotropy = 4; return t;
}
