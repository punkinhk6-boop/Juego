// ESCENA — renderer, escena, cámara, luz ambiente, niebla y el pool de luces reales.
import * as THREE from 'three';
import { TACTIL } from './config.js';

// ================= ESCENA =================
export const renderer = new THREE.WebGLRenderer({ antialias: !TACTIL });  // en móvil: sin antialias y menos resolución
renderer.setPixelRatio(Math.min(devicePixelRatio, TACTIL ? 1.25 : 1.5));
renderer.setSize(innerWidth, innerHeight);
document.body.prepend(renderer.domElement);
export const scene = new THREE.Scene();
export const FOG_CLARA = new THREE.Color(0x2b2510), FOG_OSCURA = new THREE.Color(0x030302);
scene.fog = new THREE.FogExp2(0x2b2510, 0.05);
export const cam = new THREE.PerspectiveCamera(75, innerWidth / innerHeight, 0.1, 90);
cam.rotation.order = 'YXZ';
export const ambiente = new THREE.AmbientLight(0xffe7a0, 0.4);
scene.add(ambiente);
// Pocas luces reales (caras) que se reasignan a los fluorescentes más cercanos
export const pool = [];
for (let i = 0; i < (TACTIL ? 4 : 6); i++) { const l = new THREE.PointLight(0xfff1b0, 0, 16, 1.6); scene.add(l); pool.push(l); }
export const cv = renderer.domElement;
