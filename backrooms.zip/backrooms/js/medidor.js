// MEDIDOR DE PORCENTAJES y destino de la salida (que se mueve cada ~2 minutos).
import * as THREE from 'three';
import { estado, SZ } from './config.js';
import { cam } from './escena.js';
import { Bx, Cy, mMueble, mueble } from './muebles.js';
import { P } from './player.js';
import { chunks, destruirChunk } from './world.js';
import { som } from './sombra.js';
import { estaticaSonido } from './camara.js';

// ================= MEDIDOR DE PORCENTAJES (el aparato de los Wanderers) =================
// Destino fijo de la partida: un chunk lejano con la puerta blanca o la sala manila. El medidor mide distancia y puntería hacia él.
export function nuevoDestino() {
  const a = Math.random() * 6.2832, d = 260 + Math.random() * 260, cx = Math.floor((14 + Math.sin(a) * d) / SZ), cz = Math.floor((14 + Math.cos(a) * d) / SZ);
  return { cx, cz, tipo: Math.random() < .5 ? 'salida' : 'manila', d0: Math.hypot(cx * SZ + SZ / 2 - 14, cz * SZ + SZ / 2 - 14) };
}
export const DEST = { cx: 1e9, cz: 1e9, tipo: 'salida', d0: 400, activo: false, t: 120 };  // solo existe en modo Fácil
// Modelo chapucero: carcasa verde gastada con capas desiguales y cinta adhesiva, antena parabólica con cable que sale de abajo
const gMed = (() => {
  const cable = new THREE.TubeGeometry(new THREE.CatmullRomCurve3([new THREE.Vector3(0, -.17, -.015), new THREE.Vector3(.01, -.25, .01), new THREE.Vector3(.14, -.23, .02), new THREE.Vector3(.17, -.05, -.01), new THREE.Vector3(.13, .15, -.04), new THREE.Vector3(.075, .235, -.05)]), 28, .0065, 6, false);
  const TC = 0xa39d84, p = [
    [Bx(.26, .34, .05), 0x2f3d33, 0, 0, 0], [Bx(.27, .28, .046), 0x3e4b41, .006, -.02, .002, 0, 0, .035], [Bx(.2, .06, .052), 0x59635a, -.02, .165, 0, 0, 0, -.05],
    [Bx(.23, .165, .012), 0x0f130f, 0, .025, .03],
    [Bx(.034, .016, .012), 0xa33a30, -.07, -.115, .03], [Bx(.034, .016, .012), 0x6b6f6a, 0, -.115, .03], [Bx(.034, .016, .012), 0x6b6f6a, .07, -.115, .03],
    [Bx(.32, .034, .058), TC, 0, .095, 0, 0, 0, .05], [Bx(.32, .034, .058), TC, .005, -.14, 0, 0, 0, -.04], [Bx(.034, .3, .058), TC, -.12, 0, 0, 0, 0, .02], [Bx(.034, .26, .058), TC, .125, .02, 0, 0, 0, -.03], [Bx(.06, .03, .06), TC, .1, .19, -.01, 0, 0, .6],
    [Cy(.011, .011, .1, 8), 0x6b6f6a, .07, .23, -.03], [Bx(.04, .03, .04), TC, .07, .19, -.03, 0, 0, .3],
    [new THREE.SphereGeometry(.075, 14, 6, 0, Math.PI * 2, 0, 1), 0x5a6358, .07, .29, -.07, 0, Math.PI / 2], [Cy(.004, .004, .07, 6), 0x2a2c2a, .07, .29, -.11, 0, Math.PI / 2],
    [cable, 0x111111, 0, 0, 0]];
  return mueble(p);
})();
const cvMed = document.createElement('canvas');
cvMed.width = 1024;
cvMed.height = 680;
const xm = cvMed.getContext('2d'), texMed = new THREE.CanvasTexture(cvMed);
texMed.minFilter = THREE.LinearFilter;
texMed.generateMipmaps = false;
texMed.anisotropy = 8;  // sin mipmaps: el texto se ve nítido
const medModelo = new THREE.Group();
medModelo.add(new THREE.Mesh(gMed, mMueble));
const pantallaMesh = new THREE.Mesh(new THREE.PlaneGeometry(.215, .145), new THREE.MeshBasicMaterial({ map: texMed, fog: false }));
pantallaMesh.position.set(0, .025, .0375);
medModelo.add(pantallaMesh);
medModelo.scale.setScalar(.8);
medModelo.visible = false;
cam.add(medModelo);
let medU = 0, medT = 0, medCong = 0, medFalla = false;
export function poseMed() {
  const e = estado.medPos * estado.medPos * (3 - 2 * estado.medPos); medModelo.visible = estado.medPos > .02;
  medModelo.position.set(.02 + .1 * (1 - e) + Math.sin(estado.tfase * 1.3) * .004, -.22 - .55 * (1 - e), -.5); medModelo.rotation.set(-.45 - .5 * (1 - e), -.15 * (1 - e), .1 * (1 - e));
}
export function calcMed(dt) {   // u (0..1) = cercanía x puntería; se suaviza para que suba y baje de forma progresiva
  const dx = DEST.cx * SZ + SZ / 2 - P.x, dz = DEST.cz * SZ + SZ / 2 - P.z, d = Math.hypot(dx, dz) || 1;
  let prox = Math.pow(Math.max(0, Math.min(1, 1 - d / 800)), 1.4);   // curva algo cóncava: marca bajo hasta que te acercas de verdad
  if (Math.floor(P.x / SZ) === DEST.cx && Math.floor(P.z / SZ) === DEST.cz) prox = Math.max(prox, .9 + .1 * (1 - Math.min(1, d / 17)));
  const cosA = d < 6 ? 1 : (dx * -Math.sin(P.yaw) + dz * -Math.cos(P.yaw)) / d, ali = Math.pow(Math.max(0, cosA), 2);
  medU += (prox * (.15 + .85 * ali) - medU) * Math.min(1, dt * 2.5);
}
const VERDE = '#7dff8f', TENUE = '#2f8a44';
function ecuacion(x, cx, y) {   // ε(x→y) = γx·βx + γy·βy, con subíndices (siempre igual), en grande
  const T = [['ε', 'x→y'], [' = '], ['γ', 'x'], ['·'], ['β', 'x'], [' + '], ['γ', 'y'], ['·'], ['β', 'y']], F1 = 'italic bold 84px "Times New Roman", serif', F2 = 'bold 42px "Courier New", monospace';
  let ancho = 0; for (const [a, b] of T) { x.font = F1; ancho += x.measureText(a).width; if (b) { x.font = F2; ancho += x.measureText(b).width + 2; } }
  let px = cx - ancho / 2; x.textAlign = 'left'; x.fillStyle = VERDE;
  for (const [a, b] of T) { x.font = F1; x.fillText(a, px, y); px += x.measureText(a).width; if (b) { x.font = F2; x.fillText(b, px, y + 20); px += x.measureText(b).width + 2; } }
}
function pantallaMedidor(v, eps, txtEps, color) {
  const x = xm, W = 1024, H = 680;
  x.fillStyle = '#06130a'; x.fillRect(0, 0, W, H);
  ecuacion(x, W / 2, 100);
  x.fillStyle = TENUE; x.fillRect(50, 138, W - 100, 4);
  x.fillStyle = color; x.textAlign = 'left'; x.font = 'bold 60px "Courier New", monospace';
  x.fillText('γx=' + v[0] + '  βx=' + v[1], 56, 218); x.fillText('γy=' + v[2] + '  βy=' + v[3], 56, 292);
  x.textAlign = 'center'; x.font = 'bold 208px "Courier New", monospace'; x.fillText(txtEps, W / 2, 530);
  x.strokeStyle = TENUE; x.lineWidth = 6; x.strokeRect(50, 574, W - 100, 48); x.fillRect(58, 582, Math.max(0, (W - 116) * Math.min(1, eps)), 32);
  for (let y = 0; y < H; y += 6) { x.fillStyle = 'rgba(0,0,0,.10)'; x.fillRect(0, y, W, 2); }
}
export function dibujarMed(dt) {
  const falla = som.s === 1;   // la sombra está encima: el aparato falla hasta que la mires y desaparezca
  if (falla && !medFalla) { medCong = .5; estaticaSonido(.2, .07); }
  medFalla = falla;
  if (medCong > 0) { medCong -= dt; return; }        // congelada: se queda con la última imagen
  if ((medT -= dt) > 0) return;
  const R = Math.random, f2 = n => n.toFixed(2);
  if (!falla) {
    medT = .066;
    const gx = .13 * (1 - medU) + .01, bx = .152 * (1 - medU) + .02, gy = .05 + .95 * medU, by = .05 + .95 * medU, eps = Math.min(1, gx * bx + gy * by);
    pantallaMedidor([f2(gx), f2(bx), f2(gy), f2(by)], eps, (eps * 100).toFixed(1) + '%', VERDE);
  } else {
    medT = .04 + R() * .2;
    if (R() < .12) { medCong = .15 + R() * .4; return; }   // se vuelve a congelar un momento
    const m = R(), x = xm;
    if (m < .4) {   // ERR a pantalla completa
      x.fillStyle = R() < .5 ? '#1a0000' : '#000'; x.fillRect(0, 0, 1024, 680); x.fillStyle = '#ff3b30'; x.textAlign = 'center';
      x.font = 'bold 300px "Courier New", monospace'; x.fillText('ERR', 512 + (R() - .5) * 48, 380);
      x.font = 'bold 48px "Courier New", monospace'; x.fillText('SEÑAL 0x' + ((R() * 65535) | 0).toString(16).toUpperCase().padStart(4, '0') + ' PERDIDA', 512, 504);
    } else {        // valores caóticos y 999.9%
      const c = R() < .5 ? '#ff3b30' : VERDE;
      pantallaMedidor([f2(R() * 9.99), f2(R() * 9.99), f2(-R() * 3), f2(R() * 99)], 1, R() < .6 ? '999.9%' : ((R() * 1000) | 0) + '.' + ((R() * 10) | 0) + '%', c);
    }
    for (let k = 0; k < 6; k++) { const y = (R() * 680) | 0, h = 8 + ((R() * 48) | 0); x.drawImage(cvMed, 0, y, 1024, h, (R() - .5) * 180, y, 1024, h); }   // rebanadas desplazadas
    for (let k = 0; k < 60; k++) { x.fillStyle = 'rgba(255,255,255,' + R() * .5 + ')'; x.fillRect(R() * 1024, R() * 680, 4 + R() * 80, 4); }
  }
  texMed.needsUpdate = true;
}
// Modo Fácil: la salida cambia de sitio cada ~2 min respecto a ti: se queda, más lejos, más cerca, desviada o al lado contrario (misma distancia)
export function moverDestino(dt) {
  if (!DEST.activo || (DEST.t -= dt) > 0) return;
  const dx = DEST.cx * SZ + SZ / 2 - P.x, dz = DEST.cz * SZ + SZ / 2 - P.z, d = Math.hypot(dx, dz);
  if (d < 45) { DEST.t = 10; return; }   // si estás a punto de llegar no te la quitan
  const a = Math.atan2(dx, dz), u = Math.random(); let ang = a, dist = d;
  if (u < .2) { DEST.t = 100 + Math.random() * 40; return; }
  if (u < .45) dist = d * (1.3 + Math.random() * .5);
  else if (u < .65) dist = d * (.55 + Math.random() * .3);
  else if (u < .85) ang = a + (Math.random() < .5 ? 1 : -1) * (1 + Math.random() * 1.1);
  else ang = a + Math.PI;
  dist = Math.max(135, Math.min(720, dist));   // siempre fuera de la zona cargada, así el chunk nuevo se genera ya con la salida
  Object.assign(DEST, { cx: Math.floor((P.x + Math.sin(ang) * dist) / SZ), cz: Math.floor((P.z + Math.cos(ang) * dist) / SZ), tipo: Math.random() < .5 ? 'salida' : 'manila', t: 100 + Math.random() * 40 });
  const k = DEST.cx + ',' + DEST.cz; if (chunks.has(k)) destruirChunk(k, chunks.get(k));   // si justo estaba cargado (en el borde), se regenera ya con la salida
}
