// MUEBLES DE OFICINA — constructor de piezas (`mueble`) y prototipos con su colisión.
import * as THREE from 'three';
import { H } from './config.js';

// ================= MUEBLES DE OFICINA =================
// Cada mueble se construye una vez con varias piezas (cajas/cilindros con color) unidas en UNA geometría: se dibuja de un solo golpe
export const Bx = (a, b, c) => new THREE.BoxGeometry(a, b, c), Cy = (r1, r2, h, n = 12) => new THREE.CylinderGeometry(r1, r2, h, n);
export function mueble(piezas) {
  const pos = [], nor = [], col = [], idx = [], c = new THREE.Color(), m = new THREE.Matrix4(); let base = 0;
  for (const [g, color, x, y, z, ry = 0, rx = 0, rz = 0] of piezas) {   // pieza: [geometría, color, x, y, z, giro Y, giro X]
    g.applyMatrix4(m.makeRotationFromEuler(new THREE.Euler(rx, ry, rz, 'YXZ')).setPosition(x, y, z));
    const p = g.attributes.position, nr = g.attributes.normal; c.set(color);
    for (let i = 0; i < p.count; i++) { pos.push(p.getX(i), p.getY(i), p.getZ(i)); nor.push(nr.getX(i), nr.getY(i), nr.getZ(i)); col.push(c.r, c.g, c.b); }
    for (const i of g.index.array) idx.push(i + base);
    base += p.count;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); geo.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3)); geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3)); geo.setIndex(idx);
  return geo;
}
export const K = { mad: 0x8a6a3c, madO: 0x5b4126, met: 0x7c8083, gri: 0x45494c, bei: 0xb9af97, tela: 0x6a7b77, car: 0xa27d4c, neg: 0x1b1b1b, pan: 0x14221a, azu: 0x5f8fb0, bla: 0xcfcab9, rojo: 0x8a3a30, verd: 0x3f5a46, azo: 0x3d4f70 };
const rnd = a => (Math.random() - .5) * a;
// Escritorio con cajonera y, encima, monitor CRT + teclado (o teléfono y papeles)
export const escritorio = crt => {
  const p = [[Bx(1.6, .05, .75), K.mad, 0, .75, 0], [Bx(.04, .72, .7), K.madO, .76, .36, 0], [Bx(1.5, .42, .03), K.madO, 0, .5, -.34], [Bx(.44, .72, .7), K.madO, -.57, .36, 0]];
  for (let k = 0; k < 3; k++) p.push([Bx(.38, .19, .02), K.mad, -.57, .13 + k * .23, .355], [Bx(.14, .025, .03), K.neg, -.57, .2 + k * .23, .375]);
  if (crt) p.push([Bx(.42, .36, .4), K.bei, .15, .955, -.12], [Bx(.32, .26, .02), K.pan, .15, .96, .09], [Bx(.44, .025, .16), K.bei, .15, .79, .2], [Bx(.14, .08, .1), K.bei, .47, .8, .05]);
  else p.push([Bx(.26, .08, .22), K.neg, .5, .8, .1], [Bx(.32, .05, .24), K.bla, -.1, .8, .05], [Bx(.28, .04, .2), K.bla, -.1, .85, .04, .2]);
  return { g: mueble(p), hx: .85, hz: .4, esc: true };
};
// Silla de oficina giratoria: asiento, respaldo inclinado, apoyabrazos, columna y base de estrella
export const silla = tela => {
  const p = [[Bx(.5, .07, .5), tela, 0, .5, 0], [Bx(.46, .52, .06), tela, 0, .82, -.24, 0, -.12], [Cy(.035, .035, .42, 8), K.gri, 0, .27, 0], [Bx(.05, .05, .3), K.gri, -.28, .66, -.02], [Bx(.05, .05, .3), K.gri, .28, .66, -.02], [Bx(.04, .16, .04), K.gri, -.28, .58, .08], [Bx(.04, .16, .04), K.gri, .28, .58, .08]];
  for (let k = 0; k < 3; k++) p.push([Bx(.62, .035, .06), K.gri, 0, .06, 0, k * Math.PI / 3]);
  return { g: mueble(p), hx: .32, hz: .32, libre: true };
};
// Archivador metálico de n cajones con tiradores
const archivador = n => {
  const h = n * .33 + .1, p = [[Bx(.46, h, .62), K.met, 0, h / 2, 0]];
  for (let k = 0; k < n; k++) p.push([Bx(.42, .29, .02), 0x8d9194, 0, .18 + k * .33, .315], [Bx(.2, .03, .03), K.neg, 0, .26 + k * .33, .34]);
  return { g: mueble(p), hx: .25, hz: .33 };
};
// Estantería con baldas y libros/carpetas de colores apagados
export const estanteria = () => {
  const p = [[Bx(.03, 1.9, .3), K.mad, -.44, .95, 0], [Bx(.03, 1.9, .3), K.mad, .44, .95, 0], [Bx(.9, .03, .3), K.mad, 0, 1.9, 0], [Bx(.86, 1.9, .01), K.madO, 0, .95, -.15]], lib = [K.rojo, K.verd, K.azo, K.car, K.bla, K.madO];
  for (let s = 0; s < 4; s++) {
    const y = .05 + s * .46; p.push([Bx(.86, .025, .28), K.mad, 0, y, 0]); let x = -.4;
    while (x < .38) { if (Math.random() < .2) { x += .12; continue; } const w = .03 + Math.random() * .05, h = .22 + Math.random() * .12; p.push([Bx(w, h, .2), lib[(Math.random() * 6) | 0], x + w / 2, y + .0125 + h / 2, 0]); x += w + .005; }
  }
  return { g: mueble(p), hx: .46, hz: .17 };
};
// Panel divisorio de cubículo
const cubiculo = () => ({ g: mueble([[Bx(1.7, 1.45, .06), K.tela, 0, 1, 0], [Bx(1.74, .05, .09), K.gri, 0, 1.75, 0], [Bx(.06, .3, .5), K.gri, -.8, .15, 0], [Bx(.06, .3, .5), K.gri, .8, .15, 0]]), hx: .88, hz: .25 });
// Fotocopiadora: cuerpo, tapa, cristal, panel de control y bandeja
const fotocopiadora = () => ({ g: mueble([[Bx(.9, .9, .7), K.bei, 0, .45, 0], [Bx(.92, .06, .72), K.gri, 0, .93, 0], [Bx(.5, .015, .36), 0x9fb3a8, -.1, .965, 0], [Bx(.3, .03, .18), K.neg, .28, .95, .24, 0, -.25], [Bx(.7, .08, .3), K.gri, 0, .35, .46], [Bx(.2, .45, .03), K.gri, -.35, .45, .36]]), hx: .48, hz: .55 });
// Dispensador de agua con garrafón
const dispensador = () => ({ g: mueble([[Bx(.34, .9, .34), K.bla, 0, .45, 0], [Cy(.15, .15, .42), K.azu, 0, 1.12, 0], [Cy(.07, .12, .08), K.azu, 0, 1.37, 0], [Bx(.08, .04, .06), K.rojo, -.07, .82, .18], [Bx(.08, .04, .06), K.azo, .07, .82, .18]]), hx: .2, hz: .2 });
// Cajas de cartón apiladas (con cinta en la tapa)
const cajas = n => {
  const p = []; let y = 0;
  for (let k = 0; k < n; k++) { const w = .75 - k * .12, h = .4 + Math.random() * .12, d = .55 - k * .06, ox = rnd(.08), oz = rnd(.06), ro = rnd(.3); p.push([Bx(w, h, d), K.car, ox, y + h / 2, oz, ro], [Bx(w * .14, .006, d + .004), 0xc9b48a, ox, y + h + .003, oz, ro]); y += h; }
  return { g: mueble(p), hx: .42, hz: .36 };
};
export const papelera = () => ({ g: mueble([[Cy(.19, .15, .36), K.gri, 0, .18, 0], [Cy(.2, .2, .02), K.neg, 0, .36, 0]]), hx: .21, hz: .21 });
const pilar = () => ({ g: mueble([[Bx(.6, H, .6), 0xb7ab74, 0, H / 2, 0], [Bx(.68, .14, .68), K.madO, 0, .07, 0], [Bx(.66, .05, .66), 0xa89c66, 0, H - .025, 0]]), hx: .35, hz: .35 });
// Lista con repeticiones = más probabilidad de que salgan escritorios, sillas, archivadores...
export const PROTOS = [escritorio(true), escritorio(false), escritorio(true), silla(K.gri), silla(K.azo), silla(K.neg), silla(K.verd), archivador(4), archivador(2), archivador(4), estanteria(), estanteria(), cubiculo(), cubiculo(), fotocopiadora(), dispensador(), cajas(1), cajas(2), cajas(3), papelera(), papelera(), pilar(), pilar()];
export const mMueble = new THREE.MeshLambertMaterial({ vertexColors: true });
