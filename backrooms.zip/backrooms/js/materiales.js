// MATERIALES Y GEOMETRÍAS compartidos, más los maniquíes (poses desde assets/maniqui.bin; modelo de SketchPunk, CC BY 4.0).
import * as THREE from 'three';
import { C, H, SZ, T } from './config.js';
import { texMuro, texSuelo, texTecho } from './texturas.js';

// ================= MATERIALES Y GEOMETRÍAS (compartidos) =================
export const mMuro = new THREE.MeshLambertMaterial({ map: texMuro });
export const mSuelo = new THREE.MeshLambertMaterial({ map: texSuelo });
export const mTecho = new THREE.MeshLambertMaterial({ map: texTecho });
export const mLuz = new THREE.MeshBasicMaterial({ color: 0xffffff });
const mManiqui = new THREE.MeshLambertMaterial({ color: 0xd8d0bc, emissive: 0x1a1710, side: THREE.DoubleSide });
const mProp = [0x6b5030, 0x555048, 0x3f4a3c, 0x7a6a48].map(c => new THREE.MeshLambertMaterial({ color: c }));
export const gMuro = new THREE.BoxGeometry(C + T, H, T);
export const gSuelo = new THREE.PlaneGeometry(SZ, SZ).rotateX(-Math.PI / 2);
export const gTecho = new THREE.PlaneGeometry(SZ, SZ).rotateX(Math.PI / 2);
export const gLuz = new THREE.PlaneGeometry(1.8, 0.7).rotateX(Math.PI / 2);
const gCubo = new THREE.BoxGeometry(1, 1, 1);
// Maniquí: modelo "Mannequin Female" (SketchPunk, CC BY 4.0). Las poses se calcularon desde su esqueleto y van incrustadas en el archivo
const MQ_V = 15560, MQ_I = 91050, MQ_N = 8;
const POSES = await (async () => {
  const u8 = new Uint8Array(await (await fetch(new URL('../assets/maniqui.bin', import.meta.url))).arrayBuffer());
  const idx = new THREE.BufferAttribute(new Uint16Array(u8.buffer, 0, MQ_I), 1), geos = [];
  for (let p = 0; p < MQ_N; p++) {
    const q = new Int16Array(u8.buffer, MQ_I * 2 + p * MQ_V * 6, MQ_V * 3), pos = new Float32Array(MQ_V * 3);
    for (let i = 0; i < pos.length; i++) pos[i] = q[i] / 10000;
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3)); geo.setIndex(idx);
    geo.computeVertexNormals(); geo.computeBoundingSphere(); geos.push(geo);
  }
  return geos;
})();
// Muebles/objetos: medias dimensiones de colisión + partes [sx,sy,sz,px,py,pz]
const PROPS = [
  { hx: .6, hz: .6, p: [[1.1, 1, 1.1, 0, .5, 0]] },                                                  // caja
  { hx: .3, hz: .3, p: [[.6, H, .6, 0, H / 2, 0]] },                                                 // pilar
  { hx: .3, hz: .4, p: [[.5, 1.5, .7, 0, .75, 0]] },                                                 // archivador
  { hx: .8, hz: .4, p: [[1.6, .08, .8, 0, .76, 0], [.08, .72, .8, -.76, .36, 0], [.08, .72, .8, .76, .36, 0]] } // escritorio
];
// Maniquí: una de las poses del modelo, a veces reflejada
export function crearManiqui(r) {
  const g = new THREE.Group(), m = new THREE.Mesh(POSES[(r() * POSES.length) | 0], mManiqui);
  if (r() < .5) m.scale.x = -1;   // reflejo: duplica la variedad de poses
  g.add(m); g.rotation.order = 'YXZ';
  return g;
}
