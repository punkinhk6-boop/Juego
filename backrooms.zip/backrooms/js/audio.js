// AUDIO — contexto Web Audio, zumbido de fluorescentes, voces en bucle y carga de los mp3 (assets/audio).
import { estado } from './config.js';
import { P } from './player.js';
import { VOL } from './ajustes.js';

// ================= AUDIO: zumbido de fluorescentes =================
export function iniciarAudio() {
  if (estado.hum) return;
  const a = estado.ctx = new (window.AudioContext || window.webkitAudioContext)(); estado.hum = a.createGain(); estado.hum.gain.value = .05; estado.hum.connect(a.destination);
  [[60, .5, 'sawtooth'], [120, .25, 'sawtooth'], [121.7, .25, 'sawtooth'], [2400, .01, 'sine']].forEach(([f, v, tipo]) => {
    const o = a.createOscillator(), g = a.createGain(); o.type = tipo; o.frequency.value = f; g.gain.value = v; o.connect(g).connect(estado.hum); o.start();
  });
}
// Panorama estéreo según la dirección de la fuente respecto a hacia dónde miras (-1 izq, +1 der)
export const panDe = (dx, dz) => (dx * Math.cos(P.yaw) - dz * Math.sin(P.yaw)) / (Math.hypot(dx, dz) || 1);
// Voz sintetizada: dos dientes de sierra con vibrato + filtro + eco largo (efecto "cañón")
export function prepararVoz() {
  try { cargarAudios(); } catch (e) {}
  const osc = tipo => { const o = estado.ctx.createOscillator(); o.type = tipo; return o; };
  const o1 = osc('sawtooth'), o2 = osc('sawtooth'), lfo = osc('sine');
  o2.detune.value = 9; lfo.frequency.value = 5.2;
  const prof = estado.ctx.createGain(); prof.gain.value = 7;                  // profundidad del vibrato (Hz)
  lfo.connect(prof); prof.connect(o1.frequency); prof.connect(o2.frequency);
  const mezcla = estado.ctx.createGain(), env = estado.ctx.createGain(), lp = estado.ctx.createBiquadFilter(), pan = estado.ctx.createStereoPanner(), out = estado.ctx.createGain();
  mezcla.gain.value = .5; env.gain.value = 0; lp.type = 'lowpass'; lp.Q.value = 3;
  o1.connect(mezcla); o2.connect(mezcla); mezcla.connect(lp); lp.connect(env); env.connect(pan); pan.connect(out); out.connect(estado.ctx.destination);
  const ret = estado.ctx.createDelay(1), fb = estado.ctx.createGain(), fl = estado.ctx.createBiquadFilter(), eco = estado.ctx.createGain();
  ret.delayTime.value = .45; fb.gain.value = .5; fl.type = 'lowpass'; fl.frequency.value = 900; eco.gain.value = .25;
  out.connect(ret); ret.connect(fl); fl.connect(fb); fb.connect(ret); fl.connect(eco); eco.connect(estado.ctx.destination);
  [o1, o2, lfo].forEach(o => o.start());
  estado.voz = { o1, o2, env, lp, pan, out, mezcla };
}
// ----- Sonidos reales (mp3 incrustados): se decodifican al empezar; si algo falla se usan los sintetizados -----
export const AUD = { aull: [], corr: null, susu: null, amb: null, resp: null, gotas: null, golp1: null, golp2: null }, vCarrera = {}, vSusurro = {};
export function cargarAudios() {
  if (cargarAudios.hecho) return; cargarAudios.hecho = true;
  const dec = nombre => fetch(new URL('../assets/audio/' + nombre, import.meta.url)).then(r => r.arrayBuffer()).then(b => estado.ctx.decodeAudioData(b));
  ['aullido1.mp3', 'aullido2.mp3', 'aullido3.mp3', 'aullido4.mp3'].forEach(n => dec(n).then(buf => AUD.aull.push(buf)).catch(() => {}));
  dec('corriendo.mp3').then(b => AUD.corr = b).catch(() => {}); dec('susurros.mp3').then(b => AUD.susu = b).catch(() => {});
  for (const [k, n] of [['amb', 'ambiente.mp3'], ['resp', 'respiracion.mp3'], ['gotas', 'gotas.mp3'], ['golp1', 'golpes1.mp3'], ['golp2', 'golpes2.mp3']]) dec(n).then(b => AUD[k] = b).catch(() => {});
}
// Voz en bucle (carrera del lobo, susurros de la sombra) con volumen y panorama que se actualizan en cada fotograma
export function bucleVoz(v, buf, vol, pan, rate) {
  if (!v.src) {
    const s = estado.ctx.createBufferSource(), g = estado.ctx.createGain(), p = estado.ctx.createStereoPanner();
    s.buffer = buf; s.loop = true; s.loopEnd = Math.max(1, buf.duration - 1.2); g.gain.value = 0;
    s.connect(g); g.connect(p); p.connect(estado.ctx.destination); s.start(0, Math.random() * s.loopEnd); Object.assign(v, { src: s, g, p });
  }
  v.g.gain.setTargetAtTime(vol * VOL.ent, estado.ctx.currentTime, .08); v.p.pan.value = pan; v.src.playbackRate.value = rate || 1;
}
export function pararVoz(v) { if (!v.src) return; const t = estado.ctx.currentTime; v.g.gain.setTargetAtTime(0, t, .15); v.src.stop(t + 1); v.src = null; }
