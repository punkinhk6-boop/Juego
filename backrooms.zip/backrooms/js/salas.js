// SALAS ESPECIALES — materiales y geometrías (sala manila, vacío, arcos, pasillo de marcos, puerta de salida).
import * as THREE from 'three';
import { C, H, SZ, T } from './config.js';
import { lienzo, ruido } from './texturas.js';
import { Bx, Cy, escritorio, K, mueble, papelera, silla } from './muebles.js';

// ================= SALAS ESPECIALES: materiales y geometrías =================
const texManila = lienzo(256, 256, (x, w, h) => { x.fillStyle = '#d9c48a'; x.fillRect(0, 0, w, h); ruido(x, w, h, 2500, () => `rgba(120,95,40,${Math.random() * .16})`); for (let i = 0; i < h; i += 32) { x.fillStyle = 'rgba(150,120,60,.08)'; x.fillRect(0, i, w, 2); } }, 3, 1.5);
export const mManila = new THREE.MeshLambertMaterial({ map: texManila }), mCrema = new THREE.MeshLambertMaterial({ color: 0xcfc3a0 });
const texBeige = lienzo(512, 512, (x, w, h) => { x.fillStyle = '#9e957c'; x.fillRect(0, 0, w, h); for (let i = 0; i < 26000; i++) { const t = Math.random(), a = .2 + Math.random() * .3; x.fillStyle = t < .45 ? `rgba(70,64,48,${a})` : `rgba(190,180,150,${a * .8})`; x.fillRect(Math.random() * w, Math.random() * h, 1 + Math.random() * 1.5, 1 + Math.random() * 3); } }, SZ / 2, SZ / 2);
export const mSueloBeige = new THREE.MeshLambertMaterial({ map: texBeige });
// Pared con vano en arco (un tramo de arcada): silueta con muesca redondeada desde abajo, extruida
export const gArco = (() => {
  const sh = new THREE.Shape(), hw = (C + T) / 2;
  sh.moveTo(-hw, 0); sh.lineTo(-1.1, 0); sh.lineTo(-1.1, 1.5); sh.absarc(0, 1.5, 1.1, Math.PI, 0, true); sh.lineTo(1.1, 0); sh.lineTo(hw, 0); sh.lineTo(hw, H); sh.lineTo(-hw, H); sh.lineTo(-hw, 0);
  return new THREE.ExtrudeGeometry(sh, { depth: T, bevelEnabled: false, curveSegments: 14 }).translate(0, 0, -T / 2);
})();
// Sala de huecos: 5x5 huecos cuadrados simétricos de 2,1 u. con tiras de suelo de ~0,9 u. (justo para caminar)
export const HS = 2.1, ST = (4 * C - 5 * HS) / 6, HUECOS_L = [];
for (let a = 0; a < 5; a++) for (let b = 0; b < 5; b++) HUECOS_L.push([-8 + ST + a * (HS + ST), -8 + ST + b * (HS + ST)]);  // esquina de cada hueco, con el origen en el centro del chunk
export const gSueloHuecos = (() => {
  const sh = new THREE.Shape(); sh.moveTo(-SZ / 2, -SZ / 2); sh.lineTo(SZ / 2, -SZ / 2); sh.lineTo(SZ / 2, SZ / 2); sh.lineTo(-SZ / 2, SZ / 2); sh.lineTo(-SZ / 2, -SZ / 2);
  for (const [hx, hz] of HUECOS_L) { const q = new THREE.Path(); q.moveTo(hx, hz); q.lineTo(hx, hz + HS); q.lineTo(hx + HS, hz + HS); q.lineTo(hx + HS, hz); q.lineTo(hx, hz); sh.holes.push(q); }
  const g = new THREE.ShapeGeometry(sh), uv = g.attributes.uv, ps = g.attributes.position;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, ps.getX(i) / SZ + .5, ps.getY(i) / SZ + .5);
  return g.rotateX(-Math.PI / 2);
})();
export const gVacio = mueble(HUECOS_L.map(([hx, hz]) => [Bx(HS, 6, HS), 0x000000, hx + HS / 2, -3, hz + HS / 2])), mVacio = new THREE.MeshBasicMaterial({ color: 0x000000, side: THREE.BackSide, fog: false });
// Sala de arcos: objetos de limpieza y algo de mobiliario
const contenedor = () => ({ g: mueble([[Bx(1.2, .95, .7), 0x3b5a40, 0, .6, 0], [Bx(1.24, .06, .74), 0x2a4030, 0, 1.1, 0], [Bx(.08, .12, .08), K.neg, -.5, .06, .3], [Bx(.08, .12, .08), K.neg, .5, .06, .3], [Bx(.08, .12, .08), K.neg, -.5, .06, -.3], [Bx(.08, .12, .08), K.neg, .5, .06, -.3]]), hx: .65, hz: .4 });
const escoba = () => ({ g: mueble([[Cy(.012, .012, 1.5, 6), K.mad, 0, .74, 0, 0, .1], [Bx(.28, .1, .07), 0xb59b5a, 0, .05, .08]]), hx: .16, hz: .16 });
const recogedor = () => ({ g: mueble([[Bx(.3, .025, .28), K.gri, 0, .015, 0], [Bx(.3, .07, .02), K.gri, 0, .045, .14], [Bx(.03, .03, .3), K.gri, 0, .04, -.28]]), hx: .17, hz: .3 });
const trapeador = () => ({ g: mueble([[Cy(.012, .012, 1.4, 6), K.mad, 0, .72, 0, 0, .08], [Cy(.07, .1, .16, 8), 0xd9d6c8, 0, .09, .06]]), hx: .13, hz: .13 });
const cubo = () => ({ g: mueble([[Cy(.17, .13, .3, 12), K.azu, 0, .15, 0], [Bx(.34, .02, .02), K.gri, 0, .32, 0]]), hx: .19, hz: .19 });
export const PROTOS_ARCOS = [papelera(), papelera(), contenedor(), contenedor(), escoba(), escoba(), recogedor(), trapeador(), trapeador(), cubo(), cubo(), cubo(), escritorio(false), silla(K.gri)];
// Marcos de puerta amarillos sin puerta, y la puerta blanca de salida
export const gMarco = mueble([[Bx(.3, 2.3, .2), 0xc4ad4e, 0, 1.15, -.7], [Bx(.3, 2.3, .2), 0xc4ad4e, 0, 1.15, .7], [Bx(.3, .22, 1.6), 0xc4ad4e, 0, 2.4, 0]]);
export const gPuerta = mueble([[Bx(.08, 2.2, .1), 0xe9e7df, -.52, 1.1, .05], [Bx(.08, 2.2, .1), 0xe9e7df, .52, 1.1, .05], [Bx(1.12, .08, .1), 0xe9e7df, 0, 2.24, .05], [Bx(.96, 2.1, .05), 0xf1efe8, 0, 1.05, .04], [Bx(.34, .8, .01), 0xdcdad2, -.2, 1.55, .07], [Bx(.34, .8, .01), 0xdcdad2, .2, 1.55, .07], [Bx(.34, .7, .01), 0xdcdad2, -.2, .55, .07], [Bx(.34, .7, .01), 0xdcdad2, .2, .55, .07], [Bx(.06, .06, .06), 0xb59b3a, .36, 1, .1]]);
export const mPuerta = new THREE.MeshLambertMaterial({ vertexColors: true, emissive: 0x2a2a28 });
