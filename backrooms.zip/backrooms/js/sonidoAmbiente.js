// AMBIENTE SONORO — ambiente, respiración, gotas y golpes lejanos (mp3).
import { estado } from './config.js';
import { AUD } from './audio.js';
import { cine } from './cinematica.js';
import { VOL } from './ajustes.js';
import { M } from './menu.js';

// ================= AMBIENTE, RESPIRACIÓN, GOTAS Y GOLPES LEJANOS (mp3 incrustados) =================
let ambV = null, respV = null, ambFase = 0, esf = 0, gotasT = 25 + Math.random() * 20, golpT = 70 + Math.random() * 60;
const GOLPES2_T = [1.5, 3.5, 5.5, 7, 8.75, 10, 11.5];  // instantes de los golpes dentro de Golpes2 (para sacar tandas de 1 a 3)
function bucleSimple(buf, fin) {   // fuente en bucle con control de volumen
  const s = estado.ctx.createBufferSource(), g = estado.ctx.createGain(); s.buffer = buf; s.loop = true; if (fin) s.loopEnd = fin; g.gain.value = 0;
  s.connect(g); g.connect(estado.ctx.destination); s.start(0, Math.random() * (fin || buf.duration)); return { s, g };
}
// El ambiente va por debajo del zumbido y "respira" despacio (volumen y velocidad casi imperceptibles) para no sentirse plano.
export function ambienteLoop(dt) {
  if (!estado.ctx || !AUD.amb) return;
  if (!ambV) ambV = bucleSimple(AUD.amb);
  ambFase += dt * .07;
  const base = M.act ? .3 * VOL.amb : estado.activo && !(cine.act && cine.t < 18.2) ? .42 * VOL.amb : 0;   // en la casa de la cinemática no suena
  ambV.g.gain.setTargetAtTime(base * (1 + .25 * Math.sin(ambFase) * Math.sin(ambFase * .37 + 1)) * (1 + .5 * estado.osc), estado.ctx.currentTime, .6);
  ambV.s.playbackRate.value = 1 + .012 * Math.sin(ambFase * .6);
}
// Respiración: sube rápido al correr, se recupera despacio, y aparece con la paranoia alta y al despertar en la cinemática.
export function respiracion(dt) {
  if (!estado.ctx || !AUD.resp) return;
  if (!respV) respV = bucleSimple(AUD.resp, Math.max(1, AUD.resp.duration - .1));
  const juego = estado.activo && !cine.act, corriendo = juego && estado.corrAhora;
  esf += ((corriendo ? 1 : 0) - esf) * Math.min(1, dt * (corriendo ? 1.5 : .3));
  const pn = Math.max(0, (estado.par - .55) / .45), nivel = juego ? Math.max(esf, pn, estado.calmando ? .55 : 0) : (estado.activo && cine.act ? (cine.resp || 0) : 0);
  respV.g.gain.setTargetAtTime(nivel * .85 * VOL.jug, estado.ctx.currentTime, .2); respV.s.playbackRate.value = juego && estado.calmando ? .8 : 1 + .22 * Math.max(esf, pn);   // calmándote respira lento y hondo
}
// Sonido suelto y lejano: trozo del clip con fundidos, panorama al azar y filtro paso bajo (distancia)
function sonidoLejano(buf, off, dur, vol, lp, k = 1) {
  vol *= k;
  const t = estado.ctx.currentTime, s = estado.ctx.createBufferSource(), g = estado.ctx.createGain(), f = estado.ctx.createBiquadFilter(), pn = estado.ctx.createStereoPanner();
  s.buffer = buf; f.type = 'lowpass'; f.frequency.value = lp; pn.pan.value = (Math.random() - .5) * 1.6;
  g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol, t + .04); g.gain.setValueAtTime(vol, t + Math.max(.05, dur - .8)); g.gain.linearRampToValueAtTime(0, t + dur);
  s.connect(f); f.connect(g); g.connect(pn); pn.connect(estado.ctx.destination); s.start(t, off, dur);
}
export function ambienteSonoro(dt) {   // gotas (cada ~30-80 s, flojitas) y golpes (rarísimos; con más paranoia vienen antes)
  if (!estado.ctx) return;
  if ((gotasT -= dt) <= 0 && AUD.gotas) { gotasT = 28 + Math.random() * 52; const d = Math.min(AUD.gotas.duration - .5, 3 + Math.random() * 3); sonidoLejano(AUD.gotas, Math.random() * (AUD.gotas.duration - d), d, .5, 1800, VOL.amb); }
  if ((golpT -= dt * (1 + estado.par * 1.5)) <= 0 && (AUD.golp1 || AUD.golp2)) {
    golpT = 100 + Math.random() * 140;
    if (AUD.golp2 && (!AUD.golp1 || Math.random() < .5)) { const i = (Math.random() * GOLPES2_T.length) | 0, n = Math.min(1 + ((Math.random() * 3) | 0), GOLPES2_T.length - i), off = Math.max(0, GOLPES2_T[i] - .35), fin = Math.min(AUD.golp2.duration, GOLPES2_T[i + n - 1] + 1.3); sonidoLejano(AUD.golp2, off, fin - off, .7, 2800, VOL.ent); }
    else sonidoLejano(AUD.golp1, 0, AUD.golp1.duration, .8, 3200, VOL.ent);
  }
}
