# Backrooms — Nivel 0 (versión modular)

Juego de terror en primera persona hecho con Three.js r128. Esta versión separa el antiguo `backrooms.html` (un solo archivo) en módulos ES.

## Cómo ejecutarlo

Los módulos ES **no funcionan abriendo `index.html` con doble clic** (`file://`): el navegador los bloquea. Hace falta servirlo por HTTP, aunque sea en local:

```bash
cd backrooms
python3 -m http.server 8000      # o: npx serve
# abre http://localhost:8000
```

En Android sin ordenador: súbelo a cualquier hosting estático (GitHub Pages, Netlify Drop, Cloudflare Pages…) o sírvelo desde Termux con el mismo comando de Python.
Three.js se carga desde un CDN (import map de `index.html`). Para jugar sin conexión, descarga `three.module.js` r128 a `js/lib/` y cambia la URL del import map por `./js/lib/three.module.js`.

Navegadores: Chrome/Edge 89+, Firefox 108+, Safari 16.4+ (import maps + top-level await).

## Estructura

```
index.html          HTML limpio: DOM del juego + import map + <script type="module" src="js/main.js">
css/styles.css      Estilos y HUD
assets/
  audio/*.mp3       Aullidos, carrera, susurros, ambiente, respiración, gotas, golpes
  sombra.webp       Sprite de la sombra
  maniqui.bin       Poses del maniquí (SketchPunk, CC BY 4.0)
js/
  config.js         Constantes (C, H, SZ, R, SEMILLA, TACTIL…) y `estado` (variables globales mutables)
  main.js           Punto de entrada: importa todo, registra eventos y ejecuta el bucle `bucle()`
  player.js         Controles (teclado/ratón/táctil), movimiento, caída, cámara del jugador, PARANOIA, muerte/reinicio
  world.js          Chunks procedurales, carga/descarga, colisiones, zonas oscuras
  shaders.js        Render a textura + post-proceso analógico / visión nocturna (GLSL en VERT_POST y FRAG_POST)
  — escena y datos —
  escena.js         renderer, scene, cam, luces      utils.js     hash / rng con semilla
  texturas.js       texturas en canvas               materiales.js  materiales, geometrías, maniquíes
  muebles.js        muebles y colisiones             manchas.js / garabatos.js / grietas.js   decals
  salas.js          salas especiales                 modeloCamara.js  modelo 3D de la cámara de mano
  — sistemas del juego —
  camara.js         zoom, ojo de pez, visión nocturna, batería, fecha, cámara/medidor en mano
  hidratacion.js    sed y botellas               inventario.js   mochila, objetos, interacción
  medidor.js        medidor de porcentajes y destino de la salida
  modos.js          dificultades (Fácil / Canon / Liminal)       luces.js   fallos de luz
  cinematica.js     intro en la casa abandonada                  hud.js     barras y reloj
  — audio y entidades —
  audio.js          Web Audio, zumbido, carga de mp3             aulladores.js  entidad sonora
  sombra.js         entidad "sombra"                             sonidoAmbiente.js  ambiente, respiración, gotas, golpes
  — menú —
  menu.js           menú principal 3D                            ajustes.js  volúmenes y brillo
  sonidosMenu.js    sonidos sintetizados del menú                dom.js      referencias a elementos del HTML
```

## Reglas para modificarlo sin romper nada

1. **Variables que cambian y usa más de un módulo → `estado`** (en `config.js`). Un módulo no puede reasignar una variable que importa (`import { par }` es de solo lectura), así que se usa `estado.par += 0.1`. Las variables que solo usa un módulo siguen siendo `let` locales.
2. **El orden de los `import` de `main.js` es el orden de carga.** Cada módulo construye su parte de la escena al importarse (texturas, muebles, menú 3D…). Si añades un módulo que use algo de otro en caliente (a nivel superior, fuera de una función), impórtalo *después* de ese otro.
3. **Los listeners de eventos** (`addEventListener`, `.onclick = …`) están dentro de una función `eventosXxx()` por módulo, llamada desde `main.js` en el orden original. Si añades un listener, ponlo ahí.
4. **Dependencias circulares:** muchos módulos se importan entre sí (p. ej. `player` ↔ `camara`). Es válido mientras solo se usen dentro de funciones. Lo que se ejecuta al cargar el módulo debe depender únicamente de módulos “de abajo” (`config`, `escena`, `texturas`, `materiales`, `muebles`, `dom`…).
5. **Añadir un efecto al shader:** edita `FRAG_POST` en `shaders.js` y, si necesita un valor nuevo, añade el uniform en `postMat` y actualízalo en `camaraSistema()` (`camara.js`).
6. **Añadir un recurso:** colócalo en `assets/` y cárgalo con `new URL('../assets/…', import.meta.url)`.

## Créditos

- Modelo "Mannequin Female" de SketchPunk — CC BY 4.0.
- Three.js — MIT.
